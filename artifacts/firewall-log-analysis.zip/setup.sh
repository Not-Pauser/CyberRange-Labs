#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === Firewall Log Analysis Lab Setup ==="

apt-get update -qq
apt-get install -y -qq python3 gawk jq > /dev/null 2>&1

mkdir -p /opt/lab_data/firewall
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/firewall

echo "[*] Generating multi-vendor firewall logs..."
python3 << 'PYEOF'
import random, datetime

random.seed(42)
base = datetime.datetime(2026, 3, 20, 0, 0, 0)
attacker = "203.0.113.77"
scanner = "198.51.100.42"
internal = [f"10.0.1.{i}" for i in range(10, 60)]
compromised = "10.0.1.25"
c2 = "185.220.101.42"

# === iptables format ===
with open("iptables.log", "w") as f:
    for i in range(3000):
        ts = base + datetime.timedelta(seconds=random.randint(0, 86400))
        tss = ts.strftime("%b %d %H:%M:%S")
        if i < 2000:
            src = random.choice(internal)
            dst = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
            dpt = random.choice([80,443,53,8080])
            action = "ACCEPT"
        elif i < 2500:
            src = scanner
            dst = random.choice(internal)
            dpt = random.randint(1, 65535)
            action = "DROP"
        elif i < 2700:
            src = compromised
            dst = random.choice([h for h in internal if h != compromised])
            dpt = 445
            action = "ACCEPT"
        else:
            src = compromised
            dst = c2
            dpt = random.choice([443, 8443])
            action = "ACCEPT"

        spt = random.randint(1024, 65535)
        proto = "TCP" if dpt != 53 else random.choice(["TCP", "UDP"])
        f.write(f'{tss} fw-gw kernel: [{action}] IN=eth0 OUT=eth1 SRC={src} DST={dst} LEN={random.randint(40,1500)} '
                f'TTL=64 ID={random.randint(1,65535)} PROTO={proto} SPT={spt} DPT={dpt}\n')

# === OPNsense filterlog (CSV) ===
with open("opnsense.log", "w") as f:
    for i in range(2000):
        ts = base + datetime.timedelta(seconds=random.randint(0, 86400))
        if i < 1400:
            src = random.choice(internal)
            dst = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
            dpt = random.choice([80,443])
            action = "pass"
        elif i < 1700:
            src = scanner
            dst = random.choice(internal)
            dpt = random.randint(1, 65535)
            action = "block"
        else:
            src = compromised
            dst = c2
            dpt = 8443
            action = "pass"
        spt = random.randint(1024, 65535)
        f.write(f'{ts.strftime("%b %d %H:%M:%S")},filterlog,{random.randint(1,200)},em0,match,{action},in,4,tcp,'
                f'{src},{spt},{dst},{dpt},{random.randint(40,1500)}\n')

# === Palo Alto CSV ===
with open("paloalto.csv", "w") as f:
    f.write("Date/Time,Source,Destination,Application,Action,Rule,Bytes Sent,Bytes Received,Source Port,Destination Port\n")
    for i in range(2000):
        ts = base + datetime.timedelta(seconds=random.randint(0, 86400))
        if i < 1500:
            src = random.choice(internal)
            dst = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
            dpt = random.choice([80,443])
            app = random.choice(["web-browsing","ssl","dns"])
            action = "allow"
            rule = "Internet-Access"
        elif i < 1800:
            src = scanner
            dst = random.choice(internal)
            dpt = random.randint(1, 65535)
            app = "incomplete"
            action = "deny"
            rule = "Default-Deny"
        else:
            src = compromised
            dst = c2
            dpt = 8443
            app = "unknown-tcp"
            action = "allow"
            rule = "Internet-Access"
        f.write(f'{ts.strftime("%Y/%m/%d %H:%M:%S")},{src},{dst},{app},{action},{rule},'
                f'{random.randint(100,50000)},{random.randint(100,50000)},{random.randint(1024,65535)},{dpt}\n')

# === Firewall ruleset ===
with open("ruleset.txt", "w") as f:
    f.write("""# === Corporate Firewall Ruleset ===
# Priority  Action  Source            Destination       Port        Proto  Description
# -------- ------  ----------------  ----------------  ----------  -----  ----------------------------------------
  10       ALLOW   10.0.1.0/24       ANY               80,443      TCP    Web browsing (HTTP/HTTPS)
  20       ALLOW   10.0.1.0/24       10.0.2.5/32       53          UDP    DNS to internal resolver
  30       ALLOW   10.0.1.0/24       10.0.3.0/24       22          TCP    SSH to server VLAN
  40       ALLOW   10.0.1.0/24       10.0.1.0/24       445,139     TCP    Internal SMB/CIFS (ALL workstations)    # TOO BROAD
  50       ALLOW   ANY               ANY               ANY         ANY    Outbound catchall                       # OVERLY PERMISSIVE
  60       DENY    ANY               10.0.1.0/24       3389        TCP    Block external RDP
  70       ALLOW   10.0.2.5/32       10.0.1.0/24       ANY         TCP    DB admin to workstations                # SHADOWED by rule 50
  80       DENY    ANY               10.0.1.0/24       25          TCP    Block direct SMTP
  999      DENY    ANY               ANY               ANY         ANY    Default deny
""")

# === Decommissioned hosts ===
with open("decommissioned-hosts.txt", "w") as f:
    f.write("""# Hosts decommissioned but still referenced in firewall rules
10.0.1.50   WS-OLD-01   Decommissioned 2025-12-01
10.0.1.51   WS-OLD-02   Decommissioned 2025-12-01
10.0.3.15   SRV-LEGACY  Decommissioned 2026-01-15
""")

print("Generated iptables.log, opnsense.log, paloalto.csv, ruleset.txt")
PYEOF

echo "[+] Firewall log analysis lab ready."
