#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing tools..."
apt-get update -qq
apt-get install -y -qq python3 jq gawk > /dev/null 2>&1

mkdir -p /opt/lab_data
cd /opt/lab_data

echo "[*] Generating firewall logs and rules..."
python3 << 'PYEOF'
import random, datetime

random.seed(42)
start = datetime.datetime(2026, 3, 20, 0, 0, 0)
internal_hosts = [f"10.0.1.{i}" for i in range(10, 60)]
attacker_ip = "203.0.113.77"
scanner_ip = "198.51.100.42"
internal_scanner = "10.0.1.45"

# Firewall log
with open("firewall.log", "w") as f:
    f.write("timestamp,action,src_ip,src_port,dst_ip,dst_port,proto,rule_id,bytes\n")
    for i in range(5000):
        ts = start + datetime.timedelta(seconds=random.randint(0, 86400))
        src = random.choice(internal_hosts)
        dst_port = random.choice([80, 443, 53, 22, 3389, 8080, 25, 110])

        if i < 3500:
            # Normal traffic
            dst = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
            action = "ALLOW"
            rule_id = random.choice(["R001", "R002", "R003", "R004"])
        elif i < 4200:
            # External port scan
            src = scanner_ip
            dst = random.choice(internal_hosts)
            dst_port = random.randint(1, 65535)
            action = "DENY"
            rule_id = "R010"
        elif i < 4600:
            # Lateral movement (SMB between internal hosts)
            src = internal_scanner
            dst = random.choice([h for h in internal_hosts if h != internal_scanner])
            dst_port = 445
            action = "ALLOW"
            rule_id = "R005"
        else:
            # Attacker C2 callback
            src = "10.0.1.25"
            dst = attacker_ip
            dst_port = random.choice([443, 8443, 4444])
            action = "ALLOW"
            rule_id = "R003"

        proto = "TCP" if dst_port != 53 else random.choice(["TCP", "UDP"])
        src_port = random.randint(1024, 65535)
        size = random.randint(40, 15000)
        f.write(f"{ts.isoformat()},{action},{src},{src_port},{dst},{dst_port},{proto},{rule_id},{size}\n")

# Firewall ruleset
with open("firewall_rules.conf", "w") as f:
    f.write("""# Firewall Ruleset - Corp Network
# Rule ID | Action | Src | Dst | Port | Proto | Description

R001  ALLOW  10.0.1.0/24  any          80,443  TCP  "Web browsing"
R002  ALLOW  10.0.1.0/24  10.0.2.0/24  53      UDP  "DNS to internal DNS"
R003  ALLOW  any          any          any     any  "Allow all outbound"      # OVERLY PERMISSIVE
R004  ALLOW  10.0.1.0/24  10.0.3.0/24  22      TCP  "SSH to servers"
R005  ALLOW  10.0.1.0/24  10.0.1.0/24  445     TCP  "Internal SMB"            # Too broad
R006  DENY   10.0.1.0/24  any          25      TCP  "Block direct SMTP"
R007  ALLOW  10.0.1.0/24  10.0.2.5     3306    TCP  "MySQL access"
R008  DENY   any          10.0.1.0/24  3389    TCP  "Block external RDP"
R009  ALLOW  10.0.2.5     10.0.1.0/24  any     TCP  "DB server to workstations" # SHADOWED by R003
R010  DENY   any          any          any     any  "Default deny"
""")

print("Generated firewall.log and firewall_rules.conf")
PYEOF

cat > /opt/lab_data/README.txt << 'EOF'
=== Firewall Log Analysis & Rule Auditing Lab ===

Files:
  firewall.log        - Firewall log (CSV: timestamp, action, src, src_port, dst, dst_port, proto, rule_id, bytes)
  firewall_rules.conf - Firewall ruleset configuration

Analysis tips:
  # Top denied source IPs
  grep "DENY" firewall.log | awk -F, '{print $3}' | sort | uniq -c | sort -rn | head

  # Find port scanning (many unique dest ports from one source)
  grep "DENY" firewall.log | awk -F, '{print $3,$6}' | sort -u | awk '{a[$1]++} END{for(k in a) if(a[k]>10) print a[k],k}'

  # Internal lateral movement (SMB)
  grep ",445," firewall.log | grep "10.0.1" | awk -F, '{print $3"->"$5}' | sort | uniq -c | sort -rn

  # Outbound to suspicious ports
  grep "ALLOW" firewall.log | awk -F, '$6==4444||$6==8443{print}' | head

Your goal: find port scans, lateral movement, overly permissive rules, and write better rules.
EOF

echo "[+] Firewall log analysis lab setup complete."
