#!/bin/bash
###############################################################################
# setup.sh — Firewall Log Analysis & Rule Auditing lab (Module 4)
#
# Runs ON the lab VM (Ubuntu 22.04) as root after the artifact bundle is
# extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# Responsibilities (kept deliberately small — NO data generation, NO Splunk,
# NO web UI):
#   1. Install the CLI tools the tasks rely on (jq + gawk; grep/sort/uniq are
#      already present on the base image).
#   2. Create the /lab-data -> /opt/lab_data symlink the other labs use, plus
#      the /opt/lab_data/firewall/ sub-directory the material references.
#   3. Place the pre-generated, deterministic log files where material.md
#      expects them (both /opt/lab_data/firewall/ and /lab-data/firewall/).
#
# The log files are GENERATED OFFLINE by generate_logs.py and shipped inside
# the artifact bundle — they are NOT produced here, so grading stays 100 %
# reproducible.
#
# Idempotent + always exits 0.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

LAB_SRC="/opt/lab_data"
LAB_DIR="/opt/lab_data/firewall"

echo "[*] === Firewall Log Analysis & Rule Auditing lab setup ==="

# ── 1. Install CLI analysis tools (idempotent) ──────────────────────────────
if ! command -v jq >/dev/null 2>&1 || ! command -v gawk >/dev/null 2>&1; then
    echo "[*] Installing jq + gawk ..."
    apt-get update -y -qq 2>/dev/null || true
    apt-get install -y -qq jq gawk >/dev/null 2>&1 || true
else
    echo "[+] jq + gawk already installed"
fi

# ── 2. Lab directory + /lab-data symlink (matches the other labs) ───────────
mkdir -p "${LAB_DIR}"
ln -sf "${LAB_SRC}" /lab-data 2>/dev/null || true

# ── 3. Place the deterministic log files where material.md expects them ─────
# The artifact bundle drops the files at the root of /opt/lab_data; copy them
# into the firewall/ sub-directory referenced throughout material.md.
for f in iptables.log paloalto.csv opnsense.log ruleset.conf \
         decommissioned-hosts.txt README.txt; do
    if [ -f "${LAB_SRC}/${f}" ]; then
        cp -f "${LAB_SRC}/${f}" "${LAB_DIR}/${f}"
        echo "[+] ${LAB_DIR}/${f}"
    elif [ -f "${LAB_DIR}/${f}" ]; then
        echo "[+] ${LAB_DIR}/${f} (already in place)"
    else
        echo "[!] WARNING: ${f} not found in artifact bundle"
    fi
done

# Make the log files world-readable so the trainee account can read them.
chmod 0644 "${LAB_DIR}"/*.log "${LAB_DIR}"/*.csv "${LAB_DIR}"/*.conf \
           "${LAB_DIR}"/*.txt 2>/dev/null || true

echo "[*] Firewall lab setup complete."
ls -lh "${LAB_DIR}/" 2>/dev/null || true
exit 0
