FIREWALL LOG ANALYSIS LAB - Artifact Kit
=========================================

FILES INCLUDED:
- iptables.log   : 2000 Linux iptables/UFW log entries
- opnsense.log   : 1500 OPNsense filterlog entries
- paloalto.csv   : 1500 Palo Alto firewall log entries (CSV)
- ruleset.txt    : Current firewall ruleset with security gaps

SCENARIO:
You are performing a security audit of the corporate network's firewall
infrastructure on March 16, 2025. Multiple firewall platforms are in use.

ANALYSIS TASKS:
1. Parse and correlate logs across all three firewall formats
2. Identify the external attacker IP conducting port scans
3. Find allowed connections that should have been blocked
4. Identify C2 traffic that passed through the firewall
5. Locate data exfiltration attempts (DNS, HTTPS)
6. Review the ruleset and identify ALL security gaps

SECURITY GAPS TO FIND IN RULESET:
- Rule 2: SSH open to world (should be admin IPs only)
- Rule 4: No SSL/TLS inspection on outbound HTTPS
- Rule 6: DNS allowed to external (enables tunneling)
- Rule 9: ICMP allowed globally
- Rule 11: Database access too broad
- Rule 12: No egress filtering on high ports

REMEDIATION: For each gap, write the corrected rule.

CORRELATION EXERCISE:
Track the attacker IP across all three log sources:
- What was scanned? (iptables)
- What was allowed through? (opnsense)
- What threats were detected? (paloalto)
