=== Firewall Log Analysis & Rule Auditing — lab data ===

Multi-vendor firewall logs from one network's edge appliance, covering a
24-hour window (2026-04-14). Three export formats of the same environment:

  iptables.log            Linux netfilter/iptables kernel log (ACCEPT / DROP).
                          Key fields per line: SRC= DST= PROTO= SPT= DPT= RULE=
                          Action is in the bracket tag: [FW-ACCEPT] / [FW-DROP].

  paloalto.csv            Palo Alto traffic-log export with NAMED CSV columns:
                          DateTime,Action,Source,Destination,Application,Protocol,
                          SourcePort,DestinationPort,BytesSent,BytesReceived,Rule,RuleID
                          Action is allow / deny. BytesSent is the egress volume.

  opnsense.log            OPNsense / pf filterlog (CSV). action field = pass / block.

  ruleset.conf            The firewall ruleset (for the rule-audit task).
  decommissioned-hosts.txt

Analyse with the CLI only: grep / awk / sort / uniq, plus jq-style CSV work.
Work through the tasks in the training portal panel on the right.
