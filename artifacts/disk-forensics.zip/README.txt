DISK FORENSICS LAB - Artifact Kit
==================================

FILES INCLUDED:
- file_listing.txt    : Complete file system listing from forensic image
- deleted_files.txt   : Recovered deleted/unallocated files
- browser_history.csv : Chrome browser history extraction
- usb_devices.csv     : USB device connection history
- timeline.csv        : Consolidated forensic timeline (super timeline)

SCENARIO:
Workstation WS-DEV03 (user: jsmith) was involved in a security incident
on March 19, 2025. A forensic image was taken and these artifacts extracted.

NOTE: Since real disk images are 50GB+, this lab provides pre-extracted
artifacts that mirror what forensic tools (Autopsy, FTK, X-Ways) produce.

FORENSIC ANALYSIS TASKS:
1. FILE SYSTEM ANALYSIS:
   - Identify all suspicious files and their locations
   - Note timestamps to establish when files were created
   - Look for files in unusual locations (Temp, ProgramData)
   - Identify any persistence mechanisms

2. DELETED FILE ANALYSIS:
   - Determine what the attacker tried to hide
   - Assess which deleted files are attack tools vs normal deletions
   - Note which files were partially vs fully recovered

3. BROWSER FORENSICS:
   - Trace the initial compromise vector (phishing link)
   - Identify the malicious download source
   - Distinguish attack-related browsing from normal activity

4. USB FORENSICS:
   - Identify all USB storage devices
   - Determine which device was used for data exfiltration
   - Note first-time-connected devices (high suspicion)

5. TIMELINE ANALYSIS:
   - Reconstruct the complete attack timeline
   - Identify the initial compromise time
   - Map each attack phase (access, execution, persistence, lateral, exfil)
   - Calculate total dwell time

KEY FINDINGS TO DOCUMENT:
- Initial access vector and timestamp
- All malware artifacts (names, hashes, locations)
- Persistence mechanisms
- Credential theft evidence
- Data exfiltration method and volume
- Anti-forensic actions taken by attacker
