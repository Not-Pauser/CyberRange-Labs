
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === Disk Forensics Lab Setup ==="
New-Item -Path C:\LabData\forensics -ItemType Directory -Force | Out-Null

Write-Host "[*] Creating forensic disk image with planted artifacts..."

# Create a VHD with planted evidence (since E01 requires special tools)
$vhdPath = "C:\LabData\forensics\suspect-drive.vhd"
$vhdSize = 50MB

# Create VHD
$diskpartScript = @"
create vdisk file="$vhdPath" maximum=50 type=fixed
select vdisk file="$vhdPath"
attach vdisk
create partition primary
format fs=ntfs quick label="Evidence"
assign letter=E
"@
$diskpartScript | diskpart 2>$null
Start-Sleep -Seconds 5

if (Test-Path "E:\") {
    Write-Host "[*] Planting forensic artifacts on evidence drive..."

    # Sensitive files (data exfiltration evidence)
    New-Item -Path "E:\Documents" -ItemType Directory -Force | Out-Null
    "Employee SSN Data`nJohn Smith,123-45-6789`nJane Doe,987-65-4321" | Set-Content "E:\Documents\Employee-SSN.csv"
    "Q1 Revenue: $2.5M`nProjected Q2: $3.1M`nConfidential" | Set-Content "E:\Documents\Q1-Revenue.xlsx.txt"
    "admin:P@ssw0rd!`nroot:toor123`nbackup:B@ckup2026" | Set-Content "E:\Documents\passwords.txt"
    "Project Alpha - Internal Only`nBudget: $500K`nTimeline: Q3 2026" | Set-Content "E:\Documents\Project-Alpha.docx.txt"

    # Browser history
    New-Item -Path "E:\AppData\Local\Google\Chrome\User Data\Default" -ItemType Directory -Force | Out-Null
    @"
URL,Title,Visit Time,Visit Count
https://mail.google.com/,Gmail - Inbox,2026-03-18 09:15:00,5
https://drive.google.com/upload,Google Drive Upload,2026-03-18 09:30:00,2
https://mega.nz/upload,MEGA Upload,2026-03-18 10:00:00,1
https://pastebin.com/new,Pastebin New Paste,2026-03-18 10:15:00,1
https://www.dropbox.com/upload,Dropbox Upload,2026-03-18 10:30:00,1
"@ | Set-Content "E:\AppData\Local\Google\Chrome\User Data\Default\History.csv"

    # Deleted files (simulate Recycle Bin)
    New-Item -Path "E:\`$Recycle.Bin\S-1-5-21-user" -ItemType Directory -Force | Out-Null
    "DELETED: passwords.txt - original path C:\Users\jsmith\Documents\passwords.txt" | Set-Content "E:\`$Recycle.Bin\S-1-5-21-user\`$Rrecovered1.txt"
    "DELETED: data_export.zip - 15.7MB - USB copy evidence" | Set-Content "E:\`$Recycle.Bin\S-1-5-21-user\`$Rrecovered2.txt"

    # USB trace file
    @"
USB Device History:
  Kingston DataTraveler 3.0 (E0D55EA573F3F180) - Connected: 2026-03-18 10:45
  SanDisk Ultra (4C530001220803) - Connected: 2026-03-10 09:00
"@ | Set-Content "E:\USBDeviceLog.txt"

    # Suspicious executable remnant
    [byte[]]$exeBytes = @(0x4D, 0x5A, 0x90, 0x00) + (1..200 | ForEach-Object { 0x00 })
    [System.IO.File]::WriteAllBytes("E:\Documents\updater.exe", $exeBytes)

    # Timeline CSV
    @"
Timestamp,Action,Path,Size,User
2026-03-18 09:00:00,Created,C:\Users\jsmith\Documents\Q1-Revenue.xlsx,2.1MB,jsmith
2026-03-18 09:30:00,Created,C:\Users\jsmith\Desktop\data_export.zip,15.7MB,jsmith
2026-03-18 10:00:00,Copied,E:\backup\data_export.zip,15.7MB,jsmith
2026-03-18 10:10:00,Deleted,C:\Users\jsmith\Desktop\data_export.zip,15.7MB,jsmith
2026-03-18 10:15:00,Deleted,C:\Users\jsmith\Documents\passwords.txt,0.1KB,jsmith
2026-03-18 10:45:00,Disconnected,E:\ (Kingston DataTraveler),,jsmith
"@ | Set-Content "E:\filesystem_timeline.csv"

    Write-Host "[+] Evidence planted on E:\ drive"

    # Detach VHD
    $detach = "select vdisk file=""$vhdPath""`ndetach vdisk"
    $detach | diskpart 2>$null
} else {
    Write-Host "[-] Could not mount VHD, creating flat evidence instead"
    New-Item -Path "C:\LabData\forensics\evidence" -ItemType Directory -Force | Out-Null
    "This is a placeholder - VHD creation requires admin" | Set-Content "C:\LabData\forensics\evidence\README.txt"
}

@"
=== Disk Forensics Lab ===

Evidence: C:\LabData\forensics\suspect-drive.vhd
  Mount with: Right-click -> Mount, or Disk Management -> Attach VHD

Alternative: Open with Autopsy (if installed) as a disk image.
  Download Autopsy from: https://www.autopsy.com/download/

Investigation targets:
  1. Recover deleted files from Recycle Bin
  2. Extract browser history (Chrome History.csv)
  3. Find USB device connection evidence
  4. Identify data exfiltration (cloud uploads + USB copies)
  5. Build filesystem timeline of suspicious activity
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] Disk Forensics lab ready."
