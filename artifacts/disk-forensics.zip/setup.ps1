
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up Disk Forensics lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null
$logPath = "C:\LabData"

# Create simulated forensic artifacts
Write-Host "[*] Creating forensic artifacts..."

# Browser history CSV
$history = @(
    [PSCustomObject]@{Timestamp="2026-03-18 09:15:00"; URL="https://mail.google.com"; Title="Gmail"},
    [PSCustomObject]@{Timestamp="2026-03-18 09:30:00"; URL="https://drive.google.com/upload"; Title="Google Drive - Upload"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:00:00"; URL="https://mega.nz/upload"; Title="MEGA - File Upload"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:15:00"; URL="https://pastebin.com/new"; Title="Pastebin - New Paste"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:30:00"; URL="https://www.dropbox.com/upload"; Title="Dropbox - Upload"},
    [PSCustomObject]@{Timestamp="2026-03-18 11:00:00"; URL="https://outlook.office365.com"; Title="Outlook"}
)
$history | Export-Csv -Path "$logPath\browser_history.csv" -NoTypeInformation

# Create files that simulate "deleted and recovered" items
New-Item -Path "$logPath\RecycleBin" -ItemType Directory -Force | Out-Null
"SSN: 123-45-6789`nName: John Smith`nSalary: 150000" | Set-Content "$logPath\RecycleBin\Employee_Data.csv"
"Project Alpha - Confidential`nBudget: $2.5M`nTimeline: Q3 2026" | Set-Content "$logPath\RecycleBin\Project_Alpha_Budget.xlsx.txt"
"admin:P@ssw0rd123!`nroot:toor`nbackup:B@ckup2026" | Set-Content "$logPath\RecycleBin\passwords.txt"

# USB device artifacts
$usb = @(
    [PSCustomObject]@{DeviceName="Kingston DataTraveler 3.0"; Serial="E0D55EA573F3F180"; FirstConnected="2026-03-15 08:00:00"; LastConnected="2026-03-18 10:45:00"; DriveLetter="E:"},
    [PSCustomObject]@{DeviceName="SanDisk Ultra USB 3.0"; Serial="4C530001220803"; FirstConnected="2026-03-01 14:30:00"; LastConnected="2026-03-10 09:00:00"; DriveLetter="F:"}
)
$usb | Export-Csv -Path "$logPath\usb_devices.csv" -NoTypeInformation

# File system timeline
$timeline = @(
    [PSCustomObject]@{Timestamp="2026-03-18 09:00:00"; Action="Created"; Path="C:\Users\jsmith\Documents\Q1-Revenue.xlsx"; Size="2.1 MB"},
    [PSCustomObject]@{Timestamp="2026-03-18 09:05:00"; Action="Modified"; Path="C:\Users\jsmith\Documents\Q1-Revenue.xlsx"; Size="2.3 MB"},
    [PSCustomObject]@{Timestamp="2026-03-18 09:30:00"; Action="Created"; Path="C:\Users\jsmith\Desktop\data_export.zip"; Size="15.7 MB"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:00:00"; Action="Copied"; Path="E:\backup\data_export.zip"; Size="15.7 MB"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:10:00"; Action="Deleted"; Path="C:\Users\jsmith\Desktop\data_export.zip"; Size="15.7 MB"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:15:00"; Action="Deleted"; Path="C:\Users\jsmith\Documents\passwords.txt"; Size="0.1 KB"},
    [PSCustomObject]@{Timestamp="2026-03-18 10:45:00"; Action="Disconnected"; Path="E:\ (Kingston DataTraveler)"; Size=""}
)
$timeline | Export-Csv -Path "$logPath\filesystem_timeline.csv" -NoTypeInformation

@"
=== Disk Forensics with Autopsy Lab ===

Files:
  browser_history.csv       - Browser history from suspect's machine
  RecycleBin/               - Files recovered from Recycle Bin
  usb_devices.csv           - USB device connection history
  filesystem_timeline.csv   - File system event timeline

Analysis Tasks:
  1. Examine recovered files from RecycleBin/ for sensitive data
  2. Review browser_history.csv for data exfiltration (cloud uploads)
  3. Check usb_devices.csv for USB device used during the incident
  4. Build a timeline using filesystem_timeline.csv
  5. Correlate USB connection times with file copy events

PowerShell analysis:
  Import-Csv C:\LabData\filesystem_timeline.csv | Format-Table -AutoSize
  Import-Csv C:\LabData\browser_history.csv | Where-Object {`$_.URL -like "*upload*"} | Format-Table

Your goal: Determine what data was exfiltrated, when, and how.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] Disk Forensics lab setup complete."
