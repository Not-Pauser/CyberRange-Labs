SIEM ALERT TRIAGE LAB - Artifact Kit
======================================

FILES INCLUDED:
- windows_auth.json    : 1500 Windows authentication events
- network_events.json  : 2000 firewall/network flow events
- sysmon_process.json  : 1000 Sysmon process creation events
- alerts.json          : 50 SIEM alerts (mix of true and false positives)

SCENARIO:
You are a Tier 1 SOC analyst. Your SIEM has generated 50 alerts over a 24-hour period.
Your job is to triage each alert and determine if it is a TRUE POSITIVE or FALSE POSITIVE.

TRIAGE PROCESS FOR EACH ALERT:
1. Read the alert description and severity
2. Pivot to the relevant data source (auth, network, or process logs)
3. Look for corroborating evidence
4. Determine if the alert is a true positive or false positive
5. Document your reasoning

KEY QUESTIONS:
- Is the source IP internal or external?
- Is the activity consistent with normal business operations?
- Are there multiple correlated alerts from the same source?
- Does the timeline make sense for an attack chain?

ATTACKER INDICATORS (discover through investigation):
- External IP conducting brute force and scanning
- C2 beaconing to known malicious IP
- LOLBIN usage (certutil, bitsadmin, mshta)
- Office macro spawning shell
- Compromised user: investigate who was targeted

The _answer_key field in alerts.json contains the correct verdict.
Remove this field before giving to students!
