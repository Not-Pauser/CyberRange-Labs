#!/bin/bash
###############################################################################
# setup.sh — SIEM Alert Triage & Correlation lab
#
# Runs ON the lab VM (Ubuntu desktop) after the artifact zip extracts to
# /opt/lab_data. Installs Splunk (scenario recipe), then loads the 4 data
# sources so the trainee browses http://localhost:8000 with everything indexed:
#   alerts.json         -> index=alerts
#   windows_auth.json   -> index=wineventlog   (4624/4625)
#   network_events.json -> index=firewall      (src_ip/dst_ip/dst_port)
#   sysmon_process.json -> index=sysmon        (EventCode 1 process creation)
#
# The data files are JSON ARRAYS — they're converted to NDJSON (one object per
# line) so Splunk indexes each record as its own event (counts must be exact).
###############################################################################
set -uo pipefail

SPLUNK_URL="${SPLUNK_URL:-https://download.splunk.com/products/splunk/releases/9.3.0/linux/splunk-9.3.0-51ccf43db5bd-Linux-x86_64.tgz}"
SPLUNK_HOME="/opt/splunk"
SPLUNK_PASS="changeme123!"
LAB_DATA="/opt/lab_data"

echo "[*] === SIEM Alert Triage lab setup ==="

# ── 1. Install Splunk (scenario recipe) if not present ───────────────────────
if [ ! -x "${SPLUNK_HOME}/bin/splunk" ]; then
    echo "[*] Downloading Splunk: ${SPLUNK_URL##*/}"
    curl -fsSL -o /opt/splunk.tgz "$SPLUNK_URL" || wget -qO /opt/splunk.tgz "$SPLUNK_URL"
    tar xzf /opt/splunk.tgz -C /opt/ && rm -f /opt/splunk.tgz
    echo "OPTIMISTIC_ABOUT_FILE_LOCKING = 1" >> "${SPLUNK_HOME}/etc/splunk-launch.conf"
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt --seed-passwd "$SPLUNK_PASS"
    "${SPLUNK_HOME}/bin/splunk" enable boot-start || true
else
    echo "[+] Splunk already installed"
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" || \
        "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt
fi

for _ in $(seq 1 24); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    sleep 5
done

AUTH="-auth admin:${SPLUNK_PASS}"

# ── 2. Convert JSON arrays -> NDJSON (one event per line) ────────────────────
for f in alerts windows_auth network_events sysmon_process; do
    if [ -f "${LAB_DATA}/${f}.json" ]; then
        python3 -c "import json;[print(json.dumps(o)) for o in json.load(open('${LAB_DATA}/${f}.json'))]" \
            > "${LAB_DATA}/${f}.ndjson" 2>/dev/null && echo "[+] ${f}.ndjson" || echo "[!] ${f} convert failed"
    fi
done

# ── 3. Create the indexes the lab's queries use ──────────────────────────────
for idx in alerts wineventlog firewall sysmon; do
    "${SPLUNK_HOME}/bin/splunk" add index "$idx" $AUTH 2>/dev/null || true
done

# ── 4. Field extraction + aliases so material.md field names resolve ─────────
CONF_DIR="${SPLUNK_HOME}/etc/system/local"
mkdir -p "$CONF_DIR"
cat >> "${CONF_DIR}/props.conf" <<'PROPS'
[alerts_json]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT

[WinEventLog:Security]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT
FIELDALIAS-eventcode = EventID AS EventCode
FIELDALIAS-srcaddr   = SourceAddress AS Source_Network_Address
FIELDALIAS-srcip     = SourceAddress AS src_ip
FIELDALIAS-account   = SubjectUserName AS Account_Name
FIELDALIAS-logontype = LogonType AS Logon_Type
FIELDALIAS-host      = Computer AS host

[network_json]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT

[Sysmon]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT
FIELDALIAS-eventcode = EventID AS EventCode
PROPS

# ── 5. Inputs: monitor each NDJSON into the right index / sourcetype ─────────
cat > "${CONF_DIR}/inputs.conf" <<INPUTS
[monitor://${LAB_DATA}/alerts.ndjson]
sourcetype = alerts_json
index = alerts
disabled = false

[monitor://${LAB_DATA}/windows_auth.ndjson]
sourcetype = WinEventLog:Security
index = wineventlog
disabled = false

[monitor://${LAB_DATA}/network_events.ndjson]
sourcetype = network_json
index = firewall
disabled = false

[monitor://${LAB_DATA}/sysmon_process.ndjson]
sourcetype = Sysmon
index = sysmon
disabled = false
INPUTS

# ── 6. Restart so inputs/props/indexes take effect ───────────────────────────
"${SPLUNK_HOME}/bin/splunk" restart $AUTH 2>/dev/null || \
    "${SPLUNK_HOME}/bin/splunk" restart --accept-license --answer-yes --no-prompt || true
# ENSURE splunkd is actually up — the restart can race/fail on a slow VM.
for _ in $(seq 1 18); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt 2>/dev/null || true
    sleep 5
done

echo "[+] SIEM Alert Triage lab ready — http://localhost:8000  (admin / ${SPLUNK_PASS})"

# Remove this provisioning script so the trainee sees only the lab data, not how it was built.
rm -f /opt/lab_data/setup.sh 2>/dev/null || true
