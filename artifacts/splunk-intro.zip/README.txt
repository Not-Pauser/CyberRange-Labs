SPLUNK INTRO LAB - Artifact Kit
================================

FILES INCLUDED:
- web_access.log    : 5000 Apache access log entries (24hr period)
- windows_security.json : 3000 Windows Security events

SCENARIO:
A web server and domain controller were potentially compromised on March 10, 2025.
Ingest these logs into Splunk and investigate:

1. Identify the top source IPs and any suspicious external addresses
2. Find web scanning/attack patterns (path traversal, admin pages, SQLi)
3. Identify the brute force attack in Windows Security logs
4. Track the attacker's post-compromise activity (account creation, lateral movement)
5. Find evidence of log tampering

KEY SEARCH TIPS:
- source="web_access.log" | stats count by clientip | sort -count
- source="windows_security.json" EventID=4625 | stats count by SubjectUserName
- source="windows_security.json" EventID=4720

ATTACKER IOCs (verify these during investigation):
- Suspicious source IP in web logs from 198.51.100.0/24 range
- Multiple failed logons followed by success
- New account created post-compromise
- Audit log clearing event (EventID 1102)
