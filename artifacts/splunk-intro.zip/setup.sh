#!/bin/bash
###############################################################################
# setup.sh — Splunk Intro Lab
#
# Runs ON the lab VM (Ubuntu desktop) via `qm guest exec` after the artifact
# zip is extracted to /opt/lab_data. The zip ships the pre-generated data
# (web_access.log, windows_security.json); THIS script installs Splunk and
# loads that data so the trainee just browses http://localhost:8000.
#
# Splunk install mirrors the scenario role p4t12ick.ludus_ar_splunk exactly:
# same download URL, same /opt/splunk path, same admin password. Swap
# SPLUNK_URL to a MinIO bucket later — it's the only line that changes.
###############################################################################
set -uo pipefail

# ── Splunk source — identical to the scenario Splunk role ────────────────────
SPLUNK_URL="${SPLUNK_URL:-https://download.splunk.com/products/splunk/releases/9.3.0/linux/splunk-9.3.0-51ccf43db5bd-Linux-x86_64.tgz}"
SPLUNK_HOME="/opt/splunk"
SPLUNK_PASS="changeme123!"
LAB_DATA="/opt/lab_data"

echo "[*] === Splunk Intro Lab setup ==="

# ── 1. Install Splunk (scenario recipe) if not already present ───────────────
if [ ! -x "${SPLUNK_HOME}/bin/splunk" ]; then
    echo "[*] Downloading Splunk: ${SPLUNK_URL##*/}"
    curl -fsSL -o /opt/splunk.tgz "$SPLUNK_URL" || wget -qO /opt/splunk.tgz "$SPLUNK_URL"
    echo "[*] Extracting to /opt ..."
    tar xzf /opt/splunk.tgz -C /opt/
    rm -f /opt/splunk.tgz
    # Matches the scenario role (filesystem-locking compat) — harmless on a VM.
    echo "OPTIMISTIC_ABOUT_FILE_LOCKING = 1" >> "${SPLUNK_HOME}/etc/splunk-launch.conf"
    echo "[*] First start: accept license + seed admin password ..."
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt --seed-passwd "$SPLUNK_PASS"
    "${SPLUNK_HOME}/bin/splunk" enable boot-start || true
else
    echo "[+] Splunk already installed"
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" || \
        "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt
fi

# ── 2. Wait for Splunk to come up (up to ~2 min) ─────────────────────────────
for _ in $(seq 1 24); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    sleep 5
done

AUTH="-auth admin:${SPLUNK_PASS}"

# ── 3. Create the indexes this lab's material.md queries use ─────────────────
#     (index=main is built-in; index=wineventlog must be created)
"${SPLUNK_HOME}/bin/splunk" add index wineventlog $AUTH 2>/dev/null || true

# ── 4. JSON field extraction for the Windows Security events ─────────────────
#     windows_security.json is JSON; KV_MODE=json makes EventCode, Logon_Type,
#     Account_Name etc. searchable while keeping the WinEventLog:Security
#     sourcetype name the material.md queries expect.
CONF_DIR="${SPLUNK_HOME}/etc/system/local"
mkdir -p "$CONF_DIR"
cat >> "${CONF_DIR}/props.conf" <<'PROPS'
[WinEventLog:Security]
KV_MODE = json
SHOULD_LINEMERGE = false
# The data is statically timestamped (2025) but material.md uses earliest=-7d,
# so index it at current time → relative-time queries return results.
DATETIME_CONFIG = CURRENT
# Bridge the data's JSON field names to the names material.md teaches.
FIELDALIAS-eventcode = EventID AS EventCode
FIELDALIAS-account   = TargetUserName AS Account_Name
FIELDALIAS-srcip     = SourceIP AS src_ip
FIELDALIAS-logontype = LogonType AS Logon_Type
FIELDALIAS-host      = Computer AS host

[access_combined]
# Same — index web logs at current time so earliest/latest examples work.
DATETIME_CONFIG = CURRENT
PROPS

# ── 5. Inputs: monitor the lab data into the correct index / sourcetype ──────
cat > "${CONF_DIR}/inputs.conf" <<INPUTS
[monitor://${LAB_DATA}/web_access.log]
sourcetype = access_combined
index = main
disabled = false

[monitor://${LAB_DATA}/windows_security.json]
sourcetype = WinEventLog:Security
index = wineventlog
disabled = false
INPUTS

# ── 6. Restart so inputs + props take effect ─────────────────────────────────
"${SPLUNK_HOME}/bin/splunk" restart $AUTH 2>/dev/null || \
    "${SPLUNK_HOME}/bin/splunk" restart --accept-license --answer-yes --no-prompt || true
# ENSURE splunkd is actually up — the restart can race/fail on a slow VM, which
# is what left Splunk stopped after install. Start it until status confirms up.
for _ in $(seq 1 18); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt 2>/dev/null || true
    sleep 5
done

echo "[+] Splunk Intro Lab ready — http://localhost:8000  (admin / ${SPLUNK_PASS})"

# Remove this provisioning script so the trainee sees only the lab data, not how it was built.
rm -f /opt/lab_data/setup.sh 2>/dev/null || true
