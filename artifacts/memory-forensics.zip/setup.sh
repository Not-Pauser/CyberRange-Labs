#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing Python3, pip, and dependencies..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv unzip curl > /dev/null 2>&1

echo "[*] Installing Volatility3..."
pip3 install volatility3 yara-python pefile > /dev/null 2>&1

echo "[*] Downloading memory sample (public Cridex malware sample ~250MB)..."
mkdir -p /opt/lab_data
cd /opt/lab_data
# Use the well-known public Volatility sample from the NIST CFReDS project (smaller sample)
curl -sfL "https://github.com/volatilityfoundation/volatility3/releases/download/v2.0.0/test-data.zip" \
    -o /tmp/vol-samples.zip 2>/dev/null || true

if [ -f /tmp/vol-samples.zip ] && [ -s /tmp/vol-samples.zip ]; then
    unzip -o /tmp/vol-samples.zip -d /opt/lab_data/ 2>/dev/null || true
    rm -f /tmp/vol-samples.zip
fi

# Generate a realistic synthetic memory dump if download failed
if ! ls /opt/lab_data/*.raw /opt/lab_data/**/*.raw 2>/dev/null; then
    echo "[*] Creating synthetic memory dump for analysis..."
    python3 << 'PYEOF'
import struct, os, random

dump_path = "/opt/lab_data/compromised-memory.raw"
size = 64 * 1024 * 1024  # 64MB synthetic dump

with open(dump_path, "wb") as f:
    # Write mostly zeros with planted artifacts
    f.write(b"\x00" * 4096)

    # Plant MZ/PE header signatures at various offsets
    f.seek(0x1000)
    f.write(b"MZ" + b"\x90" * 58 + struct.pack("<I", 0xE0))  # DOS header
    f.seek(0x10E0)
    f.write(b"PE\x00\x00")  # PE signature

    # Plant suspicious process names
    artifacts = [
        (0x5000, b"svchost.exe\x00"),
        (0x5100, b"csrss.exe\x00"),
        (0x5200, b"explorer.exe\x00"),
        (0x5300, b"chrome.exe\x00"),
        (0x5400, b"updater.exe\x00"),       # suspicious
        (0x5500, b"SystemHealth.exe\x00"),   # suspicious - unusual name
        (0x6000, b"cmd.exe /c whoami\x00"),
        (0x6100, b"powershell.exe -enc aQBwAGMAbwBuAGYAaQBnAA==\x00"),
        (0x7000, b"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemHealth\x00"),
        (0x8000, b"192.168.1.105\x00"),      # internal IP
        (0x8100, b"45.33.32.156\x00"),        # suspicious external IP (scanme.nmap.org)
        (0x8200, b"185.220.101.42\x00"),      # suspicious C2 IP
        (0x9000, b"GET /beacon.php?id=A3F2 HTTP/1.1\r\nHost: c2.evil-domain.com\r\n\x00"),
        (0xA000, b"CreateRemoteThread\x00"),
        (0xA100, b"VirtualAllocEx\x00"),
        (0xA200, b"WriteProcessMemory\x00"),
        (0xA300, b"NtUnmapViewOfSection\x00"),
        (0xB000, b"TCP  0.0.0.0:4444  LISTENING  updater.exe\x00"),
        (0xB100, b"TCP  10.0.0.5:49712  185.220.101.42:443  ESTABLISHED\x00"),
        (0xC000, b"admin:P@ssw0rd123!\x00"),  # extracted credential
    ]
    for offset, data in artifacts:
        f.seek(offset)
        f.write(data)

    # Fill rest with random data to look like real memory
    f.seek(0x10000)
    remaining = size - 0x10000
    chunk = 65536
    while remaining > 0:
        write_size = min(chunk, remaining)
        f.write(os.urandom(write_size))
        remaining -= write_size

print(f"Created synthetic memory dump: {dump_path} ({os.path.getsize(dump_path)} bytes)")
PYEOF
fi

# Create analysis guide README
cat > /opt/lab_data/README.txt << 'EOF'
=== Memory Forensics Lab ===

Memory dump location: /opt/lab_data/compromised-memory.raw

Useful Volatility3 commands:
  python3 -m volatility3 -f compromised-memory.raw windows.info
  python3 -m volatility3 -f compromised-memory.raw windows.pslist
  python3 -m volatility3 -f compromised-memory.raw windows.pstree
  python3 -m volatility3 -f compromised-memory.raw windows.netscan
  python3 -m volatility3 -f compromised-memory.raw windows.malfind
  python3 -m volatility3 -f compromised-memory.raw windows.cmdline
  python3 -m volatility3 -f compromised-memory.raw windows.filescan

You can also use strings + grep for initial triage:
  strings compromised-memory.raw | grep -i "http"
  strings compromised-memory.raw | grep -iE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b"
  strings compromised-memory.raw | grep -i "password"

Your goal: identify malicious processes, network connections, and IOCs.
EOF

echo "[+] Memory forensics lab setup complete."
