MEMORY FORENSICS LAB - Artifact Kit
=====================================

FILES INCLUDED:
- pslist.txt              : Process listing (Volatility windows.pslist)
- netscan.txt             : Network connections (Volatility windows.netscan)
- malfind.txt             : Injected/suspicious memory regions (Volatility windows.malfind)
- cmdline.txt             : Process command lines (Volatility windows.cmdline)
- dlllist.txt             : DLL listings for suspicious processes
- strings_suspicious.txt  : Suspicious strings extracted from process memory

NOTE: Real memory dumps are 2-8GB. This lab provides pre-extracted Volatility
output so you can practice analysis without needing the full dump.

SCENARIO:
A memory dump was captured from WS-DEV03 on March 19, 2025 at 15:30.
The system was suspected of being compromised. Analyze the Volatility output.

ANALYSIS TASKS:
1. PROCESS ANALYSIS (pslist.txt):
   - Identify suspicious parent-child relationships
   - Find processes running from unusual locations
   - Note processes with abnormal creation times
   - Identify orphaned processes

2. NETWORK ANALYSIS (netscan.txt):
   - Find active connections to external IPs
   - Identify C2 connections (unusual ports, foreign IPs)
   - Find lateral movement connections (internal SMB)

3. CODE INJECTION (malfind.txt):
   - Identify processes with injected code
   - Distinguish real malware from false positives
   - Recognize shellcode patterns (MZ headers, x64 stubs)

4. COMMAND LINE ANALYSIS (cmdline.txt):
   - Find encoded PowerShell commands (decode the base64!)
   - Identify recon commands
   - Find credential dumping tools
   - Trace the execution chain

5. DLL ANALYSIS (dlllist.txt):
   - Find DLLs loaded from unusual paths
   - Identify malicious DLLs (Temp directory)

6. STRING ANALYSIS (strings_suspicious.txt):
   - Extract C2 infrastructure details
   - Find credentials in memory
   - Identify attack tool artifacts
   - Find configuration parameters

SUSPICIOUS PROCESSES TO INVESTIGATE:
- PID 4200 -> 4456 -> 4612 (WINWORD -> cmd -> powershell)
- PID 5100 (svc_update.exe from Temp)
- PID 5900 (debug_tool.exe from Windows\Temp)
- PID 5700 (procdump targeting lsass)
