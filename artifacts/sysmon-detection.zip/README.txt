SYSMON DETECTION LAB - Artifact Kit
=====================================

FILES INCLUDED:
- sysmon_events.json : Sysmon telemetry with embedded attack patterns

SCENARIO:
Workstation WS-DEV03 was compromised via a malicious Word document on March 18, 2025.
Analyze the Sysmon events to trace the full attack chain.

SYSMON EVENT IDs TO KNOW:
- EID 1  : Process Creation (look for suspicious parent-child relationships)
- EID 3  : Network Connection (look for C2 connections on unusual ports)
- EID 11 : File Create (look for drops in Temp/AppData)
- EID 13 : Registry Value Set (look for Run key persistence)
- EID 22 : DNS Query (look for DGA-like domain patterns)

DETECTION CHALLENGES:
1. Find the initial macro execution (Office process spawning cmd/powershell)
2. Identify all C2 IP addresses and ports
3. Find all files dropped by the attacker
4. Locate registry persistence mechanisms
5. Detect DGA domain patterns in DNS queries
6. Identify the C2 beaconing interval pattern
7. Find all reconnaissance commands executed
8. Map the full attack chain to MITRE ATT&CK

SUSPICIOUS INDICATORS:
- WINWORD.EXE should NOT spawn cmd.exe or powershell.exe
- PowerShell with -enc (encoded commands), -nop (no profile), -w hidden
- Network connections to non-standard ports (4444)
- Files created in Temp directories by PowerShell
- Registry Run keys set by PowerShell
- High-entropy domain names (DGA)
- Regular-interval network connections (beaconing)
