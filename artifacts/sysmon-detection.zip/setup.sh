#!/bin/bash
###############################################################################
# setup.sh — Sysmon for Threat Detection lab
#
# Runs ON the lab VM (Ubuntu desktop) after the artifact zip extracts to
# /opt/lab_data. Installs Splunk (scenario recipe), then loads the Sysmon
# telemetry so the trainee browses http://localhost:8000 with everything
# indexed:
#   sysmon_events.json  -> index=sysmon   (sourcetype=Sysmon)
#       EventID 1  process create  (incl. LOLBins / suspicious parent-child)
#       EventID 3  network connection
#       EventID 11 file create
#       EventID 13 registry value set (Run-key persistence)
#       EventID 22 DNS query
#
# The data file is a JSON ARRAY — it's converted to NDJSON (one object per
# line) so Splunk indexes each record as its own event (counts must be exact).
###############################################################################
set -uo pipefail

SPLUNK_URL="${SPLUNK_URL:-https://download.splunk.com/products/splunk/releases/9.3.0/linux/splunk-9.3.0-51ccf43db5bd-Linux-x86_64.tgz}"
SPLUNK_HOME="/opt/splunk"
SPLUNK_PASS="changeme123!"
LAB_DATA="/opt/lab_data"

echo "[*] === Sysmon for Threat Detection lab setup ==="

# ── 1. Install Splunk (scenario recipe) if not present ───────────────────────
if [ ! -x "${SPLUNK_HOME}/bin/splunk" ]; then
    echo "[*] Downloading Splunk: ${SPLUNK_URL##*/}"
    curl -fsSL -o /opt/splunk.tgz "$SPLUNK_URL" || wget -qO /opt/splunk.tgz "$SPLUNK_URL"
    tar xzf /opt/splunk.tgz -C /opt/ && rm -f /opt/splunk.tgz
    echo "OPTIMISTIC_ABOUT_FILE_LOCKING = 1" >> "${SPLUNK_HOME}/etc/splunk-launch.conf"
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt --seed-passwd "$SPLUNK_PASS"
    "${SPLUNK_HOME}/bin/splunk" enable boot-start || true
else
    echo "[+] Splunk already installed"
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" || \
        "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt
fi

for _ in $(seq 1 24); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    sleep 5
done

AUTH="-auth admin:${SPLUNK_PASS}"

# ── 2. Convert JSON arrays -> NDJSON (one event per line) ────────────────────
for f in sysmon_events; do
    if [ -f "${LAB_DATA}/${f}.json" ]; then
        python3 -c "import json;[print(json.dumps(o)) for o in json.load(open('${LAB_DATA}/${f}.json'))]" \
            > "${LAB_DATA}/${f}.ndjson" 2>/dev/null && echo "[+] ${f}.ndjson" || echo "[!] ${f} convert failed"
    fi
done

# ── 3. Create the indexes the lab's queries use ──────────────────────────────
for idx in sysmon; do
    "${SPLUNK_HOME}/bin/splunk" add index "$idx" $AUTH 2>/dev/null || true
done

# ── 4. Field extraction + aliases so material.md field names resolve ─────────
CONF_DIR="${SPLUNK_HOME}/etc/system/local"
mkdir -p "$CONF_DIR"
cat >> "${CONF_DIR}/props.conf" <<'PROPS'
[Sysmon]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT
FIELDALIAS-eventcode = EventID AS EventCode
FIELDALIAS-host      = Computer AS host
FIELDALIAS-dstip     = DestinationIp AS dest_ip
FIELDALIAS-dstport   = DestinationPort AS dest_port
FIELDALIAS-srcip     = SourceIp AS src_ip
FIELDALIAS-process   = Image AS process
PROPS

# ── 5. Inputs: monitor each NDJSON into the right index / sourcetype ─────────
cat > "${CONF_DIR}/inputs.conf" <<INPUTS
[monitor://${LAB_DATA}/sysmon_events.ndjson]
sourcetype = Sysmon
index = sysmon
disabled = false
INPUTS

# ── 6. Restart so inputs/props/indexes take effect ───────────────────────────
"${SPLUNK_HOME}/bin/splunk" restart $AUTH 2>/dev/null || \
    "${SPLUNK_HOME}/bin/splunk" restart --accept-license --answer-yes --no-prompt || true
# ENSURE splunkd is actually up — the restart can race/fail on a slow VM.
for _ in $(seq 1 18); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt 2>/dev/null || true
    sleep 5
done

echo "[+] Sysmon for Threat Detection lab ready — http://localhost:8000  (admin / ${SPLUNK_PASS})"

# Remove this provisioning script so the trainee sees only the lab data, not how it was built.
rm -f /opt/lab_data/setup.sh 2>/dev/null || true
