
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === Sysmon Detection Lab Setup ==="
New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null

# Download and install Sysmon with SwiftOnSecurity config
Write-Host "[*] Downloading Sysmon..."
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12

try {
    Invoke-WebRequest -Uri "https://download.sysinternals.com/files/Sysmon.zip" -OutFile "C:\LabData\Sysmon.zip" -UseBasicParsing
    Expand-Archive -Path "C:\LabData\Sysmon.zip" -DestinationPath "C:\LabData\Sysmon" -Force

    # Download SwiftOnSecurity config
    Invoke-WebRequest -Uri "https://raw.githubusercontent.com/SwiftOnSecurity/sysmon-config/master/sysmonconfig-export.xml" -OutFile "C:\LabData\sysmonconfig.xml" -UseBasicParsing

    # Install Sysmon
    & "C:\LabData\Sysmon\Sysmon64.exe" -accepteula -i "C:\LabData\sysmonconfig.xml" 2>$null
    Write-Host "[+] Sysmon installed with SwiftOnSecurity config"
} catch {
    Write-Host "[-] Sysmon download failed, installing with defaults"
    try { & "C:\LabData\Sysmon\Sysmon64.exe" -accepteula -i 2>$null } catch {}
}

# Generate suspicious activity for Sysmon to capture
Write-Host "[*] Generating attack artifacts..."

$simScript = @'
# Simulate malicious behavior for Sysmon to log

# Event 1: Suspicious process chain (Word -> cmd -> powershell)
Start-Process cmd.exe -ArgumentList "/c echo Simulated macro execution" -Wait

# Event 1: Encoded PowerShell
$enc = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes("Get-Process"))
powershell.exe -EncodedCommand $enc 2>$null

# Event 3: Network connection to external IP (DNS lookup)
try { [System.Net.Dns]::GetHostAddresses("evil-domain.com") } catch {}
try { Invoke-WebRequest -Uri "http://httpbin.org/get" -UseBasicParsing -TimeoutSec 3 } catch {}

# Event 11: File creation in temp/public
$suspPath = "$env:PUBLIC\updater.exe"
"MZ-fake-binary" | Set-Content -Path $suspPath
Start-Sleep -Seconds 2
Remove-Item $suspPath -Force 2>$null

# Event 13: Registry Run key
$runKey = "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
Set-ItemProperty -Path $runKey -Name "LabTest_SystemUpdate" -Value "C:\Users\Public\updater.exe" 2>$null
Start-Sleep -Seconds 2
Remove-ItemProperty -Path $runKey -Name "LabTest_SystemUpdate" 2>$null

# Event 22: DNS query (suspicious domains)
try { Resolve-DnsName "c2-beacon.evil-domain.com" -ErrorAction SilentlyContinue } catch {}
try { Resolve-DnsName "data-exfil.evil-corp.net" -ErrorAction SilentlyContinue } catch {}

Write-Host "[+] Sysmon simulation complete"
'@

Set-Content -Path "C:\LabData\simulate_sysmon.ps1" -Value $simScript
& powershell.exe -ExecutionPolicy Bypass -File "C:\LabData\simulate_sysmon.ps1" 2>$null
Start-Sleep -Seconds 5

# Export Sysmon events
wevtutil epl "Microsoft-Windows-Sysmon/Operational" "C:\LabData\Sysmon-Events.evtx" 2>$null

@"
=== Sysmon for Threat Detection Lab ===

Sysmon is LIVE and logging to: Microsoft-Windows-Sysmon/Operational
Exported copy: C:\LabData\Sysmon-Events.evtx

Key Sysmon Event IDs:
  1  - Process Creation (parent, image, command line, hashes)
  3  - Network Connection (source/dest IP, port, process)
  11 - File Create (target filename, process)
  13 - Registry Value Set (key, value, process)
  22 - DNS Query (queried domain, process)

PowerShell analysis:
  Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -MaxEvents 100 | Format-Table TimeCreated, Id, Message -Wrap
  Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -FilterHashtable @{Id=1} | Select -First 20
  Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -FilterHashtable @{Id=3} | Select -First 10
  Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -FilterHashtable @{Id=13} | Select -First 10

Re-run simulation: C:\LabData\simulate_sysmon.ps1
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] Sysmon Detection lab ready."
