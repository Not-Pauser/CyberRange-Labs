
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up Sysmon Detection lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null
$logPath = "C:\LabData"

# Download and install Sysmon
Write-Host "[*] Downloading Sysmon..."
[Net.ServicePointManager]::SecurityProtocol = [Net.SecurityProtocolType]::Tls12
try {
    Invoke-WebRequest -Uri "https://download.sysinternals.com/files/Sysmon.zip" -OutFile "$logPath\Sysmon.zip" -UseBasicParsing
    Expand-Archive -Path "$logPath\Sysmon.zip" -DestinationPath "$logPath\Sysmon" -Force
    # Install Sysmon with default config
    & "$logPath\Sysmon\Sysmon64.exe" -accepteula -i 2>$null
    Write-Host "[+] Sysmon installed"
} catch {
    Write-Host "[-] Sysmon download failed, using synthetic data only"
}

# Generate Sysmon-style events as CSV
$script = @'
$logPath = "C:\LabData"
$events = @()
$base = (Get-Date).AddHours(-3)

# Event 1: Process Creation
$procs = @(
    @{Time=$base.AddMinutes(5); Parent="explorer.exe"; Image="chrome.exe"; Cmd="chrome.exe --new-window"},
    @{Time=$base.AddMinutes(10); Parent="explorer.exe"; Image="outlook.exe"; Cmd="outlook.exe"},
    @{Time=$base.AddMinutes(30); Parent="winword.exe"; Image="cmd.exe"; Cmd="cmd.exe /c whoami"},
    @{Time=$base.AddMinutes(31); Parent="cmd.exe"; Image="powershell.exe"; Cmd="powershell.exe -enc aQBwAGMAbwBuAGYAaQBnAA=="},
    @{Time=$base.AddMinutes(35); Parent="powershell.exe"; Image="updater.exe"; Cmd="C:\Users\Public\updater.exe"},
    @{Time=$base.AddMinutes(40); Parent="services.exe"; Image="svchost.exe"; Cmd="svchost.exe -k netsvcs"}
)
foreach ($p in $procs) {
    $events += [PSCustomObject]@{EventID=1; Time=$p.Time; ParentImage=$p.Parent; Image=$p.Image; CommandLine=$p.Cmd}
}

# Event 3: Network Connection
$nets = @(
    @{Time=$base.AddMinutes(32); Image="powershell.exe"; DstIP="185.220.101.42"; DstPort=443},
    @{Time=$base.AddMinutes(33); Image="powershell.exe"; DstIP="185.220.101.42"; DstPort=443},
    @{Time=$base.AddMinutes(36); Image="updater.exe"; DstIP="185.220.101.42"; DstPort=8443},
    @{Time=$base.AddMinutes(37); Image="updater.exe"; DstIP="185.220.101.42"; DstPort=8443},
    @{Time=$base.AddMinutes(50); Image="chrome.exe"; DstIP="142.250.80.46"; DstPort=443}
)
foreach ($n in $nets) {
    $events += [PSCustomObject]@{EventID=3; Time=$n.Time; ParentImage=""; Image=$n.Image; CommandLine="$($n.DstIP):$($n.DstPort)"}
}

# Event 11: File Create
$files = @(
    @{Time=$base.AddMinutes(34); Image="powershell.exe"; Target="C:\Users\Public\updater.exe"},
    @{Time=$base.AddMinutes(35); Image="updater.exe"; Target="C:\Users\localuser\AppData\Local\Temp\payload.dll"},
    @{Time=$base.AddMinutes(38); Image="updater.exe"; Target="C:\Windows\Temp\data.zip"}
)
foreach ($f in $files) {
    $events += [PSCustomObject]@{EventID=11; Time=$f.Time; ParentImage=""; Image=$f.Image; CommandLine=$f.Target}
}

# Event 13: Registry modification
$regs = @(
    @{Time=$base.AddMinutes(36); Image="updater.exe"; Target="HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run\SystemUpdate = C:\Users\Public\updater.exe"}
)
foreach ($r in $regs) {
    $events += [PSCustomObject]@{EventID=13; Time=$r.Time; ParentImage=""; Image=$r.Image; CommandLine=$r.Target}
}

# Event 22: DNS Query
$dns = @(
    @{Time=$base.AddMinutes(31); Image="powershell.exe"; Target="c2.evil-domain.com"},
    @{Time=$base.AddMinutes(35); Image="updater.exe"; Target="update-service.evil-corp.com"},
    @{Time=$base.AddMinutes(40); Image="chrome.exe"; Target="www.google.com"}
)
foreach ($d in $dns) {
    $events += [PSCustomObject]@{EventID=22; Time=$d.Time; ParentImage=""; Image=$d.Image; CommandLine=$d.Target}
}

$events | Sort-Object Time | Export-Csv -Path "$logPath\sysmon_events.csv" -NoTypeInformation
Write-Host "[+] Generated $(($events).Count) Sysmon events"
'@

Set-Content -Path "$logPath\generate_sysmon.ps1" -Value $script
& powershell.exe -ExecutionPolicy Bypass -File "$logPath\generate_sysmon.ps1"

@"
=== Sysmon for Threat Detection Lab ===

Files:
  sysmon_events.csv         - Simulated Sysmon events
  generate_sysmon.ps1       - Event generation script

Sysmon Event IDs:
  1  - Process Creation (parent, image, commandline)
  3  - Network Connection (process, destination IP/port)
  11 - File Create (process that created, target path)
  13 - Registry Modification (process, key/value)
  22 - DNS Query (process, queried domain)

Analysis:
  Import-Csv C:\LabData\sysmon_events.csv | Where-Object {`$_.EventID -eq 1} | Format-Table
  Import-Csv C:\LabData\sysmon_events.csv | Where-Object {`$_.EventID -eq 3} | Format-Table
  Import-Csv C:\LabData\sysmon_events.csv | Where-Object {`$_.CommandLine -like "*185*"} | Format-Table

Also check live Sysmon logs (if Sysmon installed):
  Get-WinEvent -LogName "Microsoft-Windows-Sysmon/Operational" -MaxEvents 50

Your goal: Trace the attack chain from initial execution to persistence.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] Sysmon Detection lab setup complete."
