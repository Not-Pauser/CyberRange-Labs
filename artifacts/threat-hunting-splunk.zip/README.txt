THREAT HUNTING WITH SPLUNK LAB - Artifact Kit
===============================================

FILES INCLUDED:
- windows_security.json : 3 days of Windows Security events (~4000)
- sysmon_events.json    : 3 days of Sysmon events (~3000)
- dns_queries.json      : 3 days of DNS query logs (~5000)
- hunting_templates.txt : Splunk SPL query templates to get started

SCENARIO:
No alerts have fired. No incidents have been reported. But intelligence
suggests your organization may be compromised. You have 3 days of log
data. Hunt for threats hiding in the noise.

HIDDEN THREATS TO FIND (do NOT read until after hunting!):
This section is the answer key - try hunting first!

SPOILER WARNING - THREATS EMBEDDED IN THE DATA:
1. LATERAL MOVEMENT: Pass-the-hash from 10.0.3.25 to multiple servers
   (2-4 AM, Type 3 NTLM logons as administrator)

2. PERSISTENCE: Service account 'svc_maint' with RDP access
   (Type 10 logons at unusual hours, running recon commands)

3. C2 BEACONING: Regular ~5 minute connections from WS-DEV03 to
   185.220.101.33:443 via process updater.exe in ProgramData

4. DNS EXFILTRATION: Long encoded TXT queries from 10.0.3.25
   to *.data.cdn-update-service.xyz

5. DGA ACTIVITY: NXDOMAIN responses for random-looking domains
   from 10.0.3.25

6. PASSWORD SPRAY: Single source attempting 8 accounts in 2 minutes
   on day 2 at 22:00

HUNTING METHODOLOGY:
1. Start with the templates in hunting_templates.txt
2. Look for statistical outliers (rare events, unusual volumes)
3. Check for temporal anomalies (off-hours activity)
4. Investigate any host that appears in multiple hunts
5. Document the full attack narrative with evidence
