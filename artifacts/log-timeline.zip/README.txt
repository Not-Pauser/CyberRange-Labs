LOG TIMELINE CORRELATION LAB - Artifact Kit
=============================================

FILES INCLUDED:
- apache_access.log      : Web server access logs (3000+ entries)
- windows_security.json  : Domain controller security events (2000+)
- sysmon.json            : Sysmon events from multiple hosts (800+)
- auth.log               : Linux SSH authentication log (600+)

SCENARIO:
A multi-stage attack occurred on March 21, 2025. The attacker compromised
the DMZ web server, pivoted to internal systems, and exfiltrated data.
ALL log sources share the same attacker: IP 198.51.100.42

CRITICAL EXERCISE:
Build a unified timeline by correlating events across ALL FOUR log sources.
The attack spans: Web logs -> Linux auth -> Windows security -> Sysmon

ATTACK CHAIN TO RECONSTRUCT:
1. 10:15 - Web reconnaissance/scanning (apache_access.log)
2. 10:30 - SQL injection exploitation (apache_access.log)
3. 10:45 - Web shell upload and access (apache_access.log + auth.log)
4. 11:00 - Pivot: SSH from web server to internal (auth.log)
5. 11:05 - SSH brute force on internal host (auth.log)
6. 11:15 - Brute force on Domain Controller (windows_security.json)
7. 11:30 - Admin access gained on DC (windows_security.json)
8. 11:35 - Account creation for persistence (windows_security.json)
9. 11:45 - Credential dumping (windows_security.json + sysmon.json)
10. 12:00 - Lateral movement via SMB (sysmon.json)
11. 12:15 - C2 beaconing established (sysmon.json)
12. 12:45 - Audit log cleared (windows_security.json)

CORRELATION TASKS:
1. Identify the SAME attacker IP across web logs and auth logs
2. Track the pivot from DMZ to internal network
3. Correlate Linux SSH events with Windows logon events
4. Match Sysmon network connections with authentication events
5. Build a complete timeline with timestamps from all sources
6. Identify ALL compromised systems

TIPS:
- Sort all events by timestamp for a unified view
- The web server IP appears as source in Windows logs (pivot)
- Look for lateral movement paths: External -> DMZ -> Internal -> DC
- Map each attack step to MITRE ATT&CK techniques
