#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === Log Timeline Reconstruction Lab Setup ==="

apt-get update -qq
apt-get install -y -qq python3 jq > /dev/null 2>&1

mkdir -p /opt/lab_data/timeline
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/timeline

echo "[*] Generating multi-source correlated attack logs..."
python3 << 'PYEOF'
import random, datetime

random.seed(42)
attacker = "203.0.113.77"
ws25 = "10.0.1.25"
dc = "10.0.2.10"
fs = "10.0.2.20"
web = "10.0.3.5"

# Attack timeline anchors (UTC)
T0 = datetime.datetime(2026, 3, 18, 9, 15, 0)   # Initial access
T1 = T0 + datetime.timedelta(minutes=5)           # Recon
T2 = T0 + datetime.timedelta(minutes=12)           # Lateral to DC
T3 = T0 + datetime.timedelta(minutes=18)           # Lateral to FS
T4 = T0 + datetime.timedelta(minutes=25)           # Data access
T5 = T0 + datetime.timedelta(minutes=35)           # Persistence
T6 = T0 + datetime.timedelta(minutes=45)           # Exfiltration

# === Windows Security Events (XML-like structured format) ===
with open("windows-security.evtx.txt", "w") as f:
    f.write("TimeCreated(UTC)|EventID|Computer|Account|SourceIP|LogonType|Details\n")
    # Background normal logons
    for i in range(80):
        t = T0 - datetime.timedelta(hours=random.randint(1,48))
        user = random.choice(["jsmith","mwilson","agarcia","blee"])
        host = f"WS-{random.randint(10,30)}"
        f.write(f"{t.isoformat()}Z|4624|{host}|{user}|10.0.1.{random.randint(10,50)}|2|Interactive logon\n")

    # Brute force (T0 - 2min to T0)
    t = T0 - datetime.timedelta(minutes=2)
    for i in range(18):
        t += datetime.timedelta(seconds=random.randint(2,8))
        f.write(f"{t.isoformat()}Z|4625|WS-25|administrator|{attacker}|3|Bad password - attempt {i+1}\n")
    # Success
    f.write(f"{T0.isoformat()}Z|4624|WS-25|administrator|{attacker}|3|Network logon - brute force success\n")

    # Recon (T1)
    f.write(f"{T1.isoformat()}Z|4688|WS-25|administrator||0|Process: cmd.exe -> net user /domain\n")
    f.write(f"{(T1+datetime.timedelta(seconds=15)).isoformat()}Z|4688|WS-25|administrator||0|Process: cmd.exe -> net group \"Domain Admins\" /domain\n")
    f.write(f"{(T1+datetime.timedelta(seconds=30)).isoformat()}Z|4688|WS-25|administrator||0|Process: cmd.exe -> nltest /dclist:corp.local\n")

    # Lateral to DC (T2)
    f.write(f"{T2.isoformat()}Z|4648|WS-25|administrator|{ws25}|0|Explicit credentials used to access DC-01\n")
    f.write(f"{T2.isoformat()}Z|4624|DC-01|administrator|{ws25}|3|Network logon from WS-25\n")

    # Lateral to FS (T3)
    f.write(f"{T3.isoformat()}Z|4624|FS-01|administrator|{ws25}|3|Network logon from WS-25\n")

    # File access (T4)
    for fname in ["Q1-Revenue.xlsx","Employee-SSN.csv","Project-Roadmap.docx","API-Keys.txt","VPN-Configs.zip"]:
        t = T4 + datetime.timedelta(seconds=random.randint(5,60))
        f.write(f"{t.isoformat()}Z|4663|FS-01|administrator|{ws25}|0|ReadData: \\\\FS-01\\Sensitive$\\{fname}\n")

    # Persistence (T5)
    f.write(f"{T5.isoformat()}Z|4720|DC-01|administrator|{ws25}|0|Account created: svc_backup\n")
    f.write(f"{(T5+datetime.timedelta(seconds=5)).isoformat()}Z|4728|DC-01|administrator|{ws25}|0|Added svc_backup to Domain Admins\n")
    f.write(f"{(T5+datetime.timedelta(seconds=10)).isoformat()}Z|4698|WS-25|administrator||0|Scheduled task created: \\Microsoft\\Windows\\SystemUpdate\n")

    # Log clearing attempt (T6 + 10min)
    tc = T6 + datetime.timedelta(minutes=10)
    f.write(f"{tc.isoformat()}Z|1102|WS-25|administrator||0|Security audit log was cleared\n")

# === Sysmon Events ===
with open("sysmon-events.evtx.txt", "w") as f:
    f.write("TimeCreated(UTC)|EventID|Computer|Image|CommandLine|ParentImage|DestIP|DestPort\n")
    # Normal
    for i in range(40):
        t = T0 - datetime.timedelta(minutes=random.randint(10,120))
        proc = random.choice(["chrome.exe","outlook.exe","explorer.exe","teams.exe"])
        f.write(f"{t.isoformat()}Z|1|WS-25|{proc}|{proc}|explorer.exe||\n")

    # Attack chain
    f.write(f"{T1.isoformat()}Z|1|WS-25|cmd.exe|cmd.exe /c whoami|winword.exe||\n")
    f.write(f"{(T1+datetime.timedelta(seconds=5)).isoformat()}Z|1|WS-25|powershell.exe|powershell.exe -enc aQBwAGMAbwBuAGYAaQBnAA==|cmd.exe||\n")
    f.write(f"{(T1+datetime.timedelta(seconds=20)).isoformat()}Z|3|WS-25|powershell.exe||cmd.exe|{attacker}|8080\n")
    f.write(f"{(T1+datetime.timedelta(seconds=25)).isoformat()}Z|11|WS-25|powershell.exe|C:\\Users\\Public\\updater.exe|cmd.exe||\n")
    f.write(f"{(T1+datetime.timedelta(seconds=30)).isoformat()}Z|1|WS-25|updater.exe|C:\\Users\\Public\\updater.exe --persist|powershell.exe||\n")
    f.write(f"{(T1+datetime.timedelta(seconds=35)).isoformat()}Z|13|WS-25|updater.exe|HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemUpdate = C:\\Users\\Public\\updater.exe|updater.exe||\n")
    f.write(f"{(T1+datetime.timedelta(seconds=40)).isoformat()}Z|22|WS-25|updater.exe|update-service.evil-corp.com|updater.exe||\n")

    # C2 beaconing
    for i in range(20):
        t = T2 + datetime.timedelta(seconds=60*i)
        f.write(f"{t.isoformat()}Z|3|WS-25|updater.exe||updater.exe|185.220.101.42|8443\n")

# === Apache Access Log (web server) ===
with open("apache-access.log", "w") as f:
    for i in range(400):
        t = T0 - datetime.timedelta(hours=random.randint(0,24))
        src = f"10.0.1.{random.randint(10,50)}"
        url = random.choice(["/","/login","/dashboard","/api/users","/static/css/app.css"])
        f.write(f'{src} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET {url} HTTP/1.1" {random.choice([200,200,304])} {random.randint(200,5000)}\n')

    # Web shell upload + commands
    t = T0 + datetime.timedelta(minutes=8)
    f.write(f'{attacker} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "POST /upload.php HTTP/1.1" 200 84\n')
    for i, cmd in enumerate(["whoami","ipconfig","net+user","dir+C:\\","systeminfo","net+view"]):
        tc = t + datetime.timedelta(minutes=i+1)
        f.write(f'{attacker} - - [{tc.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET /uploads/cmd.php?c={cmd} HTTP/1.1" 200 {random.randint(100,2000)}\n')

# === Linux Auth Log ===
with open("linux-auth.log", "w") as f:
    for i in range(200):
        t = T0 - datetime.timedelta(hours=random.randint(0,48))
        user = random.choice(["sysadmin","deploy","monitor"])
        f.write(f'{t.strftime("%b %d %H:%M:%S")} web-srv sshd[{random.randint(1000,9999)}]: Accepted publickey for {user} from 10.0.1.{random.randint(10,50)} port {random.randint(49000,65000)} ssh2\n')

    # Attacker SSH brute force
    t = T0 + datetime.timedelta(minutes=20)
    for i in range(10):
        t += datetime.timedelta(seconds=random.randint(1,3))
        f.write(f'{t.strftime("%b %d %H:%M:%S")} web-srv sshd[{random.randint(1000,9999)}]: Failed password for root from {attacker} port {random.randint(49000,65000)} ssh2\n')
    t += datetime.timedelta(seconds=5)
    f.write(f'{t.strftime("%b %d %H:%M:%S")} web-srv sshd[{random.randint(1000,9999)}]: Accepted password for root from {attacker} port {random.randint(49000,65000)} ssh2\n')

print("Generated windows-security.evtx.txt, sysmon-events.evtx.txt, apache-access.log, linux-auth.log")
PYEOF

cat > /opt/lab_data/timeline/README.txt << 'EOF'
=== Log Timeline Reconstruction Lab ===

Log sources (4 systems, 4 formats):
  windows-security.evtx.txt  - Windows Security events (pipe-delimited, UTC)
  sysmon-events.evtx.txt     - Sysmon events (pipe-delimited, UTC)
  apache-access.log           - Apache Combined Log Format (UTC+0)
  linux-auth.log              - Linux auth.log (syslog format)

Attack timeline to reconstruct:
  1. External brute force -> successful logon
  2. Reconnaissance commands
  3. Lateral movement to Domain Controller
  4. Lateral movement to File Server
  5. Sensitive file access
  6. Persistence (new account + scheduled task)
  7. Data exfiltration
  8. Anti-forensics (log clearing)

Key IPs:
  203.0.113.77  - External attacker
  10.0.1.25     - Compromised workstation (WS-25)
  10.0.2.10     - Domain Controller (DC-01)
  10.0.2.20     - File Server (FS-01)
  10.0.3.5      - Web Server (web-srv)
EOF

echo "[+] Log timeline reconstruction lab ready."
