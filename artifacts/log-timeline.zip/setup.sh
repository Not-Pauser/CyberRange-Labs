#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing tools..."
apt-get update -qq
apt-get install -y -qq python3 jq > /dev/null 2>&1

mkdir -p /opt/lab_data
cd /opt/lab_data

echo "[*] Generating multi-source log data..."
python3 << 'PYEOF'
import random, datetime

random.seed(42)
# Attack timeline: initial access -> recon -> lateral movement -> data access -> exfiltration
attacker_ip = "203.0.113.77"
victim1 = "10.0.1.25"
victim2 = "10.0.1.30"
dc = "10.0.2.10"
fileserver = "10.0.2.20"

base = datetime.datetime(2026, 3, 18, 9, 0, 0)

# Windows Security events (XML-like format)
with open("windows_security.log", "w") as f:
    f.write("timestamp|event_id|computer|account|src_ip|logon_type|status|details\n")
    # Normal logons before attack
    for i in range(100):
        ts = base - datetime.timedelta(hours=random.randint(1, 48))
        user = random.choice(["jsmith", "mwilson", "agarcia", "blee"])
        f.write(f"{ts.isoformat()}|4624|WS-{random.randint(10,30)}|{user}|10.0.1.{random.randint(10,50)}|2|Success|Interactive logon\n")

    # Attack begins: brute force
    t = base
    for i in range(15):
        t += datetime.timedelta(seconds=random.randint(1, 5))
        f.write(f"{t.isoformat()}|4625|WS-25|administrator|{attacker_ip}|3|Failure|Bad password\n")

    # Successful logon
    t += datetime.timedelta(seconds=30)
    f.write(f"{t.isoformat()}|4624|WS-25|administrator|{attacker_ip}|3|Success|Network logon\n")

    # Recon commands
    t += datetime.timedelta(minutes=2)
    f.write(f"{t.isoformat()}|4688|WS-25|administrator|{victim1}|0|Success|net user /domain\n")
    t += datetime.timedelta(seconds=15)
    f.write(f"{t.isoformat()}|4688|WS-25|administrator|{victim1}|0|Success|net group \"Domain Admins\" /domain\n")

    # Lateral movement to DC
    t += datetime.timedelta(minutes=5)
    f.write(f"{t.isoformat()}|4624|DC-01|administrator|{victim1}|3|Success|Network logon from WS-25\n")
    f.write(f"{t.isoformat()}|4648|WS-25|administrator|{victim1}|0|Success|Explicit credential to DC-01\n")

    # Lateral movement to file server
    t += datetime.timedelta(minutes=3)
    f.write(f"{t.isoformat()}|4624|FS-01|administrator|{victim1}|3|Success|Network logon from WS-25\n")

    # File access
    t += datetime.timedelta(minutes=1)
    for fname in ["Q1-Revenue.xlsx", "Employee-SSN.csv", "Project-Roadmap.docx", "API-Keys.txt"]:
        t += datetime.timedelta(seconds=random.randint(5, 30))
        f.write(f"{t.isoformat()}|4663|FS-01|administrator|{victim1}|0|Success|ReadData: \\\\FS-01\\Sensitive\\{fname}\n")

    # Account creation (persistence)
    t += datetime.timedelta(minutes=10)
    f.write(f"{t.isoformat()}|4720|DC-01|administrator|{victim1}|0|Success|Created user: svc_backup\n")
    f.write(f"{t.isoformat()}|4728|DC-01|administrator|{victim1}|0|Success|Added svc_backup to Domain Admins\n")

# Apache access log
with open("apache_access.log", "w") as f:
    t = base - datetime.timedelta(hours=2)
    for i in range(500):
        t += datetime.timedelta(seconds=random.randint(1, 30))
        src = f"10.0.1.{random.randint(10, 50)}"
        url = random.choice(["/", "/login", "/dashboard", "/api/users", "/static/css/app.css"])
        status = random.choice([200, 200, 200, 304])
        f.write(f'{src} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET {url} HTTP/1.1" {status} {random.randint(200,5000)}\n')

    # Attack: web shell upload
    t = base + datetime.timedelta(minutes=30)
    f.write(f'{attacker_ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "POST /upload.php HTTP/1.1" 200 84\n')
    for i in range(10):
        t += datetime.timedelta(minutes=random.randint(1, 5))
        cmd = random.choice(["whoami", "ipconfig", "net+user", "dir+C:\\", "type+C:\\flag.txt"])
        f.write(f'{attacker_ip} - - [{t.strftime("%d/%b/%Y:%H:%M:%S +0000")}] "GET /uploads/shell.php?cmd={cmd} HTTP/1.1" 200 {random.randint(100,2000)}\n')

# Sysmon-style network events
with open("sysmon_network.log", "w") as f:
    f.write("timestamp|event_id|process|src_ip|src_port|dst_ip|dst_port|proto\n")
    t = base
    for i in range(200):
        t += datetime.timedelta(seconds=random.randint(1, 60))
        proc = random.choice(["chrome.exe", "outlook.exe", "teams.exe", "svchost.exe"])
        f.write(f"{t.isoformat()}|3|{proc}|{victim1}|{random.randint(49000,65000)}|{random.choice(['93.184.216.34','13.107.6.152'])}|443|TCP\n")

    # Suspicious: powershell connecting to C2
    t = base + datetime.timedelta(minutes=15)
    for i in range(20):
        t += datetime.timedelta(seconds=60)
        f.write(f"{t.isoformat()}|3|powershell.exe|{victim1}|{random.randint(49000,65000)}|{attacker_ip}|443|TCP\n")

    # Data exfiltration: large transfers
    t = base + datetime.timedelta(minutes=45)
    for i in range(5):
        t += datetime.timedelta(seconds=random.randint(10, 60))
        f.write(f"{t.isoformat()}|3|powershell.exe|{victim1}|{random.randint(49000,65000)}|{attacker_ip}|443|TCP\n")

print("Generated windows_security.log, apache_access.log, sysmon_network.log")
PYEOF

cat > /opt/lab_data/README.txt << 'EOF'
=== Log Timeline Reconstruction Lab ===

Files:
  windows_security.log  - Windows Security events (pipe-delimited)
  apache_access.log     - Apache HTTP access log (Common Log Format)
  sysmon_network.log    - Sysmon network connection events (pipe-delimited)

Analysis tips:
  # Find first suspicious event
  grep "4625\|Failure" windows_security.log | head -5

  # Trace lateral movement
  grep "4624" windows_security.log | grep "10.0.1.25"

  # Find web shell activity
  grep "shell.php" apache_access.log

  # Correlate network connections with attacker IP
  grep "203.0.113.77" sysmon_network.log

Your goal: Build a complete attack timeline with timestamps and MITRE ATT&CK mappings.
EOF

echo "[+] Log timeline reconstruction lab setup complete."
