IOC CORRELATION LAB - Artifact Kit
====================================

FILES INCLUDED:
- network_report.txt    : Network security team's IDS/flow analysis
- firewall.log          : 800 firewall log entries
- phishing_email.eml    : Original phishing email
- malware_analysis.txt  : Malware reverse engineering report
- host_events.json      : 500 endpoint detection events
- ioc_template.csv      : Template for IOC documentation

SCENARIO:
Multiple teams have contributed evidence from an incident on March 22, 2025.
Your job is to correlate ALL indicators across ALL sources and build a
comprehensive IOC list that can be used for:
- Blocking/detection rules
- Threat hunting across the enterprise
- Sharing with ISACs and threat intel partners

CORRELATION TASKS:
1. Extract IOCs from EACH evidence source independently
2. Cross-reference IOCs across sources (which appear in multiple?)
3. Identify IOCs that appear in only ONE source (gaps in detection)
4. Determine confidence level for each IOC
5. Map IOCs to the attack kill chain / MITRE ATT&CK
6. Fill out the ioc_template.csv with ALL findings

IOC CATEGORIES TO FIND:
- IP Addresses (attacker, C2 servers)
- Domains (phishing, C2)
- URLs (payload download, C2 endpoints)
- File Hashes (malware, dropper)
- Email Addresses (phishing sender)
- File Names (malware names)
- Registry Keys (persistence)
- User-Agent strings
- JA3 Hashes
- DNS patterns

CORRELATION MATRIX:
Create a matrix showing which IOC appears in which source:
                    network  firewall  email  malware  host
IP 198.51.100.42   [  ]     [  ]      [  ]   [  ]     [  ]
IP 185.220.101.33        [  ]     [  ]      [  ]   [  ]     [  ]
...

DELIVERABLES:
1. Completed ioc_template.csv
2. Correlation matrix
3. Confidence assessment for each IOC
4. Recommended blocking actions
5. Threat intelligence summary (1 page)
