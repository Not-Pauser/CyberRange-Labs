#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === IOC Correlation Lab Setup ==="

apt-get update -qq
apt-get install -y -qq python3 python3-pip tshark jq > /dev/null 2>&1

mkdir -p /opt/lab_data/evidence
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data

echo "[*] Generating multi-source evidence..."
python3 << 'PYEOF'
import random, datetime, hashlib, os, struct, socket, json, base64

random.seed(42)
infra = {"c2": "185.220.101.42", "phish_srv": "198.51.100.55",
         "c2_domain": "update-service.evil-corp.com", "phish_domain": "hr-portal-update.com",
         "exfil_domain": "data-sync.evil-corp.com"}

# === Phishing email (.eml with full MIME) ===
with open("phishing-email.eml", "w") as f:
    f.write(f"""Return-Path: <no-reply@{infra['phish_domain']}>
Received: from smtp.{infra['phish_domain']} ({infra['phish_srv']})
        by mail.corp.local (10.0.2.5) with SMTP id a1b2c3;
        Mon, 18 Mar 2026 08:42:15 +0000
Received: from [{infra['phish_srv']}] (unknown [{infra['phish_srv']}])
        by smtp.{infra['phish_domain']} with ESMTP;
        Mon, 18 Mar 2026 08:42:00 +0000
From: "HR Benefits Team" <benefits@{infra['phish_domain']}>
Reply-To: support@{infra['exfil_domain']}
To: all-staff@corp.local
Subject: Urgent: Benefits Enrollment - Action Required Within 24 Hours
Date: Mon, 18 Mar 2026 08:42:00 +0000
MIME-Version: 1.0
Message-ID: <{random.randint(100000,999999)}@{infra['phish_domain']}>
X-Mailer: PHPMailer 6.8.0
Authentication-Results: mail.corp.local;
    spf=fail (sender IP {infra['phish_srv']} not authorized for {infra['phish_domain']});
    dkim=fail (no DKIM signature);
    dmarc=fail
Content-Type: multipart/mixed; boundary="----=_MIMEBoundary_001"

------=_MIMEBoundary_001
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: 7bit

<html><body>
<p>Dear Employee,</p>
<p>Your benefits enrollment requires immediate update.
<a href="http://{infra['phish_domain']}/enroll?id=28475&token=a8f3e2">Click here to update</a></p>
<p>Best regards,<br>HR Department</p>
</body></html>

------=_MIMEBoundary_001
Content-Type: application/octet-stream; name="Benefits_Form_2026.xls"
Content-Disposition: attachment; filename="Benefits_Form_2026.xls"
Content-Transfer-Encoding: base64
Content-Description: Benefits enrollment form

TVqQAAMAAAAEAAAA//8AALgAAAAAAAA=
------=_MIMEBoundary_001--
""")

# === Evidence PCAP ===
def pcap_hdr():
    return struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1)
def eth():
    return b"\x66\x77\x88\x99\xaa\xbb\x00\x11\x22\x33\x44\x55" + struct.pack("!H", 0x0800)
def iphdr(s, d, p, pl):
    h = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20+pl, random.randint(1,65535), 0x4000, 64, p, 0,
                    socket.inet_aton(s), socket.inet_aton(d))
    cs = sum(struct.unpack("!10H", h)); cs = (cs>>16)+(cs&0xffff); cs = ~cs & 0xffff
    return h[:10] + struct.pack("!H", cs) + h[12:]

with open("evidence/network-capture.pcap", "wb") as f:
    f.write(pcap_hdr())
    ts = 1711000000
    victim = "10.0.1.25"
    for i in range(50):
        ts += random.randint(1,10)
        h = f"GET / HTTP/1.1\r\nHost: www.example.com\r\nUser-Agent: Mozilla/5.0 Chrome/120\r\n\r\n".encode()
        tcp = struct.pack("!HHIIHHH", random.randint(49000,65000), 80, random.randint(1,2**31), 0, (5<<12)|0x18, 65535, 0) + b"\x00\x00" + h
        p = eth() + iphdr(victim, "93.184.216.34", 6, len(tcp)) + tcp
        f.write(struct.pack("<IIII", ts, 0, len(p), len(p)) + p)

    for i in range(30):
        ts += 60
        h = f"GET /beacon?id=A3F2&s={i} HTTP/1.1\r\nHost: {infra['c2_domain']}\r\nUser-Agent: Mozilla/4.0 CobaltStrike/4.8\r\n\r\n".encode()
        tcp = struct.pack("!HHIIHHH", random.randint(49000,65000), 443, random.randint(1,2**31), 0, (5<<12)|0x18, 65535, 0) + b"\x00\x00" + h
        p = eth() + iphdr(victim, infra['c2'], 6, len(tcp)) + tcp
        f.write(struct.pack("<IIII", ts, 0, len(p), len(p)) + p)

# === Suspicious binary files ===
pe_data = b"MZ\x90\x00" + b"\x00" * 56 + struct.pack("<I", 0x80) + b"\x00" * 24
pe_data += b"PE\x00\x00\x4C\x01" + b"\x00" * 200
pe_data += f"http://{infra['c2_domain']}/c2\x00".encode()
pe_data += b"CreateRemoteThread\x00VirtualAllocEx\x00"
pe_data += os.urandom(4096)
with open("evidence/updater.exe", "wb") as f: f.write(pe_data)

doc_data = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1" + b"\x00" * 500
doc_data += b"Sub AutoOpen()\x00Shell(\"powershell -enc ...\")\x00"
doc_data += os.urandom(2048)
with open("evidence/Benefits_Form_2026.xls", "wb") as f: f.write(doc_data)

# === File hashes ===
hashes = {}
for fn in ["updater.exe", "Benefits_Form_2026.xls"]:
    data = open(f"evidence/{fn}", "rb").read()
    hashes[fn] = {"md5": hashlib.md5(data).hexdigest(), "sha256": hashlib.sha256(data).hexdigest(), "size": len(data)}
with open("evidence/file-hashes.json", "w") as f:
    json.dump(hashes, f, indent=2)

# === DNS resolution log ===
with open("evidence/dns-resolutions.log", "w") as f:
    base = datetime.datetime(2026, 3, 18, 8, 0, 0)
    for i in range(200):
        t = base + datetime.timedelta(seconds=random.randint(0, 36000))
        domain = random.choice(["www.google.com","outlook.office365.com",
                                infra['phish_domain'], infra['c2_domain'], infra['exfil_domain']])
        rip = infra['c2'] if "evil" in domain or "portal" in domain else f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        f.write(f'{t.strftime("%b %d %H:%M:%S")} dns-srv named[1234]: client 10.0.1.{random.randint(10,50)}#'
                f'{random.randint(49000,65000)}: query: {domain} IN A + ({rip})\n')

print("Generated all IOC correlation evidence")
PYEOF

cat > /opt/lab_data/README.txt << 'EOF'
=== IOC Extraction & Indicator Correlation Lab ===

Evidence:
  phishing-email.eml               - Original phishing email
  evidence/network-capture.pcap    - Network traffic from compromised host
  evidence/updater.exe             - Suspicious binary found on host
  evidence/Benefits_Form_2026.xls  - Malicious attachment from email
  evidence/file-hashes.json        - Pre-computed hashes
  evidence/dns-resolutions.log     - DNS server query log

Analysis:
  # Email IOCs
  grep -E "Return-Path|From|Reply-To|Received|spf=|dkim=|X-Originating" phishing-email.eml
  grep -oE "https?://[^ \"'>]+" phishing-email.eml

  # Network IOCs
  tshark -r evidence/network-capture.pcap -Y http.request -T fields -e http.host -e ip.dst -e http.user_agent
  tshark -r evidence/network-capture.pcap -T fields -e ip.dst | sort | uniq -c | sort -rn

  # File IOCs
  md5sum evidence/*.exe evidence/*.xls
  sha256sum evidence/*.exe evidence/*.xls
  strings evidence/updater.exe | grep -i "http\|dll"
EOF

echo "[+] IOC correlation lab ready."
