#!/bin/bash
###############################################################################
# setup.sh — IOC Extraction & Indicator Correlation lab
#            (Module 5, Incident Responder; also used by the Malware course)
#
# Runs ON the lab VM (Ubuntu 22.04) as root after the artifact bundle is
# extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# This is a LINUX CLI / SSH lab (login localuser / password). No desktop GUI,
# no web UI, no Splunk. The trainee correlates ONE malicious IOC thread across
# FIVE pre-generated log files from FIVE different sources, using jq / grep /
# awk / sort entirely from the shell.
#
# Responsibilities (kept deliberately small — NO data generation here):
#   1. Install jq (the only extra tool the tasks require) + coreutils.
#   2. Create the /lab-data -> /opt/lab_data symlink the other labs use.
#   3. Leave the five pre-generated, deterministic log files in /opt/lab_data
#      (they ship inside the artifact bundle) and ALSO place copies in the
#      /opt/lab_data/ioc/ sub-directory the material references.
#   4. Drop a short README the trainee can cat.
#
# The log files are GENERATED OFFLINE by a separate generator and shipped
# inside the artifact bundle — they are NOT produced here, so grading stays
# 100% reproducible. (The generator is intentionally NOT shipped to the VM.)
#
# Idempotent + always exits 0 + bash -n clean.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

LAB_SRC="/opt/lab_data"
LAB_DIR="/opt/lab_data/ioc"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[*] === IOC Extraction & Indicator Correlation lab setup ==="

# ── 1. Install jq (coreutils: grep/awk/sort/uniq already present) ───────────
if ! command -v jq >/dev/null 2>&1; then
    echo "[*] Installing jq ..."
    apt-get update -y -qq 2>/dev/null || true
    apt-get install -y -qq jq >/dev/null 2>&1 || true
else
    echo "[+] jq already installed"
fi

# ── 2. Lab directories + /lab-data symlink (matches the other CLI labs) ─────
mkdir -p "${LAB_SRC}"
ln -sf "${LAB_SRC}" /lab-data 2>/dev/null || true
mkdir -p "${LAB_DIR}"

# ── 3. Place the deterministic log files where material.md expects them ─────
# The artifact bundle drops the files next to this script and/or at the root
# of /opt/lab_data. Seed them into /opt/lab_data, then copy into ioc/.
LAB_FILES="proxy.log dns.log sysmon_edr.ndjson auth.log firewall.log"

for f in ${LAB_FILES}; do
    if [ ! -f "${LAB_SRC}/${f}" ] && [ -f "${SCRIPT_DIR}/${f}" ]; then
        cp -f "${SCRIPT_DIR}/${f}" "${LAB_SRC}/${f}"
    fi
done

for f in ${LAB_FILES}; do
    if [ -f "${LAB_SRC}/${f}" ]; then
        cp -f "${LAB_SRC}/${f}" "${LAB_DIR}/${f}"
        chmod 0644 "${LAB_SRC}/${f}" "${LAB_DIR}/${f}" 2>/dev/null || true
        echo "[+] ${LAB_DIR}/${f}"
    elif [ -f "${LAB_DIR}/${f}" ]; then
        echo "[+] ${LAB_DIR}/${f} (already in place)"
    else
        echo "[!] WARNING: ${f} not found in artifact bundle"
    fi
done

# ── 4. Short README for the trainee ─────────────────────────────────────────
cat > "${LAB_DIR}/README.txt" <<'README'
=== IOC Extraction & Indicator Correlation (CLI / SSH lab) ===

This is a command-line lab. Connect over SSH (localuser / password). There is
no desktop GUI and no web UI. You correlate ONE malicious indicator thread
across FIVE log files from FIVE different sources, using jq/grep/awk/sort.

Log files (in /opt/lab_data/ioc/, also at /lab-data/ioc/):

  proxy.log          web-proxy access log         NDJSON (one JSON / line)
  dns.log            internal DNS resolver log     NDJSON
  sysmon_edr.ndjson  endpoint EDR / Sysmon events  NDJSON
  auth.log           fileserver SSH auth log       syslog text
  firewall.log       egress firewall log           key=value text

proxy.log fields:
  ts, src_ip, src_host, method, host, uri, status,
  bytes_out, bytes_in, dest_ip, user_agent

dns.log fields:
  ts, src_ip, src_host, query, qtype, rcode, answer

sysmon_edr.ndjson fields:
  ts, event_id (1=ProcessCreate 3=NetworkConnect 11=FileCreate),
  host, src_ip, user, image, parent_image, sha256,
  command_line, target_filename, dest_ip, dest_port, dest_host

auth.log:  syslog lines, "... from <IP> port <n> ssh2"
firewall.log: "ts action=... src=... dst=... spt=... dpt=... proto=... bytes=..."

Quick starts:
  jq -r '.dest_ip' /opt/lab_data/ioc/proxy.log | sort | uniq -c | sort -rn | head
  jq -r 'select(.rcode=="NOERROR") | .answer' /opt/lab_data/ioc/dns.log | sort -u | head
  grep -oE '([0-9]{1,3}\.){3}[0-9]{1,3}' /opt/lab_data/ioc/auth.log | sort -u | head

The core idea: ONE external indicator threads through ALL FIVE sources and
traces back to a single patient-zero host. Find the indicator that correlates
across the most sources, then pivot from it to recover the rest of the thread.

Work through the tasks in the training portal panel on the right. Each task
has exactly one correct answer.
README

echo "[*] IOC correlation lab setup complete."
ls -lh "${LAB_DIR}/" 2>/dev/null || true
exit 0
