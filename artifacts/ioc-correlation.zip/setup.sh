#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing tools..."
apt-get update -qq
apt-get install -y -qq python3 python3-pip jq tshark > /dev/null 2>&1
pip3 install yara-python > /dev/null 2>&1

mkdir -p /opt/lab_data
cd /opt/lab_data

echo "[*] Generating multi-source evidence..."
python3 << 'PYEOF'
import random, datetime, hashlib, os, json

random.seed(42)
attacker_infra = {
    "c2_ip": "185.220.101.42",
    "phish_ip": "198.51.100.55",
    "exfil_domain": "data-sync.evil-corp.com",
    "c2_domain": "update-service.evil-corp.com",
    "phish_domain": "hr-portal-update.com",
}

# Email headers (.eml file)
with open("phishing_email.eml", "w") as f:
    f.write("""Return-Path: <hr-notifications@hr-portal-update.com>
Received: from mail.hr-portal-update.com (198.51.100.55) by mail.corp.local
    with SMTP; Mon, 18 Mar 2026 08:42:15 +0000
From: "HR Department" <hr@hr-portal-update.com>
Reply-To: support@data-sync.evil-corp.com
To: all-staff@corp.local
Subject: Urgent: Benefits Enrollment Update Required
Date: Mon, 18 Mar 2026 08:42:00 +0000
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_Part_12345"
X-Mailer: Microsoft Outlook 16.0
Authentication-Results: mail.corp.local; spf=fail; dkim=fail
X-Spam-Status: Yes, score=8.5

------=_Part_12345
Content-Type: text/html; charset="utf-8"

<html>
<body>
<p>Dear Employee,</p>
<p>Your benefits enrollment requires immediate update. Please review and sign the attached document.</p>
<p><a href="http://hr-portal-update.com/benefits/enroll.php?id=28475">Click here to update your benefits</a></p>
<p>This link expires in 24 hours.</p>
<p>Best regards,<br>HR Department</p>
</body>
</html>

------=_Part_12345
Content-Type: application/vnd.ms-excel; name="Benefits_Form_2026.xls"
Content-Disposition: attachment; filename="Benefits_Form_2026.xls"
Content-Transfer-Encoding: base64

TVqQAAMAAAA[TRUNCATED - This is actually a PE executable disguised as .xls]
------=_Part_12345--
""")

# Network connection log
with open("network_connections.log", "w") as f:
    f.write("timestamp,src_ip,src_port,dst_ip,dst_port,proto,bytes_out,bytes_in\n")
    base = datetime.datetime(2026, 3, 18, 8, 0, 0)
    for i in range(500):
        t = base + datetime.timedelta(seconds=random.randint(0, 36000))
        src = f"10.0.1.{random.randint(10,50)}"
        dst = random.choice(["93.184.216.34", "13.107.6.152", "172.217.14.206"])
        f.write(f"{t.isoformat()},{src},{random.randint(49000,65000)},{dst},443,TCP,{random.randint(100,5000)},{random.randint(200,50000)}\n")

    # C2 traffic
    victim = "10.0.1.25"
    t = base + datetime.timedelta(hours=1)
    for i in range(30):
        t += datetime.timedelta(seconds=60)
        f.write(f"{t.isoformat()},{victim},{random.randint(49000,65000)},{attacker_infra['c2_ip']},443,TCP,256,128\n")

    # Data exfiltration (large outbound)
    t = base + datetime.timedelta(hours=3)
    for i in range(5):
        t += datetime.timedelta(minutes=random.randint(5, 15))
        f.write(f"{t.isoformat()},{victim},{random.randint(49000,65000)},{attacker_infra['c2_ip']},443,TCP,{random.randint(500000,2000000)},64\n")

# Suspicious files with hashes
files_data = {
    "Benefits_Form_2026.xls": b"MZ\x90\x00" + os.urandom(4096),
    "updater.exe": b"MZ\x90\x00" + b"http://update-service.evil-corp.com/c2\x00" + os.urandom(4096),
}
os.makedirs("evidence_files", exist_ok=True)
file_hashes = {}
for name, data in files_data.items():
    path = f"evidence_files/{name}"
    with open(path, "wb") as f:
        f.write(data)
    file_hashes[name] = {
        "md5": hashlib.md5(data).hexdigest(),
        "sha256": hashlib.sha256(data).hexdigest(),
        "size": len(data),
    }

with open("file_hashes.json", "w") as f:
    json.dump(file_hashes, f, indent=2)

# DNS resolution log
with open("dns_resolutions.log", "w") as f:
    f.write("timestamp,query,resolved_ip,src_ip\n")
    base = datetime.datetime(2026, 3, 18, 8, 0, 0)
    for i in range(300):
        t = base + datetime.timedelta(seconds=random.randint(0, 36000))
        domains = ["www.google.com", "outlook.office365.com", "cdn.jsdelivr.net",
                    "hr-portal-update.com", "update-service.evil-corp.com", "data-sync.evil-corp.com"]
        domain = random.choice(domains)
        if "evil" in domain or "portal-update" in domain:
            ip = attacker_infra.get("c2_ip", "185.220.101.42")
        else:
            ip = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        f.write(f"{t.isoformat()},{domain},{ip},10.0.1.{random.randint(10,50)}\n")

print("Generated evidence files for IOC correlation")
PYEOF

cat > /opt/lab_data/README.txt << 'EOF'
=== IOC Extraction & Indicator Correlation Lab ===

Files:
  phishing_email.eml          - Phishing email with headers
  network_connections.log     - Network connection log (CSV)
  dns_resolutions.log         - DNS resolution log (CSV)
  evidence_files/             - Suspicious files collected from endpoints
  file_hashes.json            - Pre-computed file hashes

Analysis tips:
  # Analyze email headers
  grep -E "Return-Path|From|Reply-To|Received|spf=|dkim=" phishing_email.eml

  # Extract IPs from email
  grep -oE "\b([0-9]{1,3}\.){3}[0-9]{1,3}\b" phishing_email.eml | sort -u

  # Find C2 traffic (regular intervals, same destination)
  awk -F, '{print $4}' network_connections.log | sort | uniq -c | sort -rn | head

  # Cross-reference email IPs with network traffic
  grep "198.51.100.55\|185.220.101.42" network_connections.log

  # Check file hashes
  cat file_hashes.json | python3 -m json.tool

  # Compute your own hashes
  md5sum evidence_files/*
  sha256sum evidence_files/*

Your goal: Extract all IOCs, correlate across sources, and map to MITRE ATT&CK.
EOF

echo "[+] IOC correlation lab setup complete."
