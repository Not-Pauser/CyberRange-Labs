WAZUH EDR INVESTIGATION LAB - Artifact Kit
=============================================

FILES INCLUDED:
- wazuh_alerts.json  : 1500+ Wazuh alerts including MITRE ATT&CK mapping
- fim_alerts.json    : 200+ File Integrity Monitoring alerts
- vuln_report.json   : Vulnerability assessment for all agents

SCENARIO:
Wazuh EDR is deployed across your corporate network (6 agents).
On March 24, 2025, the SOC received high-severity alerts from WS-DEV03.
Investigate the full attack chain using Wazuh's MITRE ATT&CK mapping.

AGENT INVENTORY:
  001 - DC01         (10.0.1.1)   - Domain Controller
  002 - SRV-FILE01   (10.0.1.10)  - File Server
  003 - SRV-WEB01    (10.0.1.20)  - Web Server
  004 - WS-HR01      (10.0.2.10)  - HR Workstation
  005 - WS-DEV03     (10.0.3.25)  - Developer Workstation (COMPROMISED)
  006 - WS-FIN01     (10.0.4.10)  - Finance Workstation

INVESTIGATION TASKS:
1. ALERT TRIAGE:
   - Sort alerts by severity level
   - Identify which agents have critical/high alerts
   - Group alerts by MITRE ATT&CK tactic

2. ATTACK CHAIN (MITRE ATT&CK):
   Map the attack through the kill chain:
   - Initial Access (T1566.001) -> Execution (T1059.001)
   - Persistence (T1547.001) -> Defense Evasion (T1055)
   - Credential Access (T1003.001) -> Discovery (T1087)
   - Lateral Movement (T1021.002) -> C2 (T1071.001)
   - Exfiltration (T1048.003)

3. FILE INTEGRITY:
   - Identify new files created during the attack
   - Distinguish legitimate changes from malicious ones
   - Correlate FIM events with wazuh_alerts timestamps

4. VULNERABILITY ASSESSMENT:
   - Which agents have critical vulnerabilities?
   - Are any exploited-in-the-wild CVEs present?
   - Could any vulnerability have enabled the attack?
   - Prioritize remediation

DELIVERABLES:
- MITRE ATT&CK navigator layer showing the attack
- Timeline of attack with evidence from all three sources
- Vulnerability remediation priority list
- Incident report with recommendations
