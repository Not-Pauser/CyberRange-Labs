#!/bin/bash
###############################################################################
# setup.sh — Wazuh EDR Alert Investigation lab (Module 4, Incident Responder)
#
# Runs ON the lab VM (ubuntu-22.04-x64-desktop-template) as ROOT after the
# artifact bundle is extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# Model: same as the Splunk labs — the security tool runs ON this VM and the
# trainee opens its web UI in the desktop browser. Here that tool is Wazuh
# (all-in-one: wazuh-manager + wazuh-indexer + wazuh-dashboard).
#
# IMPORTANT — why this script DETACHES:
#   The backend invokes setup.sh through `qm guest exec` with a 600s timeout
#   and there is NO Wazuh-specific readiness gate in the backend (only Splunk
#   labs have one, and the backend is frozen / out of scope to edit). A Wazuh
#   all-in-one install routinely takes 10-20 min on a small VM and would blow
#   that 600s window. So this launcher kicks off the real work in a DETACHED
#   background worker (survives the guest-exec channel closing) and returns in
#   seconds. Progress is logged to /opt/lab_data/wazuh-setup.log and the phase
#   is written to /opt/lab_data/wazuh-setup.state. The lab is "ready" when the
#   dashboard answers on https://localhost — expect ~10-20 min on first boot.
#
# What the worker does (all idempotent, safe to re-run):
#   1. Install Wazuh 4.9 all-in-one via the official wazuh-install.sh (-a -i -o).
#   2. Recover the generated `admin` password from wazuh-install-files.tar and
#      persist it to /opt/lab_data/wazuh_admin_password.txt.
#   3. Apply the Wazuh alerts index template so the dashboard's default
#      `wazuh-alerts-*` index pattern renders our docs.
#   4. BULK-LOAD the pre-generated, deterministic
#      /opt/lab_data/wazuh_alerts.ndjson into today's wazuh-alerts-4.x-<date>
#      index via the indexer _bulk API, RE-STAMPING each alert timestamp into a
#      recent ~16h window so the dashboard's default time picker shows them.
#      The relative facts the lab grades on (agent count, CVEs, FIM paths,
#      MITRE ids, rule ids, counts) are date-independent, so grading is exact.
#
# The alert data is GENERATED OFFLINE (no generator shipped) and ships as
# wazuh_alerts.ndjson inside the artifact bundle — NOT produced here, so
# grading is 100% reproducible.
#
# NOTE: This installer could NOT be run end-to-end in the authoring sandbox.
#       It is written to be robust + idempotent and must be smoke-tested on a
#       real Ubuntu-desktop deploy. The DATA + ANSWERS are exact regardless of
#       how the dashboard renders them.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

WAZUH_MAJOR="4.9"
LAB_DATA="/opt/lab_data"
NDJSON="${LAB_DATA}/wazuh_alerts.ndjson"
INSTALL_DIR="/root/wazuh-aio"
PW_FILE="${LAB_DATA}/wazuh_admin_password.txt"     # persisted for re-runs + ops
SETUP_LOG="${LAB_DATA}/wazuh-setup.log"
STATE_FILE="${LAB_DATA}/wazuh-setup.state"
DONE_FLAG="${LAB_DATA}/.wazuh-load-done"
INDEXER="https://127.0.0.1:9200"

mkdir -p "$LAB_DATA"

# ===========================================================================
# THIN LAUNCHER — runs under `qm guest exec`, returns in seconds.
# Re-spawns itself as a detached worker (--worker) unless already running.
# ===========================================================================
if [ "${1:-}" != "--worker" ]; then
    if [ -f "$DONE_FLAG" ]; then
        echo "[+] Wazuh lab already provisioned (found ${DONE_FLAG}). Nothing to do."
        exit 0
    fi
    if pgrep -f "setup.sh --worker" >/dev/null 2>&1; then
        echo "[*] Wazuh lab worker already running — see ${SETUP_LOG}"
        exit 0
    fi
    echo "starting" > "$STATE_FILE"
    echo "[*] Launching detached Wazuh install+load worker."
    echo "[*] Progress: tail -f ${SETUP_LOG}   |   phase: cat ${STATE_FILE}"
    echo "[*] Dashboard will be ready on https://localhost in ~10-20 min."
    # setsid + nohup so the worker outlives the guest-exec channel.
    setsid nohup bash "$0" --worker >>"$SETUP_LOG" 2>&1 < /dev/null &
    disown 2>/dev/null || true
    exit 0
fi

# ===========================================================================
# WORKER (detached) — the heavy lifting.
# ===========================================================================
log(){ echo "[*] $(date -u +%H:%M:%S) $*"; }
ok(){  echo "[+] $(date -u +%H:%M:%S) $*"; }
warn(){ echo "[!] $(date -u +%H:%M:%S) $*"; }
phase(){ echo "$1" > "$STATE_FILE"; }

log "=== Wazuh EDR Investigation lab worker started ==="

# ---- prereqs --------------------------------------------------------------
command -v curl    >/dev/null 2>&1 || { apt-get update -y -qq 2>/dev/null; apt-get install -y -qq curl    >/dev/null 2>&1 || true; }
command -v tar     >/dev/null 2>&1 || apt-get install -y -qq tar     >/dev/null 2>&1 || true
command -v python3 >/dev/null 2>&1 || apt-get install -y -qq python3 >/dev/null 2>&1 || true

# ---- 1. install Wazuh all-in-one (idempotent) -----------------------------
phase "installing"
if [ -d /var/ossec ] && (systemctl is-active --quiet wazuh-indexer 2>/dev/null || curl -s -k -o /dev/null "$INDEXER" 2>/dev/null); then
    ok "Wazuh already installed — skipping install"
else
    log "Downloading wazuh-install.sh (${WAZUH_MAJOR}) ..."
    mkdir -p "$INSTALL_DIR"
    cd "$INSTALL_DIR" 2>/dev/null || cd /root
    curl -sS -o "${INSTALL_DIR}/wazuh-install.sh" \
        "https://packages.wazuh.com/${WAZUH_MAJOR}/wazuh-install.sh" \
        || wget -q -O "${INSTALL_DIR}/wazuh-install.sh" \
           "https://packages.wazuh.com/${WAZUH_MAJOR}/wazuh-install.sh"
    if [ ! -s "${INSTALL_DIR}/wazuh-install.sh" ]; then
        warn "Could not download wazuh-install.sh — check internet egress on this VM."
        phase "failed-download"
    else
        log "Running all-in-one install (several minutes) ..."
        # -a all-in-one, -i ignore hw/system-check warnings, -o overwrite a
        # previous partial install so re-runs converge.
        bash "${INSTALL_DIR}/wazuh-install.sh" -a -i -o \
            || bash "${INSTALL_DIR}/wazuh-install.sh" -a -i \
            || warn "wazuh-install.sh returned non-zero — continuing (may already be up)"
    fi
fi

# ---- 2. recover the admin password ----------------------------------------
phase "resolving-password"
ADMIN_PASS=""
TAR=""
for d in "$INSTALL_DIR" /root /home/* /; do
    cand=$(ls -1 "${d}"/wazuh-install-files.tar 2>/dev/null | head -n1 || true)
    [ -n "${cand:-}" ] && { TAR="$cand"; break; }
done
if [ -n "${TAR}" ] && [ -f "$TAR" ]; then
    log "Extracting admin password from ${TAR}"
    PWTXT=$(tar -xf "$TAR" -O wazuh-install-files/wazuh-passwords.txt 2>/dev/null || true)
    [ -z "$PWTXT" ] && PWTXT=$(tar -xf "$TAR" -O wazuh-passwords.txt 2>/dev/null || true)
    # Format:  "  indexer username: 'admin'\n  indexer password: '<pw>'"
    ADMIN_PASS=$(printf '%s\n' "$PWTXT" \
        | awk "/[Uu]sername: *'admin'/{f=1} f&&/[Pp]assword:/{gsub(/.*[Pp]assword: *'\''/,\"\");gsub(/'\''.*/,\"\");print;exit}")
    if [ -z "$ADMIN_PASS" ]; then
        ADMIN_PASS=$(printf '%s\n' "$PWTXT" | grep -A2 "'admin'" | grep -m1 -i password | sed "s/.*'\\([^']*\\)'.*/\\1/")
    fi
fi
if [ -z "$ADMIN_PASS" ] && [ -f "$PW_FILE" ]; then
    ADMIN_PASS=$(cat "$PW_FILE"); ok "Reusing persisted admin password"
fi
[ -z "$ADMIN_PASS" ] && ADMIN_PASS="admin"
printf '%s' "$ADMIN_PASS" > "$PW_FILE"; chmod 0640 "$PW_FILE" 2>/dev/null || true
ok "admin password resolved (stored at ${PW_FILE})"

# ---- 3. wait for indexer :9200 --------------------------------------------
phase "waiting-indexer"
log "Waiting for the Wazuh indexer on :9200 ..."
UP=0
for _ in $(seq 1 120); do
    if curl -s -k -u "admin:${ADMIN_PASS}" "${INDEXER}/_cluster/health" >/dev/null 2>&1; then
        UP=1; break
    fi
    systemctl start wazuh-indexer 2>/dev/null || true
    sleep 5
done
if [ "$UP" = 1 ]; then ok "indexer reachable"; else warn "indexer not reachable after ~10min"; fi

CURL=(curl -sS -k -u "admin:${ADMIN_PASS}")

# ---- 4. index template ----------------------------------------------------
phase "templating"
TPL=""
for cand in /etc/filebeat/wazuh-template.json \
            /usr/share/wazuh-indexer/wazuh-template.json; do
    [ -f "$cand" ] && { TPL="$cand"; break; }
done
if [ -n "$TPL" ]; then
    log "Applying official Wazuh index template from ${TPL}"
    "${CURL[@]}" -X PUT "${INDEXER}/_template/wazuh" \
        -H 'Content-Type: application/json' --data-binary "@${TPL}" >/dev/null 2>&1 \
        || warn "official template PUT failed — fallback template still applies"
fi
# Minimal fallback template — guarantees `timestamp` is a date and the mitre /
# vulnerability / syscheck objects are queryable even on a bare indexer.
"${CURL[@]}" -X PUT "${INDEXER}/_template/wazuh-lab" \
    -H 'Content-Type: application/json' -d '{
      "index_patterns": ["wazuh-alerts-4.x-*"],
      "settings": {"number_of_shards": 1, "number_of_replicas": 0},
      "mappings": {
        "dynamic_templates": [
          {"strings_as_keyword": {"match_mapping_type": "string",
            "mapping": {"type": "keyword"}}}
        ],
        "properties": {
          "timestamp": {"type": "date"},
          "rule": {"properties": {
            "level": {"type": "long"},
            "id": {"type": "keyword"},
            "description": {"type": "keyword"},
            "mitre": {"properties": {
              "id": {"type": "keyword"},
              "tactic": {"type": "keyword"},
              "technique": {"type": "keyword"}}}}},
          "agent": {"properties": {
            "id": {"type": "keyword"}, "name": {"type": "keyword"}, "ip": {"type": "keyword"}}},
          "syscheck": {"properties": {
            "path": {"type": "keyword"}, "event": {"type": "keyword"}}},
          "data": {"properties": {
            "vulnerability": {"properties": {
              "cve": {"type": "keyword"}, "severity": {"type": "keyword"}}}}}
        }
      }
    }' >/dev/null 2>&1 && ok "fallback index template applied" || warn "fallback template PUT failed"

# ---- 5. bulk-load the pre-generated alerts --------------------------------
phase "loading-data"
if [ ! -f "$NDJSON" ]; then
    warn "MISSING ${NDJSON} — cannot load alerts. Bundle did not extract correctly."
    phase "failed-no-data"
else
    INDEX="wazuh-alerts-4.x-$(date -u +%Y.%m.%d)"
    BULK="/tmp/wazuh_bulk.ndjson"
    log "Preparing _bulk payload for index ${INDEX}"
    python3 - "$NDJSON" "$INDEX" "$BULK" <<'PY'
import json, sys, datetime
src, index, out = sys.argv[1], sys.argv[2], sys.argv[3]
docs = [json.loads(l) for l in open(src) if l.strip()]
if not docs:
    raise SystemExit("no docs in NDJSON")

def parse(ts):
    return datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")

# Anchor the earliest alert ~16h before now, preserve relative spacing so the
# whole scenario lands inside the default 24h dashboard window in order.
t0 = min(parse(d["timestamp"]) for d in docs)
try:
    now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
except Exception:
    now = datetime.datetime.utcnow()
anchor = now - datetime.timedelta(hours=16)

with open(out, "w") as fh:
    for d in docs:
        delta = parse(d["timestamp"]) - t0
        newts = anchor + delta
        d["timestamp"] = newts.strftime("%Y-%m-%dT%H:%M:%S.000+0000")
        d.setdefault("@timestamp", d["timestamp"])
        fh.write(json.dumps({"index": {"_index": index}}) + "\n")
        fh.write(json.dumps(d) + "\n")
print("bulk lines:", sum(1 for _ in open(out)))
PY

    if [ -s "$BULK" ]; then
        # Idempotent reload: drop today's index first so re-runs don't double-count.
        "${CURL[@]}" -X DELETE "${INDEXER}/${INDEX}" >/dev/null 2>&1 || true
        log "POST /_bulk -> ${INDEX}"
        RESP=$("${CURL[@]}" -H 'Content-Type: application/x-ndjson' \
            -X POST "${INDEXER}/_bulk?refresh=wait_for" --data-binary "@${BULK}")
        if printf '%s' "$RESP" | grep -q '"errors":false'; then
            ok "bulk load reported errors:false"
        else
            warn "bulk load reported errors — first 400 chars:"; printf '%s\n' "${RESP:0:400}"
        fi
        COUNT=$("${CURL[@]}" "${INDEXER}/${INDEX}/_count" 2>/dev/null \
            | python3 -c 'import sys,json;print(json.load(sys.stdin).get("count","?"))' 2>/dev/null || echo "?")
        ok "documents now in ${INDEX}: ${COUNT}"
        [ "$COUNT" != "?" ] && [ "$COUNT" != "0" ] && touch "$DONE_FLAG"
    else
        warn "empty _bulk payload — skipped load"; phase "failed-bulk"
    fi
fi

# ---- 6. trainee README ----------------------------------------------------
cat > "${LAB_DATA}/README.txt" <<README_EOF
=== Wazuh EDR Alert Investigation ===

Wazuh runs ON THIS VM (all-in-one). Investigate the alerts in the web dashboard:

  URL:    https://localhost      (also https://127.0.0.1)
  Login:  admin
  Pass:   see ${PW_FILE}   ->  cat ${PW_FILE}

The dashboard uses a SELF-SIGNED certificate — your browser will warn you the
first time. Click "Advanced" -> "Proceed to localhost" to continue.

First boot installs Wazuh in the background (~10-20 min). Watch progress with:
  tail -f ${SETUP_LOG}
  cat ${STATE_FILE}

Then investigate:
  * Modules -> Threat Hunting / Security Events  — browse all alerts
  * Agents                                       — reporting endpoints
  * Modules -> File Integrity Monitoring         — /etc/* change alerts
  * Modules -> MITRE ATT&CK                       — pivot on techniques
  * Modules -> Vulnerability Detection           — CVE findings

Set the time picker to "Last 24 hours" (the default) — the alerts were loaded
with recent timestamps.

Work through the tasks in the training portal panel on the right.
README_EOF
chmod 0644 "${LAB_DATA}/README.txt" 2>/dev/null || true

phase "ready"
ok "Wazuh EDR lab worker complete — dashboard at https://localhost (admin / see ${PW_FILE})"
exit 0
