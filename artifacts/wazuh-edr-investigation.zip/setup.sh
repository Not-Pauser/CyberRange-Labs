#!/bin/bash
###############################################################################
# setup.sh — Wazuh EDR Alert Investigation lab (Module 4, Incident Responder)
#
# Runs ON the lab VM (ubuntu-22.04-x64-desktop-template) as ROOT after the
# bundle extracts to /opt/lab_data, invoked via `qm guest exec`.
#
# Model = same as the Splunk labs: the tool runs ON this VM and the trainee
# opens its web UI in the desktop browser. Here that tool is Wazuh all-in-one
# (manager + indexer + dashboard).
#
# A Wazuh install takes 10-20 min (> the 600s guest-exec timeout, and there is
# no Wazuh readiness gate in the backend), so this launcher DETACHES a worker
# and returns in seconds. Progress: tail -f /opt/lab_data/wazuh-setup.log.
#
# The worker, after install:
#   * recovers the real `admin` indexer password (value only — not the YAML line)
#   * DISABLES Wazuh self-monitoring (syscheck/rootcheck/sca/vuln) so the box
#     stops generating its own background alerts
#   * CLEARS every wazuh-alerts-* index (drops the install-time baseline noise)
#   * BULK-LOADS the deterministic /opt/lab_data/wazuh_alerts.ndjson, re-stamped
#     into a recent 16h window so they appear in the default dashboard time range
#   * removes itself + the raw alert file so the trainee works from the dashboard
#
# Graded facts (agent count, FIM path, MITRE ids, CVE, rule ids, counts) are
# date-independent, so grading stays exact regardless of the re-stamp.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

WAZUH_MAJOR="4.9"
LAB_DATA="/opt/lab_data"
NDJSON="${LAB_DATA}/wazuh_alerts.ndjson"
INSTALL_DIR="/root/wazuh-aio"
PW_FILE="${LAB_DATA}/wazuh_admin_password.txt"
SETUP_LOG="${LAB_DATA}/wazuh-setup.log"
STATE_FILE="${LAB_DATA}/wazuh-setup.state"
DONE_FLAG="${LAB_DATA}/.wazuh-load-done"
INDEXER="https://127.0.0.1:9200"

mkdir -p "$LAB_DATA"

# ===========================================================================
# THIN LAUNCHER — returns in seconds, respawns a detached worker.
# ===========================================================================
if [ "${1:-}" != "--worker" ]; then
    [ -f "$DONE_FLAG" ] && { echo "[+] Wazuh lab already provisioned."; exit 0; }
    pgrep -f "setup.sh --worker" >/dev/null 2>&1 && { echo "[*] worker already running — tail ${SETUP_LOG}"; exit 0; }
    echo "starting" > "$STATE_FILE"
    echo "[*] Launching detached Wazuh install+load worker."
    echo "[*] Progress: tail -f ${SETUP_LOG} | phase: cat ${STATE_FILE}"
    echo "[*] Dashboard ready on https://localhost in ~10-20 min."
    setsid nohup bash "$0" --worker >>"$SETUP_LOG" 2>&1 < /dev/null &
    disown 2>/dev/null || true
    exit 0
fi

# ===========================================================================
# WORKER (detached)
# ===========================================================================
log(){ echo "[*] $(date -u +%H:%M:%S) $*"; }
ok(){  echo "[+] $(date -u +%H:%M:%S) $*"; }
warn(){ echo "[!] $(date -u +%H:%M:%S) $*"; }
phase(){ echo "$1" > "$STATE_FILE"; }

log "=== Wazuh EDR Investigation lab worker started ==="
command -v curl    >/dev/null 2>&1 || { apt-get update -y -qq 2>/dev/null; apt-get install -y -qq curl >/dev/null 2>&1 || true; }
command -v python3 >/dev/null 2>&1 || apt-get install -y -qq python3 >/dev/null 2>&1 || true

# ---- 1. install Wazuh all-in-one (idempotent) -----------------------------
phase "installing"
if [ -d /var/ossec ] && (systemctl is-active --quiet wazuh-indexer 2>/dev/null || curl -s -k -o /dev/null "$INDEXER" 2>/dev/null); then
    ok "Wazuh already installed — skipping install"
else
    log "Downloading wazuh-install.sh (${WAZUH_MAJOR}) ..."
    mkdir -p "$INSTALL_DIR"; cd "$INSTALL_DIR" 2>/dev/null || cd /root
    curl -sS -o "${INSTALL_DIR}/wazuh-install.sh" "https://packages.wazuh.com/${WAZUH_MAJOR}/wazuh-install.sh" \
        || wget -q -O "${INSTALL_DIR}/wazuh-install.sh" "https://packages.wazuh.com/${WAZUH_MAJOR}/wazuh-install.sh"
    if [ ! -s "${INSTALL_DIR}/wazuh-install.sh" ]; then
        warn "Could not download wazuh-install.sh — check VM internet egress."; phase "failed-download"
    else
        log "Running all-in-one install (several minutes) ..."
        bash "${INSTALL_DIR}/wazuh-install.sh" -a -i -o \
            || bash "${INSTALL_DIR}/wazuh-install.sh" -a -i \
            || warn "wazuh-install.sh returned non-zero — continuing (may already be up)"
    fi
fi

# ---- 2. recover the admin password (THE VALUE, not the YAML line) ---------
phase "resolving-password"
ADMIN_PASS=""; TAR=""
for d in "$INSTALL_DIR" /root /home/* /; do
    cand=$(ls -1 "${d}"/wazuh-install-files.tar 2>/dev/null | head -n1 || true)
    [ -n "${cand:-}" ] && { TAR="$cand"; break; }
done
if [ -n "${TAR}" ] && [ -f "$TAR" ]; then
    log "Extracting admin password from ${TAR}"
    PWTXT=$(tar -xf "$TAR" -O wazuh-install-files/wazuh-passwords.txt 2>/dev/null || true)
    [ -z "$PWTXT" ] && PWTXT=$(tar -xf "$TAR" -O wazuh-passwords.txt 2>/dev/null || true)
    # The file holds:   indexer_password: '<value>'   — grab only <value>.
    ADMIN_PASS=$(printf '%s\n' "$PWTXT" | grep -oP "indexer_password:\s*'\K[^']+" | head -n1 || true)
    [ -z "$ADMIN_PASS" ] && ADMIN_PASS=$(printf '%s\n' "$PWTXT" | sed -n "s/.*indexer_password:[[:space:]]*'\([^']*\)'.*/\1/p" | head -n1)
fi
if [ -z "$ADMIN_PASS" ] && [ -f "$PW_FILE" ]; then ADMIN_PASS=$(tr -d '\n\r' < "$PW_FILE"); ok "Reusing persisted password"; fi
[ -z "$ADMIN_PASS" ] && ADMIN_PASS="admin"
printf '%s' "$ADMIN_PASS" > "$PW_FILE"; chmod 0640 "$PW_FILE" 2>/dev/null || true
ok "admin password resolved (length ${#ADMIN_PASS})"
CURL=(curl -sS -k -u "admin:${ADMIN_PASS}")

# ---- 3. silence Wazuh's own monitoring (so only scenario alerts show) -----
phase "quieting-self-monitoring"
OSSEC=/var/ossec/etc/ossec.conf
if [ -f "$OSSEC" ]; then
    python3 - "$OSSEC" <<'PYC'
import re, sys
p = sys.argv[1]; c = open(p).read(); orig = c
def set_in_block(tag, child, val, text):
    def repl(m):
        b = m.group(0)
        if re.search(rf'<{child}>.*?</{child}>', b, flags=re.S):
            return re.sub(rf'<{child}>.*?</{child}>', f'<{child}>{val}</{child}>', b, flags=re.S)
        return b.replace(f'<{tag}>', f'<{tag}>\n    <{child}>{val}</{child}>', 1)
    return re.sub(rf'<{tag}>.*?</{tag}>', repl, text, flags=re.S)
c = set_in_block('syscheck', 'disabled', 'yes', c)
c = set_in_block('rootcheck', 'disabled', 'yes', c)
c = set_in_block('sca', 'enabled', 'no', c)
c = set_in_block('vulnerability-detection', 'enabled', 'no', c)
c = set_in_block('vulnerability-detector', 'enabled', 'no', c)
# Remove the manager's own log monitors so agent 000 (the Wazuh server itself)
# generates NO alerts — the dashboard then shows only the scenario endpoints.
c = re.sub(r'[ \t]*<localfile>.*?</localfile>\s*', '', c, flags=re.S)
open(p, 'w').write(c)
print("ossec.conf changed" if c != orig else "ossec.conf already quiet")
PYC
    systemctl restart wazuh-manager 2>/dev/null || true
    ok "self-monitoring disabled + manager restarted"
fi

# ---- 4. wait for the indexer ----------------------------------------------
phase "waiting-indexer"
UP=0
for _ in $(seq 1 120); do
    "${CURL[@]}" "${INDEXER}/_cluster/health" >/dev/null 2>&1 && { UP=1; break; }
    systemctl start wazuh-indexer 2>/dev/null || true
    sleep 5
done
[ "$UP" = 1 ] && ok "indexer reachable" || warn "indexer not reachable after ~10min"

# ---- 5. index template (guarantees queryable mappings) --------------------
phase "templating"
"${CURL[@]}" -X PUT "${INDEXER}/_template/wazuh-lab" -H 'Content-Type: application/json' -d '{
  "index_patterns": ["wazuh-alerts-4.x-*"],
  "settings": {"number_of_shards": 1, "number_of_replicas": 0},
  "mappings": {
    "dynamic_templates": [{"strings_as_keyword": {"match_mapping_type": "string", "mapping": {"type": "keyword"}}}],
    "properties": {
      "timestamp": {"type": "date"}, "@timestamp": {"type": "date"},
      "rule": {"properties": {"level": {"type": "long"}, "id": {"type": "keyword"}, "description": {"type": "keyword"},
        "groups": {"type": "keyword"},
        "mitre": {"properties": {"id": {"type": "keyword"}, "tactic": {"type": "keyword"}, "technique": {"type": "keyword"}}}}},
      "agent": {"properties": {"id": {"type": "keyword"}, "name": {"type": "keyword"}, "ip": {"type": "keyword"}}},
      "syscheck": {"properties": {"path": {"type": "keyword"}, "event": {"type": "keyword"}}},
      "data": {"properties": {"vulnerability": {"properties": {"cve": {"type": "keyword"}, "severity": {"type": "keyword"}}}}}
    }
  }
}' >/dev/null 2>&1 && ok "lab index template applied" || warn "template PUT failed"

# ---- 6. clear baseline noise, then bulk-load the scenario alerts ----------
phase "loading-data"
if [ ! -f "$NDJSON" ]; then
    warn "MISSING ${NDJSON} — bundle did not extract correctly."; phase "failed-no-data"; exit 1
fi
log "Clearing existing wazuh-alerts-* (Wazuh install-time self-monitoring noise) ..."
"${CURL[@]}" -X DELETE "${INDEXER}/wazuh-alerts-*" >/dev/null 2>&1 || true
sleep 2
INDEX="wazuh-alerts-4.x-$(date -u +%Y.%m.%d)"
BULK="/tmp/wazuh_bulk.ndjson"
log "Preparing _bulk payload for ${INDEX}"
python3 - "$NDJSON" "$INDEX" "$BULK" <<'PY'
import json, sys, datetime
src, index, out = sys.argv[1], sys.argv[2], sys.argv[3]
docs = [json.loads(l) for l in open(src) if l.strip()]
if not docs: raise SystemExit("no docs in NDJSON")
def parse(ts): return datetime.datetime.strptime(ts[:19], "%Y-%m-%dT%H:%M:%S")
t0 = min(parse(d["timestamp"]) for d in docs)
try: now = datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
except Exception: now = datetime.datetime.utcnow()
anchor = now - datetime.timedelta(hours=16)
with open(out, "w") as fh:
    for d in docs:
        d["timestamp"] = (anchor + (parse(d["timestamp"]) - t0)).strftime("%Y-%m-%dT%H:%M:%S.000+0000")
        d.setdefault("@timestamp", d["timestamp"])
        fh.write(json.dumps({"index": {"_index": index}}) + "\n")
        fh.write(json.dumps(d) + "\n")
print("bulk lines:", sum(1 for _ in open(out)))
PY
if [ -s "$BULK" ]; then
    RESP=$("${CURL[@]}" -H 'Content-Type: application/x-ndjson' -X POST "${INDEXER}/_bulk?refresh=wait_for" --data-binary "@${BULK}")
    if printf '%s' "$RESP" | grep -q '"errors":false'; then ok "bulk load errors:false"; else warn "bulk errors — first 400:"; printf '%s\n' "${RESP:0:400}"; fi
    COUNT=$("${CURL[@]}" "${INDEXER}/${INDEX}/_count" 2>/dev/null | python3 -c 'import sys,json;print(json.load(sys.stdin).get("count","?"))' 2>/dev/null || echo "?")
    ok "documents now in ${INDEX}: ${COUNT}"
    [ "$COUNT" != "?" ] && [ "$COUNT" != "0" ] && touch "$DONE_FLAG"
else
    warn "empty _bulk payload"; phase "failed-bulk"; exit 1
fi

# ---- 7. trainee README (no answers) ---------------------------------------
cat > "${LAB_DATA}/README.txt" <<README_EOF
=== Wazuh EDR Alert Investigation ===

Wazuh runs ON THIS VM. Investigate the alerts in the dashboard:

  URL:    https://localhost        (self-signed cert -> Advanced -> Proceed)
  Login:  admin
  Pass:   cat ${PW_FILE}

Work the alerts from:  Modules -> Threat Hunting   (and the Discover/search bar).
Set the time picker to "Last 24 hours" (the default). Filter and search the
alerts to answer the tasks in the training portal on the right.

NOTE: agent 000 is the Wazuh server itself — focus on the monitored endpoints.
README_EOF
chmod 0644 "${LAB_DATA}/README.txt" 2>/dev/null || true

phase "ready"
ok "Wazuh EDR lab ready — https://localhost (admin / cat ${PW_FILE})"

# ---- 8. self-clean: remove the provisioning script + raw alert file -------
rm -f "${LAB_DATA}/setup.sh" "$NDJSON" "$BULK" 2>/dev/null || true
exit 0
