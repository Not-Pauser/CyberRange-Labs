DNS & HTTP ANALYSIS LAB - Artifact Kit
=======================================

FILES INCLUDED:
- dns_queries.log   : 3000 DNS query log entries (BIND format)
- http_access.log   : 4000 Apache HTTP access log entries

SCENARIO:
Analyze DNS and HTTP logs from March 14, 2025 to identify:
1. DNS tunneling / data exfiltration
2. DGA (Domain Generation Algorithm) activity
3. HTTP-based C2 beaconing
4. Suspicious file downloads

DNS ANALYSIS TASKS:
- Find domains with unusually long/random names (DGA indicators)
- Identify TXT record queries used for data tunneling
- Find base64-encoded data in DNS subdomains
- Calculate the ratio of NXDOMAIN responses (DGA generates many)
- Identify the C2 domain all suspicious queries resolve to

HTTP ANALYSIS TASKS:
- Find the beaconing pattern (regular interval connections)
- Calculate the exact beacon interval
- Identify suspicious User-Agent strings
- Find executable file downloads
- Identify C2 callback URLs (non-standard paths)

DETECTION TECHNIQUES:
- DNS entropy analysis: DGA domains have higher character randomness
- DNS query length: Tunneling uses abnormally long subdomain labels
- HTTP timing analysis: C2 beacons at fixed intervals (with jitter)
- User-Agent anomalies: python-requests, curl from workstations
- URI pattern analysis: /gate.php, /api/beacon are not normal web paths
