#!/bin/bash
###############################################################################
# setup.sh — DNS & HTTP Protocol Analysis lab (Module 3, Network Defense Analyst)
#
# Runs ON the lab VM (Ubuntu 22.04) as root after the artifact bundle is
# extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# This is a LINUX CLI / SSH lab (login localuser / password). No desktop GUI,
# no web UI, no Splunk. The trainee analyses two pre-generated JSON log files
# with jq / grep / awk / sort.
#
# Responsibilities (kept deliberately small — NO data generation here):
#   1. Install jq (the only tool the tasks require) + the usual coreutils.
#   2. Create the /lab-data -> /opt/lab_data symlink the other labs use.
#   3. Leave the two pre-generated, deterministic log files in /opt/lab_data
#      (they ship inside the artifact bundle) and ALSO place copies at the
#      /opt/lab_data/dns-http/ path the material references.
#
# The log files are GENERATED OFFLINE by generate_logs.py and shipped inside
# the artifact bundle — they are NOT produced here, so grading stays 100%
# reproducible.
#
# Idempotent + always exits 0 + bash -n clean.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

LAB_SRC="/opt/lab_data"
LAB_DIR="/opt/lab_data/dns-http"
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

echo "[*] === DNS & HTTP Protocol Analysis lab setup ==="

# ── 1. Install jq (+ coreutils already present) ─────────────────────────────
if ! command -v jq >/dev/null 2>&1; then
    echo "[*] Installing jq ..."
    apt-get update -y -qq 2>/dev/null || true
    apt-get install -y -qq jq >/dev/null 2>&1 || true
else
    echo "[+] jq already installed"
fi

# ── 2. Lab directories + /lab-data symlink (matches the other labs) ─────────
mkdir -p "${LAB_SRC}"
ln -sf "${LAB_SRC}" /lab-data 2>/dev/null || true
mkdir -p "${LAB_DIR}"

# ── 3. Place the deterministic log files where material.md expects them ─────
# They ship in /opt/lab_data already; if the bundle dropped them next to this
# script instead, seed them into /opt/lab_data first.
for f in dns_queries.log http_proxy.log; do
    if [ ! -f "${LAB_SRC}/${f}" ] && [ -f "${SCRIPT_DIR}/${f}" ]; then
        cp -f "${SCRIPT_DIR}/${f}" "${LAB_SRC}/${f}"
    fi
done

for f in dns_queries.log http_proxy.log; do
    if [ -f "${LAB_SRC}/${f}" ]; then
        cp -f "${LAB_SRC}/${f}" "${LAB_DIR}/${f}"
        chmod 0644 "${LAB_SRC}/${f}" "${LAB_DIR}/${f}" 2>/dev/null || true
        echo "[+] ${LAB_DIR}/${f}"
    else
        echo "[!] WARNING: ${LAB_SRC}/${f} not found in artifact bundle"
    fi
done

# ── 4. Short README for the trainee ─────────────────────────────────────────
cat > "${LAB_DIR}/README.txt" <<'README'
=== DNS & HTTP Protocol Analysis (CLI / SSH lab) ===

This is a command-line lab. Connect over SSH (localuser / password). There is
no desktop GUI and no web UI. Analyse the two JSON log files with jq/grep/awk.

Log files (NDJSON — one JSON object per line):
  /opt/lab_data/dns-http/dns_queries.log    internal DNS resolver query log
  /opt/lab_data/dns-http/http_proxy.log     corporate web-proxy access log
(also reachable at /lab-data/dns-http/ via the symlink)

dns_queries.log fields:
  ts, src_ip, src_host, resolver, query, qtype, rcode, answer

http_proxy.log fields:
  ts, src_ip, src_host, method, host, uri, status,
  bytes_out, bytes_in, dest_ip, dest_port, user_agent

Quick starts:
  jq -r '.query' /opt/lab_data/dns-http/dns_queries.log | head
  jq -r 'select(.rcode=="NXDOMAIN") | .query' /opt/lab_data/dns-http/dns_queries.log | head
  jq -r '.user_agent' /opt/lab_data/dns-http/http_proxy.log | sort | uniq -c | sort -rn

Work through the tasks in the training portal panel on the right. Each task has
exactly one correct answer.
README

echo "[*] DNS & HTTP analysis lab setup complete."
ls -lh "${LAB_DIR}/" 2>/dev/null || true
exit 0
