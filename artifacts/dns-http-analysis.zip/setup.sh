#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === DNS & HTTP Protocol Analysis Lab Setup ==="

apt-get update -qq
apt-get install -y -qq python3 tshark tcpdump dnsutils curl jq > /dev/null 2>&1

mkdir -p /opt/lab_data/dns-http
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/dns-http

echo "[*] Generating DNS traffic PCAP..."
python3 << 'PYEOF'
import struct, random, socket, os

random.seed(42)

def pcap_header():
    return struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1)  # Ethernet

def eth_hdr(src=b"\x00\x11\x22\x33\x44\x55", dst=b"\x66\x77\x88\x99\xaa\xbb"):
    return dst + src + struct.pack("!H", 0x0800)

def ip_hdr(src, dst, proto, payload_len, ident=None):
    if ident is None: ident = random.randint(1,65535)
    hdr = struct.pack("!BBHHHBBH4s4s",
        0x45, 0, 20 + payload_len, ident, 0x4000, 64, proto, 0,
        socket.inet_aton(src), socket.inet_aton(dst))
    cs = sum(struct.unpack("!10H", hdr))
    cs = (cs >> 16) + (cs & 0xffff)
    cs = ~cs & 0xffff
    return hdr[:10] + struct.pack("!H", cs) + hdr[12:]

def udp_hdr(sport, dport, payload):
    length = 8 + len(payload)
    return struct.pack("!HHHH", sport, dport, length, 0) + payload

def dns_query(txid, name, qtype=1):
    flags = 0x0100  # standard query, recursion desired
    hdr = struct.pack("!HHHHHH", txid, flags, 1, 0, 0, 0)
    labels = b""
    for part in name.split("."):
        labels += bytes([len(part)]) + part.encode()
    labels += b"\x00"
    return hdr + labels + struct.pack("!HH", qtype, 1)

def write_pkt(f, data, ts):
    f.write(struct.pack("<IIII", ts, random.randint(0,999999), len(data), len(data)))
    f.write(data)

# === DNS PCAP ===
with open("dns-traffic.pcap", "wb") as f:
    f.write(pcap_header())
    ts = 1711000000
    client = "10.0.1.25"
    dns_srv = "10.0.2.5"

    # Normal queries
    normal = ["www.google.com","mail.google.com","outlook.office365.com",
              "cdn.jsdelivr.net","api.github.com","slack.com","zoom.us",
              "teams.microsoft.com","login.microsoftonline.com","drive.google.com"]
    for i in range(300):
        ts += random.randint(1,10)
        domain = random.choice(normal)
        txid = random.randint(1,65535)
        qr = dns_query(txid, domain)
        pkt = eth_hdr() + ip_hdr(client, dns_srv, 17, 8+len(qr)) + udp_hdr(random.randint(49000,65000), 53, qr)
        write_pkt(f, pkt, ts)

    # DGA domains (high entropy, rapid queries)
    import string, hashlib
    for i in range(80):
        ts += random.randint(1,3)
        h = hashlib.md5(f"dga-seed-{i}".encode()).hexdigest()[:12]
        domain = f"{h}.evil-infra.net"
        qr = dns_query(random.randint(1,65535), domain)
        pkt = eth_hdr() + ip_hdr(client, dns_srv, 17, 8+len(qr)) + udp_hdr(random.randint(49000,65000), 53, qr)
        write_pkt(f, pkt, ts)

    # DNS exfiltration (base64 subdomains)
    import base64
    exfil_chunks = ["username:admin","password:P@ssw0rd!","server:DC-01","domain:corp.local",
                    "hash:e10adc3949ba59abbe56e057f20f883e","ssn:123-45-6789"]
    for chunk in exfil_chunks:
        ts += random.randint(5,20)
        encoded = base64.b64encode(chunk.encode()).decode().rstrip("=")
        domain = f"{encoded}.exfil.data-sync.evil-corp.com"
        qr = dns_query(random.randint(1,65535), domain)
        pkt = eth_hdr() + ip_hdr(client, dns_srv, 17, 8+len(qr)) + udp_hdr(random.randint(49000,65000), 53, qr)
        write_pkt(f, pkt, ts)

    # TXT record queries (C2 commands)
    for i in range(10):
        ts += random.randint(30,90)
        domain = f"cmd{i}.c2-channel.evil-corp.com"
        qr = dns_query(random.randint(1,65535), domain, qtype=16)  # TXT
        pkt = eth_hdr() + ip_hdr(client, dns_srv, 17, 8+len(qr)) + udp_hdr(random.randint(49000,65000), 53, qr)
        write_pkt(f, pkt, ts)

print(f"dns-traffic.pcap: {os.path.getsize('dns-traffic.pcap')} bytes")

# === HTTP PCAP ===
def tcp_hdr(sport, dport, seq, payload, flags=0x18):
    return struct.pack("!HHIIHHH", sport, dport, seq, 0, (5<<12)|flags, 65535, 0) + b"\x00\x00"

with open("http-traffic.pcap", "wb") as f:
    f.write(pcap_header())
    ts = 1711000000
    client = "10.0.1.25"
    normal_srv = "93.184.216.34"
    c2_srv = "185.220.101.42"

    normal_ua = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    c2_ua = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; CobaltStrike/4.8)"

    # Normal HTTP
    for i in range(200):
        ts += random.randint(1,15)
        url = random.choice(["/","/index.html","/api/v1/users","/static/js/app.js","/images/logo.png","/login"])
        http = f"GET {url} HTTP/1.1\r\nHost: www.example.com\r\nUser-Agent: {normal_ua}\r\nAccept: */*\r\nConnection: keep-alive\r\n\r\n".encode()
        tcp = tcp_hdr(random.randint(49000,65000), 80, random.randint(1,2**31), http)
        pkt = eth_hdr() + ip_hdr(client, normal_srv, 6, len(tcp)+len(http)) + tcp + http
        write_pkt(f, pkt, ts)

    # C2 beaconing (regular 60s interval, suspicious UA)
    beacon_start = ts + 100
    for i in range(60):
        ts = beacon_start + (i * 60) + random.randint(-2, 2)  # ~60s jitter
        method = "GET" if i % 3 != 0 else "POST"
        path = f"/api/v1/check?session=A3F2B8&seq={i}"
        http = f"{method} {path} HTTP/1.1\r\nHost: update-service.evil-corp.com\r\nUser-Agent: {c2_ua}\r\nCookie: SESSIONID=8f3a2b1c9d\r\nContent-Length: 0\r\n\r\n".encode()
        tcp = tcp_hdr(random.randint(49000,65000), 443, random.randint(1,2**31), http)
        pkt = eth_hdr() + ip_hdr(client, c2_srv, 6, len(tcp)+len(http)) + tcp + http
        write_pkt(f, pkt, ts)

print(f"http-traffic.pcap: {os.path.getsize('http-traffic.pcap')} bytes")
PYEOF

cat > /opt/lab_data/dns-http/README.txt << 'EOF'
=== DNS & HTTP Protocol Analysis Lab ===

PCAPs:
  dns-traffic.pcap  - DNS queries (normal + DGA + exfiltration + C2)
  http-traffic.pcap - HTTP traffic (normal + C2 beaconing)

Analysis:
  tshark -r dns-traffic.pcap -T fields -e dns.qry.name | sort | uniq -c | sort -rn | head -20
  tshark -r dns-traffic.pcap -Y "dns.qry.name contains evil" -T fields -e frame.time -e dns.qry.name
  tshark -r http-traffic.pcap -Y "http.request" -T fields -e http.host -e http.request.uri -e http.user_agent
  tshark -r http-traffic.pcap -Y "http.user_agent contains CobaltStrike"
EOF

echo "[+] DNS & HTTP analysis lab ready."
