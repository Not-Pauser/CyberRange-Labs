#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing tools..."
apt-get update -qq
apt-get install -y -qq python3 tshark tcpdump dnsutils jq > /dev/null 2>&1

mkdir -p /opt/lab_data
cd /opt/lab_data

echo "[*] Generating DNS and HTTP logs..."
python3 << 'PYEOF'
import random, datetime, json, base64

random.seed(42)
start = datetime.datetime(2026, 3, 15, 8, 0, 0)

# Normal domains
normal_domains = [
    "www.google.com", "mail.google.com", "drive.google.com",
    "outlook.office365.com", "login.microsoftonline.com",
    "cdn.jsdelivr.net", "api.github.com", "slack-msgs.com",
    "zoom.us", "teams.microsoft.com", "aws.amazon.com",
]
# DGA domains (algorithmically generated)
dga_domains = [
    "xk7r2m9pq4.evil.com", "b3nz8wkf1d.evil.com", "qy5t0jc6xa.evil.com",
    "m4hp9rw2vl.evil.com", "d8fn3kzg7s.evil.com", "j1cx5bmt0e.evil.com",
    "w6ay9dlq3u.evil.com", "p2ek7nhs4i.evil.com",
]
# DNS exfiltration (base64 in subdomain)
exfil_data = ["dXNlcm5hbWU6YWRtaW4=", "cGFzc3dvcmQ6UEBzc3cwcmQh",
              "c2VydmVyOkRDLTAxLmNvcnAubG9jYWw=", "ZG9tYWluOmNvcnAubG9jYWw="]

# Generate DNS query log
with open("dns_queries.log", "w") as f:
    f.write("timestamp,src_ip,query,query_type,response_ip\n")
    for i in range(2000):
        ts = start + datetime.timedelta(seconds=random.randint(0, 28800))
        src = f"10.0.1.{random.randint(10, 50)}"
        if i < 1600:
            domain = random.choice(normal_domains)
            resp = f"{random.randint(1,223)}.{random.randint(0,255)}.{random.randint(0,255)}.{random.randint(1,254)}"
        elif i < 1850:
            domain = random.choice(dga_domains)
            resp = "185.220.101.42"
        else:
            data = random.choice(exfil_data)
            domain = f"{data}.data.c2-server.net"
            resp = "185.220.101.42"
        f.write(f"{ts.isoformat()},{src},{domain},A,{resp}\n")

# Generate HTTP access log
ua_normal = [
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120.0",
    "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) Safari/605.1.15",
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0",
]
ua_c2 = "Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; Cobalt Strike Beacon)"
beacon_interval = 60  # C2 beacon every 60 seconds

with open("http_access.log", "w") as f:
    f.write("timestamp,src_ip,method,url,status,user_agent,bytes\n")
    for i in range(1500):
        ts = start + datetime.timedelta(seconds=random.randint(0, 28800))
        src = f"10.0.1.{random.randint(10, 50)}"
        if i < 1300:
            method = random.choice(["GET", "GET", "GET", "POST"])
            urls = ["/", "/api/v1/users", "/static/js/app.js", "/images/logo.png",
                    "/login", "/dashboard", "/api/v1/reports"]
            url = random.choice(urls)
            status = random.choice([200, 200, 200, 301, 304, 404])
            ua = random.choice(ua_normal)
            size = random.randint(200, 50000)
        else:
            # C2 beaconing traffic
            method = random.choice(["GET", "POST"])
            url = random.choice(["/beacon.php", "/update.php", "/check.php?id=A3F2"])
            status = 200
            ua = ua_c2
            size = random.randint(64, 512)
            src = "10.0.1.25"  # infected host
            # Regular interval
            ts = start + datetime.timedelta(seconds=(i - 1300) * beacon_interval)
        f.write(f"{ts.isoformat()},{src},{method},{url},{status},\"{ua}\",{size}\n")

print("Generated dns_queries.log and http_access.log")
PYEOF

cat > /opt/lab_data/README.txt << 'EOF'
=== DNS & HTTP Protocol Analysis Lab ===

Files:
  dns_queries.log  - DNS query log (CSV: timestamp, src_ip, query, type, response)
  http_access.log  - HTTP access log (CSV: timestamp, src_ip, method, url, status, ua, bytes)

Analysis tips:
  # Find DGA domains (unusually random names)
  awk -F, '{print $3}' dns_queries.log | sort | uniq -c | sort -rn | head -20

  # Find DNS exfiltration (base64 in subdomains)
  grep "data.c2-server.net" dns_queries.log

  # Decode exfiltrated data
  echo "dXNlcm5hbWU6YWRtaW4=" | base64 -d

  # Find suspicious user agents
  awk -F, '{print $6}' http_access.log | sort | uniq -c | sort -rn

  # Detect beaconing (regular interval HTTP requests)
  grep "beacon.php\|update.php\|check.php" http_access.log

Your goal: identify C2 communication, DGA domains, DNS exfiltration, and extract all IOCs.
EOF

echo "[+] DNS & HTTP analysis lab setup complete."
