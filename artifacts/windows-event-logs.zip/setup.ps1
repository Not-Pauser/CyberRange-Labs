
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === Windows Event Log Analysis Lab Setup ==="
New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null

Write-Host "[*] Injecting realistic security events into Windows Event Log..."

# Enable command-line auditing
auditpol /set /subcategory:"Process Creation" /success:enable /failure:enable 2>$null

# Generate events using eventcreate and direct log writing
$attackerIP = "203.0.113.77"
$baseTime = (Get-Date).AddHours(-3)

# Create XML template for importing events via wevtutil
$eventsXml = @()

# Write a PowerShell simulation script that creates real events
$simScript = @'
# Simulate attack activity to generate real Windows events

# 1. Failed logons (will create real 4625 events)
$cred = New-Object System.Management.Automation.PSCredential("administrator", (ConvertTo-SecureString "WrongPass123" -AsPlainText -Force))
for ($i = 0; $i -lt 8; $i++) {
    try {
        Start-Process "cmd.exe" -Credential $cred -ErrorAction SilentlyContinue
    } catch {}
    Start-Sleep -Milliseconds 500
}

# 2. Process creation events (real 4688 via audit)
cmd.exe /c "whoami" 2>$null
cmd.exe /c "net user" 2>$null
cmd.exe /c "ipconfig /all" 2>$null
cmd.exe /c "net group /domain" 2>$null

# 3. Spawn suspicious child processes
$encoded = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes("ipconfig"))
powershell.exe -EncodedCommand $encoded 2>$null

Write-Host "[+] Attack simulation complete - check Event Viewer"
'@

Set-Content -Path "C:\LabData\simulate_attack.ps1" -Value $simScript

# Run simulation to generate REAL events
Write-Host "[*] Running attack simulation..."
& powershell.exe -ExecutionPolicy Bypass -File "C:\LabData\simulate_attack.ps1" 2>$null

# Export recent security events for analysis
Write-Host "[*] Exporting security events..."
wevtutil epl Security "C:\LabData\Security-Export.evtx" 2>$null

# Also export as readable format
Get-WinEvent -LogName Security -MaxEvents 500 2>$null |
    Select-Object TimeCreated, Id, LevelDisplayName, Message |
    Export-Csv -Path "C:\LabData\security_events_readable.csv" -NoTypeInformation

@"
=== Windows Event Log Analysis Lab ===

Primary analysis target: Windows Event Viewer (eventvwr.msc)
  -> Windows Logs -> Security

Exported copy: C:\LabData\Security-Export.evtx
  (Open in Event Viewer: File -> Open Saved Log)

Key Event IDs to investigate:
  4624 - Successful logon (check LogonType: 2=Interactive, 3=Network, 10=RDP)
  4625 - Failed logon (brute force indicator)
  4648 - Explicit credential use (lateral movement)
  4688 - Process creation (with command line)
  4720 - Account created
  1102 - Audit log cleared (anti-forensics)

PowerShell analysis:
  Get-WinEvent -LogName Security -FilterHashtable @{Id=4625} | Format-Table TimeCreated, Message -Wrap
  Get-WinEvent -LogName Security -FilterHashtable @{Id=4688} | Format-Table TimeCreated, Message -Wrap
  Get-WinEvent -FilterHashtable @{LogName='Security';Id=4624} | Where-Object {`$_.Message -match 'Logon Type:\s+3'}

Simulation script: C:\LabData\simulate_attack.ps1
  Re-run to generate fresh events for analysis.
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] Windows Event Log lab ready."
