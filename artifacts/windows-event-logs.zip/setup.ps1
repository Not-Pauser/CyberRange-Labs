
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up Windows Event Log Analysis lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null

# Generate synthetic .evtx-like data as XML for import
$logPath = "C:\LabData"

# Create PowerShell script to generate events
$script = @'
# Generate suspicious Windows events for the lab
$logPath = "C:\LabData"

# Create event log entries using Write-EventLog
try {
    # Create custom event source if needed
    if (-not [System.Diagnostics.EventLog]::SourceExists("LabSimulation")) {
        New-EventLog -LogName Application -Source "LabSimulation"
    }
} catch {}

# Generate auth events data as CSV (since we can't create .evtx directly)
$events = @()

# Normal logons
for ($i = 0; $i -lt 50; $i++) {
    $events += [PSCustomObject]@{
        TimeCreated = (Get-Date).AddHours(-((Get-Random -Min 1 -Max 72)))
        EventId = 4624
        Computer = "WS-$(Get-Random -Min 10 -Max 30)"
        Account = @("jsmith","mwilson","agarcia","blee") | Get-Random
        SourceIP = "10.0.1.$(Get-Random -Min 10 -Max 50)"
        LogonType = @(2,3,10) | Get-Random
        Status = "Success"
    }
}

# Failed logons (brute force)
$attackerIP = "203.0.113.77"
$bruteTime = (Get-Date).AddHours(-2)
for ($i = 0; $i -lt 20; $i++) {
    $bruteTime = $bruteTime.AddSeconds((Get-Random -Min 1 -Max 5))
    $events += [PSCustomObject]@{
        TimeCreated = $bruteTime
        EventId = 4625
        Computer = "WS-25"
        Account = "administrator"
        SourceIP = $attackerIP
        LogonType = 3
        Status = "Failure"
    }
}

# Successful admin logon after brute force
$events += [PSCustomObject]@{
    TimeCreated = $bruteTime.AddSeconds(30)
    EventId = 4624
    Computer = "WS-25"
    Account = "administrator"
    SourceIP = $attackerIP
    LogonType = 3
    Status = "Success"
}

# Suspicious process creation
$events += [PSCustomObject]@{
    TimeCreated = $bruteTime.AddMinutes(5)
    EventId = 4688
    Computer = "WS-25"
    Account = "administrator"
    SourceIP = ""
    LogonType = 0
    Status = "Process: cmd.exe, CommandLine: cmd.exe /c whoami && net user /domain"
}
$events += [PSCustomObject]@{
    TimeCreated = $bruteTime.AddMinutes(6)
    EventId = 4688
    Computer = "WS-25"
    Account = "administrator"
    SourceIP = ""
    LogonType = 0
    Status = "Process: powershell.exe, CommandLine: powershell -enc aQBwAGMAbwBuAGYAaQBnAA=="
}

# Account creation
$events += [PSCustomObject]@{
    TimeCreated = $bruteTime.AddMinutes(15)
    EventId = 4720
    Computer = "DC-01"
    Account = "administrator"
    SourceIP = "10.0.1.25"
    LogonType = 0
    Status = "Created account: svc_backup"
}

# Log clearing
$events += [PSCustomObject]@{
    TimeCreated = $bruteTime.AddMinutes(30)
    EventId = 1102
    Computer = "WS-25"
    Account = "administrator"
    SourceIP = ""
    LogonType = 0
    Status = "Security log was cleared"
}

$events | Export-Csv -Path "$logPath\security_events.csv" -NoTypeInformation
Write-Host "[+] Generated $(($events).Count) security events"
'@

Set-Content -Path "$logPath\generate_events.ps1" -Value $script
& powershell.exe -ExecutionPolicy Bypass -File "$logPath\generate_events.ps1"

# Create README
@"
=== Windows Event Log Analysis Lab ===

Files:
  security_events.csv      - Simulated Windows Security events
  generate_events.ps1      - Script that generated the events

Key Event IDs:
  4624 - Successful logon
  4625 - Failed logon
  4648 - Explicit credential logon
  4688 - Process creation
  4720 - Account created
  1102 - Security log cleared

Analysis with PowerShell:
  Import-Csv C:\LabData\security_events.csv | Where-Object {`$_.EventId -eq 4625} | Format-Table
  Import-Csv C:\LabData\security_events.csv | Group-Object EventId | Sort-Object Count -Desc

Also check the actual Windows Event Viewer:
  eventvwr.msc -> Windows Logs -> Security

Your goal: Identify the attack pattern from the event data.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] Windows Event Log lab setup complete."
