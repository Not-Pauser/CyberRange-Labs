#!/bin/bash
###############################################################################
# setup.sh — Windows Event Log Analysis lab
#
# Runs ON the lab VM (Ubuntu desktop) after the artifact zip extracts to
# /opt/lab_data. Installs Splunk (scenario recipe), then loads the Windows
# Security event-log data so the trainee browses http://localhost:8000 with
# everything indexed:
#   security_events.json -> index=wineventlog   (sourcetype WinEventLog:Security)
#
# The data file is a JSON ARRAY — it's converted to NDJSON (one object per
# line) so Splunk indexes each record as its own event (counts must be exact).
###############################################################################
set -uo pipefail

SPLUNK_URL="${SPLUNK_URL:-https://download.splunk.com/products/splunk/releases/9.3.0/linux/splunk-9.3.0-51ccf43db5bd-Linux-x86_64.tgz}"
SPLUNK_HOME="/opt/splunk"
SPLUNK_PASS="changeme123!"
LAB_DATA="/opt/lab_data"

echo "[*] === Windows Event Log Analysis lab setup ==="

# ── 1. Install Splunk (scenario recipe) if not present ───────────────────────
if [ ! -x "${SPLUNK_HOME}/bin/splunk" ]; then
    echo "[*] Downloading Splunk: ${SPLUNK_URL##*/}"
    curl -fsSL -o /opt/splunk.tgz "$SPLUNK_URL" || wget -qO /opt/splunk.tgz "$SPLUNK_URL"
    tar xzf /opt/splunk.tgz -C /opt/ && rm -f /opt/splunk.tgz
    echo "OPTIMISTIC_ABOUT_FILE_LOCKING = 1" >> "${SPLUNK_HOME}/etc/splunk-launch.conf"
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt --seed-passwd "$SPLUNK_PASS"
    "${SPLUNK_HOME}/bin/splunk" enable boot-start || true
else
    echo "[+] Splunk already installed"
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" || \
        "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt
fi

for _ in $(seq 1 24); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    sleep 5
done

AUTH="-auth admin:${SPLUNK_PASS}"

# ── 2. Convert JSON arrays -> NDJSON (one event per line) ────────────────────
for f in security_events; do
    if [ -f "${LAB_DATA}/${f}.json" ]; then
        python3 -c "import json;[print(json.dumps(o)) for o in json.load(open('${LAB_DATA}/${f}.json'))]" \
            > "${LAB_DATA}/${f}.ndjson" 2>/dev/null && echo "[+] ${f}.ndjson" || echo "[!] ${f} convert failed"
    fi
done

# ── 3. Create the indexes the lab's queries use ──────────────────────────────
for idx in wineventlog; do
    "${SPLUNK_HOME}/bin/splunk" add index "$idx" $AUTH 2>/dev/null || true
done

# ── 4. Field extraction + aliases so material.md field names resolve ─────────
CONF_DIR="${SPLUNK_HOME}/etc/system/local"
mkdir -p "$CONF_DIR"
cat >> "${CONF_DIR}/props.conf" <<'PROPS'
[WinEventLog:Security]
KV_MODE = json
SHOULD_LINEMERGE = false
DATETIME_CONFIG = CURRENT
FIELDALIAS-eventcode  = EventID AS EventCode
FIELDALIAS-srcip      = IpAddress AS src_ip
FIELDALIAS-srcaddr    = IpAddress AS Source_Network_Address
FIELDALIAS-account    = TargetUserName AS Account_Name
FIELDALIAS-subjacct   = SubjectUserName AS Subject_Account_Name
FIELDALIAS-newaccount = TargetUserName AS New_Account_Name
FIELDALIAS-logontype  = LogonType AS Logon_Type
FIELDALIAS-group      = GroupName AS Group_Name
FIELDALIAS-process    = NewProcessName AS Process_Name
FIELDALIAS-parent     = ParentProcessName AS Parent_Process_Name
FIELDALIAS-cmdline    = CommandLine AS Process_Command_Line
PROPS

# ── 5. Inputs: monitor each NDJSON into the right index / sourcetype ─────────
cat > "${CONF_DIR}/inputs.conf" <<INPUTS
[monitor://${LAB_DATA}/security_events.ndjson]
sourcetype = WinEventLog:Security
index = wineventlog
disabled = false
INPUTS

# ── 6. Restart so inputs/props/indexes take effect ───────────────────────────
"${SPLUNK_HOME}/bin/splunk" restart $AUTH 2>/dev/null || \
    "${SPLUNK_HOME}/bin/splunk" restart --accept-license --answer-yes --no-prompt || true
# ENSURE splunkd is actually up — the restart can race/fail on a slow VM.
for _ in $(seq 1 18); do
    "${SPLUNK_HOME}/bin/splunk" status 2>/dev/null | grep -q "splunkd is running" && break
    "${SPLUNK_HOME}/bin/splunk" start --accept-license --answer-yes --no-prompt 2>/dev/null || true
    sleep 5
done

echo "[+] Windows Event Log Analysis lab ready — http://localhost:8000  (admin / ${SPLUNK_PASS})"
