WINDOWS EVENT LOGS LAB - Artifact Kit
======================================

FILES INCLUDED:
- synthetic_events/events.json : Complete Windows Security event log (attack sequence)

SCENARIO:
On March 15, 2025, the domain controller DC01.corp.local was compromised.
The events.json file contains the full attack sequence embedded in normal activity.

ATTACK TIMELINE TO DISCOVER:
1. Normal baseline activity (08:00-14:30)
2. Brute force attack - 80 failed logons from external IP (14:30-14:45)
3. Successful RDP logon with admin credentials (14:46)
4. Privilege confirmation (SeDebugPrivilege) (14:46)
5. New account creation (svc_update) and Domain Admins addition (14:49)
6. Reconnaissance commands (whoami, net user, ipconfig, nltest) (14:51+)
7. Credential dumping with Mimikatz (14:53)
8. Lateral movement to SRV-FILE01 via net use and service creation (14:54)
9. Audit log cleared to cover tracks (15:01)
10. Normal activity resumes

KEY EVENT IDs:
- 4625: Failed logon (brute force indicator)
- 4624: Successful logon (initial access)
- 4672: Special privileges (privilege escalation)
- 4720: Account created (persistence)
- 4728: Added to security group (privilege escalation)
- 4688: Process creation (execution, lateral movement)
- 1102: Audit log cleared (defense evasion)

INVESTIGATION TASKS:
1. Filter events by EventID to identify each attack phase
2. Build a timeline of the attacker's actions
3. Identify all IOCs (IPs, usernames, tools used)
4. Map each step to MITRE ATT&CK techniques
