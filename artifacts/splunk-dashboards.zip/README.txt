SPLUNK DASHBOARDS LAB - Artifact Kit
======================================

FILES INCLUDED:
- auth_7day.json         : 7 days of authentication events (~8000 events)
- process_baseline.json  : 7 days of process execution data (~3000 events)
- network_traffic.json   : 7 days of network flow records (~5000 events)

SCENARIO:
Build Splunk dashboards to monitor a corporate network over a 7-day period.
Day 5 (March 14) contains an attack that your dashboards should highlight.

DASHBOARD EXERCISES:
1. Authentication Dashboard:
   - Failed vs successful logons over time (timechart)
   - Top users by failed logons (bar chart)
   - Logon types distribution (pie chart)
   - Geographic/IP-based authentication heatmap

2. Process Monitoring Dashboard:
   - Process execution frequency baseline (timechart)
   - Unusual parent-child process relationships (table)
   - New/rare processes compared to baseline (stats)
   - Process execution by user (bar chart)

3. Network Traffic Dashboard:
   - Traffic volume over time by application (area chart)
   - Top talkers by bytes (bar chart)
   - Denied/blocked connections (timechart)
   - Connection duration outliers (scatter plot)

4. Combined Security Dashboard:
   - Alert severity over time
   - Correlation of auth failures with network activity
   - Anomaly detection across all three data sources

TIPS:
- Use timechart span=1h for hourly granularity
- Use stats count by field for aggregations
- Use eventstats avg(x) as avg_x for baseline comparison
- Day 5 attack should be visible as anomaly in all dashboards
