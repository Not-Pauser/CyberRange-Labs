#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing Suricata and dependencies..."
apt-get update -qq
apt-get install -y -qq suricata python3 tcpdump tshark libpcap-dev > /dev/null 2>&1

mkdir -p /opt/lab_data /opt/lab_data/rules
cd /opt/lab_data

echo "[*] Generating PCAP with attack traffic..."
python3 << 'PYEOF'
import struct, random, os

def build_ethernet(src_mac, dst_mac, eth_type=0x0800):
    return dst_mac + src_mac + struct.pack("!H", eth_type)

def build_ip(src, dst, proto, payload_len):
    ver_ihl = 0x45
    total_len = 20 + payload_len
    ident = random.randint(1, 65535)
    ttl = 64
    header = struct.pack("!BBHHHBBH4s4s",
        ver_ihl, 0, total_len, ident, 0, ttl, proto, 0,
        bytes(int(x) for x in src.split(".")),
        bytes(int(x) for x in dst.split(".")))
    # Checksum
    s = sum(struct.unpack("!10H", header))
    s = (s >> 16) + (s & 0xffff)
    s = ~s & 0xffff
    header = header[:10] + struct.pack("!H", s) + header[12:]
    return header

def build_tcp(sport, dport, payload):
    seq = random.randint(1, 2**31)
    ack = 0
    offset_flags = (5 << 12) | 0x18  # PSH+ACK
    header = struct.pack("!HHIIHHH", sport, dport, seq, ack, offset_flags, 65535, 0)
    return header + b"\x00\x00" + payload

def ip_to_bytes(ip):
    return bytes(int(x) for x in ip.split("."))

def write_pcap_packet(f, data, ts_sec):
    ts_usec = random.randint(0, 999999)
    f.write(struct.pack("<IIII", ts_sec, ts_usec, len(data), len(data)))
    f.write(data)

mac_src = b"\x00\x11\x22\x33\x44\x55"
mac_dst = b"\x66\x77\x88\x99\xaa\xbb"
victim = "10.0.1.25"
attacker = "185.220.101.42"
normal_dst = "93.184.216.34"

with open("attack-traffic.pcap", "wb") as f:
    # PCAP global header
    f.write(struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1))

    ts = 1711000000
    # Normal HTTP traffic
    for i in range(50):
        ts += random.randint(1, 5)
        http_req = f"GET /page{i}.html HTTP/1.1\r\nHost: www.example.com\r\nUser-Agent: Mozilla/5.0\r\n\r\n".encode()
        tcp = build_tcp(random.randint(49000, 65000), 80, http_req)
        ip = build_ip(victim, normal_dst, 6, len(tcp))
        eth = build_ethernet(mac_src, mac_dst)
        write_pcap_packet(f, eth + ip + tcp, ts)

    # C2 beaconing with suspicious UA
    for i in range(30):
        ts += 60  # regular interval
        http_req = f"GET /beacon?id=victim01&seq={i} HTTP/1.1\r\nHost: c2.evil-domain.com\r\nUser-Agent: Mozilla/4.0 (compatible; CobaltStrike/4.8)\r\n\r\n".encode()
        tcp = build_tcp(random.randint(49000, 65000), 443, http_req)
        ip = build_ip(victim, attacker, 6, len(tcp))
        eth = build_ethernet(mac_src, mac_dst)
        write_pcap_packet(f, eth + ip + tcp, ts)

    # DNS tunneling (long subdomain queries)
    for i in range(20):
        ts += random.randint(5, 30)
        import base64
        data = base64.b64encode(f"exfil-data-chunk-{i:04d}".encode()).decode().rstrip("=")
        dns_query = f"{data}.tunnel.evil-domain.com".encode()
        # Simple DNS-like payload
        dns_payload = struct.pack("!HHHHHH", random.randint(1,65535), 0x0100, 1, 0, 0, 0)
        dns_payload += bytes([len(dns_query)]) + dns_query + b"\x00" + struct.pack("!HH", 1, 1)
        udp_header = struct.pack("!HHHH", random.randint(49000, 65000), 53, 8 + len(dns_payload), 0)
        ip = build_ip(victim, "10.0.2.5", 17, len(udp_header + dns_payload))
        eth = build_ethernet(mac_src, mac_dst)
        write_pcap_packet(f, eth + ip + udp_header + dns_payload, ts)

    # Port scan
    for port in range(1, 101):
        ts += 1
        syn = struct.pack("!HHIIHHH", random.randint(49000,65000), port,
                          random.randint(1,2**31), 0, (5<<12)|0x02, 65535, 0) + b"\x00\x00"
        ip = build_ip("198.51.100.42", victim, 6, len(syn))
        eth = build_ethernet(mac_src, mac_dst)
        write_pcap_packet(f, eth + ip + syn, ts)

print("Generated attack-traffic.pcap")
PYEOF

# Create starter Suricata rules
cat > /opt/lab_data/rules/local.rules << 'EOF'
# Example rule - HTTP traffic detection
alert http any any -> any any (msg:"HTTP GET request detected"; flow:to_server,established; content:"GET"; http_method; sid:100001; rev:1;)

# TODO: Write your own rules below
# Rule format: action proto src_ip src_port -> dst_ip dst_port (options;)
EOF

# Create suricata config snippet
cat > /opt/lab_data/suricata-lab.yaml << 'EOF'
%YAML 1.1
---
default-rule-path: /opt/lab_data/rules
rule-files:
  - local.rules
EOF

cat > /opt/lab_data/README.txt << 'EOF'
=== Intrusion Detection with Suricata Lab ===

Files:
  attack-traffic.pcap      - Network capture with mixed normal + attack traffic
  rules/local.rules        - Starter Suricata rules (add your own here)
  suricata-lab.yaml        - Suricata config for this lab

Quick start:
  # Run Suricata against the PCAP
  suricata -r /opt/lab_data/attack-traffic.pcap -S /opt/lab_data/rules/local.rules -l /opt/lab_data/output/

  # View alerts
  cat /opt/lab_data/output/fast.log

  # View detailed JSON alerts
  cat /opt/lab_data/output/eve.json | python3 -m json.tool

  # Run with your custom rules
  echo 'alert tcp any any -> any any (msg:"Custom rule"; content:"CobaltStrike"; sid:200001; rev:1;)' >> /opt/lab_data/rules/local.rules
  suricata -r /opt/lab_data/attack-traffic.pcap -S /opt/lab_data/rules/local.rules -l /opt/lab_data/output2/

Your goal: analyze alerts, write custom rules for C2 and DNS tunneling, tune false positives.
EOF

mkdir -p /opt/lab_data/output
echo "[+] Suricata IDS lab setup complete."
