#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === Suricata IDS Lab Setup ==="

echo "[*] Installing Suricata and dependencies..."
apt-get update -qq
apt-get install -y -qq suricata python3 tshark jq libpcap-dev > /dev/null 2>&1

# Update Suricata rules
suricata-update 2>/dev/null || true

mkdir -p /opt/lab_data/suricata
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/suricata

echo "[*] Generating attack PCAPs..."
python3 << 'PYEOF'
import struct, random, socket, os, base64

random.seed(42)

def pcap_hdr():
    return struct.pack("<IHHiIII", 0xa1b2c3d4, 2, 4, 0, 0, 65535, 1)

def eth():
    return b"\x66\x77\x88\x99\xaa\xbb" + b"\x00\x11\x22\x33\x44\x55" + struct.pack("!H", 0x0800)

def ip(src, dst, proto, plen, ident=None):
    if ident is None: ident = random.randint(1,65535)
    h = struct.pack("!BBHHHBBH4s4s", 0x45, 0, 20+plen, ident, 0x4000, 64, proto, 0,
                    socket.inet_aton(src), socket.inet_aton(dst))
    cs = sum(struct.unpack("!10H", h)); cs = (cs>>16)+(cs&0xffff); cs = ~cs & 0xffff
    return h[:10] + struct.pack("!H", cs) + h[12:]

def tcp(sp, dp, payload, flags=0x18):
    seq = random.randint(1,2**31)
    hdr = struct.pack("!HHIIHHH", sp, dp, seq, 0, (5<<12)|flags, 65535, 0) + b"\x00\x00"
    return hdr + payload

def udp(sp, dp, payload):
    return struct.pack("!HHHH", sp, dp, 8+len(payload), 0) + payload

def dns_qr(name, qtype=1):
    h = struct.pack("!HHHHHH", random.randint(1,65535), 0x0100, 1, 0, 0, 0)
    labels = b""
    for p in name.split("."): labels += bytes([len(p)]) + p.encode()
    return h + labels + b"\x00" + struct.pack("!HH", qtype, 1)

def pkt(f, data, ts):
    f.write(struct.pack("<IIII", ts, random.randint(0,999999), len(data), len(data)))
    f.write(data)

victim = "10.0.1.25"
c2 = "185.220.101.42"
scanner = "198.51.100.42"
dns_srv = "10.0.2.5"
normal_srv = "93.184.216.34"

# === test-traffic.pcap: mixed normal + malicious ===
with open("test-traffic.pcap", "wb") as f:
    f.write(pcap_hdr()); ts = 1711000000
    ua_good = b"Mozilla/5.0 (Windows NT 10.0; Win64; x64) Chrome/120.0"
    ua_c2 = b"Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; CobaltStrike/4.8)"

    for i in range(100):
        ts += random.randint(1,5)
        h = f"GET /page{i} HTTP/1.1\r\nHost: www.example.com\r\nUser-Agent: {ua_good.decode()}\r\n\r\n".encode()
        p = eth() + ip(victim, normal_srv, 6, 20+len(h)) + tcp(random.randint(49000,65000), 80, h)
        pkt(f, p, ts)

    for i in range(40):
        ts += 60
        h = f"GET /beacon?s={i} HTTP/1.1\r\nHost: c2.evil-domain.com\r\nUser-Agent: {ua_c2.decode()}\r\n\r\n".encode()
        p = eth() + ip(victim, c2, 6, 20+len(h)) + tcp(random.randint(49000,65000), 443, h)
        pkt(f, p, ts)

print(f"test-traffic.pcap: {os.path.getsize('test-traffic.pcap')} bytes")

# === c2-traffic.pcap: pure C2 beaconing ===
with open("c2-traffic.pcap", "wb") as f:
    f.write(pcap_hdr()); ts = 1711000000
    for i in range(100):
        ts += 60 + random.randint(-3,3)
        m = "POST" if i % 5 == 0 else "GET"
        body = b"data=" + os.urandom(32).hex().encode() if m == "POST" else b""
        h = f"{m} /api/check?id=A3F2&seq={i} HTTP/1.1\r\nHost: update-service.evil-corp.com\r\nUser-Agent: {ua_c2.decode()}\r\nContent-Length: {len(body)}\r\n\r\n".encode() + body
        p = eth() + ip(victim, c2, 6, 20+len(h)) + tcp(random.randint(49000,65000), 443, h)
        pkt(f, p, ts)
print(f"c2-traffic.pcap: {os.path.getsize('c2-traffic.pcap')} bytes")

# === dns-tunnel.pcap: DNS tunneling ===
with open("dns-tunnel.pcap", "wb") as f:
    f.write(pcap_hdr()); ts = 1711000000
    for i in range(80):
        ts += random.randint(2,10)
        data = base64.b64encode(f"exfiltrated-data-chunk-{i:04d}-secret-payload".encode()).decode().rstrip("=")
        name = f"{data}.t.evil-tunnel.net"
        qr = dns_qr(name)
        p = eth() + ip(victim, dns_srv, 17, 8+len(qr)) + udp(random.randint(49000,65000), 53, qr)
        pkt(f, p, ts)
print(f"dns-tunnel.pcap: {os.path.getsize('dns-tunnel.pcap')} bytes")

# === benign-traffic.pcap: all clean ===
with open("benign-traffic.pcap", "wb") as f:
    f.write(pcap_hdr()); ts = 1711000000
    for i in range(200):
        ts += random.randint(1,10)
        if i % 2 == 0:
            name = random.choice(["www.google.com","outlook.office365.com","cdn.jsdelivr.net"])
            qr = dns_qr(name)
            p = eth() + ip(victim, dns_srv, 17, 8+len(qr)) + udp(random.randint(49000,65000), 53, qr)
        else:
            h = f"GET / HTTP/1.1\r\nHost: www.example.com\r\nUser-Agent: {ua_good.decode()}\r\n\r\n".encode()
            p = eth() + ip(victim, normal_srv, 6, 20+len(h)) + tcp(random.randint(49000,65000), 80, h)
        pkt(f, p, ts)
print(f"benign-traffic.pcap: {os.path.getsize('benign-traffic.pcap')} bytes")
PYEOF

# Create local rules directory
mkdir -p /opt/lab_data/suricata/rules
cat > /opt/lab_data/suricata/rules/local.rules << 'RULESEOF'
# === Custom Lab Rules ===
# Add your own rules below. Run with:
#   suricata -r /opt/lab_data/suricata/test-traffic.pcap \
#            -S /opt/lab_data/suricata/rules/local.rules \
#            -l /opt/lab_data/suricata/output/ --set outputs.eve-log.enabled=yes

# Example: detect HTTP requests
alert http any any -> any any (msg:"HTTP GET detected"; flow:to_server,established; content:"GET"; http_method; sid:100001; rev:1;)
RULESEOF

mkdir -p /opt/lab_data/suricata/output

cat > /opt/lab_data/suricata/README.txt << 'EOF'
=== Intrusion Detection with Suricata Lab ===

PCAPs:
  test-traffic.pcap   - Mixed normal + attack traffic
  c2-traffic.pcap     - Pure C2 beaconing traffic
  dns-tunnel.pcap     - DNS tunneling exfiltration
  benign-traffic.pcap - All clean traffic (for false positive testing)

Quick start:
  # Run with ET Open rules
  suricata -r test-traffic.pcap -l output/
  cat output/fast.log
  cat output/eve.json | jq '.alert' | head -50

  # Run with your custom rules
  suricata -r test-traffic.pcap -S rules/local.rules -l output/

  # Write rules in: rules/local.rules
EOF

echo "[+] Suricata IDS lab ready."
