#!/bin/bash
###############################################################################
# setup.sh — Intrusion Detection with Suricata lab (Module 5)
#
# Runs ON the lab VM (Ubuntu/Debian, CLI-only SSH lab) as root after the
# artifact bundle is extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# Responsibilities (kept deliberately small — no Splunk, no data generation):
#   1. Install suricata + jq (non-interactive).
#   2. Create /opt/lab_data/suricata/ and the /lab-data -> /opt/lab_data symlink
#      that the other labs use.
#   3. Copy the pre-generated, deterministic capture.pcap + local.rules from
#      /opt/lab_data/ to /opt/lab_data/suricata/ so they sit exactly where
#      material.md references.
#
# The pcap + rules are GENERATED OFFLINE by generate_suricata_data.py and
# shipped inside the artifact bundle — they are NOT produced here, so grading
# stays 100% reproducible.
#
# Idempotent + always exits 0.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

LAB_SRC="/opt/lab_data"
LAB_DIR="/opt/lab_data/suricata"

echo "[*] === Suricata IDS lab setup ==="

# -- 1. Install suricata + jq (non-interactive) ------------------------------
if ! command -v suricata >/dev/null 2>&1; then
    echo "[*] Installing suricata ..."
    apt-get update -y -qq 2>/dev/null || true
    apt-get install -y -qq suricata >/dev/null 2>&1 || true
else
    echo "[+] suricata already installed"
fi
if ! command -v jq >/dev/null 2>&1; then
    echo "[*] Installing jq ..."
    apt-get install -y -qq jq >/dev/null 2>&1 || true
else
    echo "[+] jq already installed"
fi

# -- 2. Lab directory + /lab-data symlink (matches the other labs) -----------
ln -sf "${LAB_SRC}" /lab-data 2>/dev/null || true
mkdir -p "${LAB_DIR}"

# -- 3. Place the deterministic data where material.md expects it ------------
for f in capture.pcap local.rules; do
    if [ -f "${LAB_SRC}/${f}" ]; then
        cp -f "${LAB_SRC}/${f}" "${LAB_DIR}/${f}"
        echo "[+] ${LAB_DIR}/${f}"
    else
        echo "[!] WARNING: ${LAB_SRC}/${f} not found in artifact bundle"
    fi
done

# Make the lab files readable by the trainee (localuser).
chmod 0644 "${LAB_DIR}/capture.pcap" "${LAB_DIR}/local.rules" 2>/dev/null || true

# -- 4. Short README for the trainee -----------------------------------------
cat > "${LAB_DIR}/README.txt" <<'README'
=== Intrusion Detection with Suricata ===

Files (CLI lab — analyse over SSH, no web UI):
  /opt/lab_data/suricata/capture.pcap   (also at /lab-data/suricata/capture.pcap)
  /opt/lab_data/suricata/local.rules

capture.pcap : a corporate-network capture mixing benign HTTP/DNS noise with
               five distinct malicious behaviours (a Log4Shell exploit probe,
               Cobalt Strike C2 beaconing, a TCP SYN port scan, lookups of a
               known-bad C2 domain, and an automated SQL-injection tool).
local.rules  : five detection signatures (sid 1000001-1000005) that fire on
               those five behaviours.

Run the engine over the capture, then read the alerts with jq:
  suricata -r /opt/lab_data/suricata/capture.pcap \
           -S /opt/lab_data/suricata/local.rules \
           -l /tmp/out -k none
  cat /tmp/out/fast.log
  jq -c 'select(.event_type=="alert")' /tmp/out/eve.json | head

Work through the tasks in the training portal panel on the right.
README

echo "[*] Suricata lab setup complete."
ls -lh "${LAB_DIR}/" 2>/dev/null || true
exit 0
