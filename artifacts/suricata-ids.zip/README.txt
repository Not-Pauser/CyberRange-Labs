SURICATA IDS LAB - Artifact Kit
================================

FILES INCLUDED:
- sample_rules.rules  : 15 Suricata detection rules (study and modify)
- alert_output.json   : Suricata EVE JSON output (newline-delimited)
- traffic_summary.txt : High-level traffic analysis summary

SCENARIO:
Suricata IDS was running on the network perimeter on March 17, 2025.
The EVE JSON log contains both alert and flow events from the 24-hour capture.

LAB TASKS:
1. RULE ANALYSIS: Study each rule in sample_rules.rules
   - Understand the detection logic
   - Identify what each rule detects
   - Note limitations of each rule

2. EVE JSON ANALYSIS: Parse and analyze alert_output.json
   - Use jq or Python to extract alert events
   - Group alerts by signature_id, severity, and src/dst IP
   - Build a timeline of the attack

3. ATTACK RECONSTRUCTION:
   - Phase 1: Reconnaissance (port scan)
   - Phase 2: Initial access (SSH brute force)
   - Phase 3: Malware delivery (HTTP exe download)
   - Phase 4: Command & Control (reverse shell + TLS beacon)
   - Phase 5: Discovery (DGA + DNS queries)
   - Phase 6: Lateral movement (SMB)
   - Phase 7: Exfiltration (DNS tunnel + large transfers)

4. RULE WRITING: Write 3 new rules to detect:
   - Specific JA3 hash for known C2 framework
   - Base64-encoded data in DNS subdomain
   - Unusual SMB activity from non-server hosts

USEFUL COMMANDS:
  cat alert_output.json | jq 'select(.event_type=="alert")' | jq '.alert.signature'
  cat alert_output.json | jq 'select(.alert.severity==1)' | jq '{time: .timestamp, sig: .alert.signature}'
