#!/bin/bash
###############################################################################
# setup.sh — Network Traffic Analysis with Wireshark lab
#
# Runs ON the lab VM (Ubuntu 22.04 desktop) as root after the artifact zip is
# extracted to /opt/lab_data and invoked via `qm guest exec`.
#
# Responsibilities (kept deliberately small — no Splunk, no data generation):
#   1. Install wireshark + tshark (non-interactive; allow non-root capture).
#   2. Create /lab-data/wireshark/ and the /lab-data -> /opt/lab_data symlink
#      that the other labs use.
#   3. Copy the two pre-generated, deterministic pcaps from /opt/lab_data/ to
#      /lab-data/wireshark/ so they sit exactly where material.md references.
#
# The pcaps are GENERATED OFFLINE by generate_pcaps.py and shipped inside the
# artifact zip — they are NOT produced here, so grading stays 100% reproducible.
#
# Idempotent + always exits 0.
###############################################################################
set -uo pipefail
export DEBIAN_FRONTEND=noninteractive

LAB_SRC="/opt/lab_data"
LAB_DIR="/lab-data/wireshark"

echo "[*] === Wireshark Network Traffic Analysis lab setup ==="

# ── 1. Install Wireshark + tshark (non-interactive) ─────────────────────────
# Preseed the setuid prompt so dpkg never blocks waiting for input.
echo "wireshark-common wireshark-common/install-setuid boolean true" | debconf-set-selections 2>/dev/null || true
if ! command -v tshark >/dev/null 2>&1; then
    echo "[*] Installing wireshark + tshark ..."
    apt-get update -y -qq 2>/dev/null || true
    apt-get install -y -qq wireshark tshark >/dev/null 2>&1 \
        || apt-get install -y -qq tshark >/dev/null 2>&1 || true
    dpkg-reconfigure -f noninteractive wireshark-common 2>/dev/null || true
else
    echo "[+] tshark already installed"
fi

# ── 2. Lab directory + /lab-data symlink (matches the other labs) ───────────
ln -sf "${LAB_SRC}" /lab-data 2>/dev/null || true
mkdir -p "${LAB_DIR}"

# ── 3. Place the deterministic pcaps where material.md expects them ─────────
for f in mixed-traffic.pcap portscan.pcap; do
    if [ -f "${LAB_SRC}/${f}" ]; then
        cp -f "${LAB_SRC}/${f}" "${LAB_DIR}/${f}"
        echo "[+] ${LAB_DIR}/${f}"
    else
        echo "[!] WARNING: ${LAB_SRC}/${f} not found in artifact bundle"
    fi
done

# Make the captures world-readable so the GUI/RDP user can open them.
chmod 0644 "${LAB_DIR}"/*.pcap 2>/dev/null || true

# ── 4. Short README for the trainee ─────────────────────────────────────────
cat > "${LAB_DIR}/README.txt" <<'README'
=== Network Traffic Analysis with Wireshark ===

Capture files (open in Wireshark, or analyse with tshark):
  /lab-data/wireshark/mixed-traffic.pcap
  /lab-data/wireshark/portscan.pcap

mixed-traffic.pcap : corporate capture with benign HTTP/HTTPS/DNS plus a
                     malicious credential-stealing HTTP POST, a malicious
                     HTTP executable download, and DNS-tunnelling queries.
portscan.pcap      : a TCP SYN (half-open) scan from one external host
                     against one internal server.

Work through the tasks in the training portal panel on the right.
README

echo "[*] Wireshark lab setup complete."
ls -lh "${LAB_DIR}/" 2>/dev/null || true
exit 0

# Remove this provisioning script so the trainee sees only the lab data, not how it was built.
rm -f /opt/lab_data/setup.sh 2>/dev/null || true
