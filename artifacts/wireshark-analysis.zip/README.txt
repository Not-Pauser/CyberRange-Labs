WIRESHARK ANALYSIS LAB - Artifact Kit
======================================

FILES INCLUDED:
- packet_summary.csv      : Exported packet data (CSV format matching Wireshark export)
- dns_queries.txt          : Extracted DNS query log
- http_transactions.txt    : Extracted HTTP transaction log

SCENARIO:
Network traffic was captured from the corporate LAN on March 12, 2025.
The capture contains ~3500 packets including normal and malicious activity.

Since generating real PCAP files requires specialized tools, this lab uses
CSV-exported packet data that mirrors what you would see in Wireshark.

ANALYSIS TASKS:
1. RECONNAISSANCE: Identify the port scan (sequential SYN packets from external IP)
2. BRUTE FORCE: Find the SSH brute force attempt (repeated SSH connections)
3. MALWARE DELIVERY: Locate the HTTP download of a suspicious .exe file
4. C2 COMMUNICATION: Identify the regular beaconing pattern to external IP
5. DATA EXFILTRATION: Find DNS tunneling activity (long encoded subdomains)

KEY INDICATORS:
- Attacker IP: External IP performing scan + brute force
- C2 IP: Different external IP receiving beacons
- Beaconing: Regular ~5 minute intervals
- DNS Exfil: TXT queries with encoded data to suspicious domain
- Malware: .exe downloaded over HTTP (not HTTPS!)

WIRESHARK DISPLAY FILTER EQUIVALENTS:
- Port scan: ip.src == [attacker] && tcp.flags.syn == 1
- SSH brute: ssh && ip.src == [attacker]
- HTTP downloads: http.request.method == GET && http contains ".exe"
- Beaconing: ip.dst == [c2] && tls
- DNS exfil: dns.qry.name contains "update-service"
