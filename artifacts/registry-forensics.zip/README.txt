REGISTRY FORENSICS LAB - Artifact Kit
=======================================

FILES INCLUDED:
- run_keys.txt          : HKCU/HKLM Run/RunOnce key analysis
- user_accounts.txt     : SAM hive user account extraction
- recent_docs.txt       : MRU (Most Recently Used) document lists
- usb_history.txt       : USB device connection history from SYSTEM hive
- installed_software.txt: Installed programs from SOFTWARE hive

SCENARIO:
Registry hives were extracted from the forensic image of WS-DEV03.
Analyze the registry artifacts to find evidence of compromise and persistence.

ANALYSIS TASKS:
1. PERSISTENCE (run_keys.txt):
   - Identify which Run key entries are legitimate vs malicious
   - Determine the persistence mechanism used by the attacker
   - Note the RunOnce entry for anti-forensic cleanup

2. USER ACCOUNTS (user_accounts.txt):
   - Identify the attacker-created account
   - Note the re-enabled Administrator account
   - Check for suspicious group memberships
   - Verify password change timestamps

3. USER ACTIVITY (recent_docs.txt):
   - Trace the malicious document that started the attack
   - Find evidence of tool usage (procdump, malware)
   - Identify exfiltration staging activity
   - Trace access to network shares

4. USB FORENSICS (usb_history.txt):
   - Identify the USB device used for exfiltration
   - Note the first-time-connected device on the attack day
   - Correlate with recent folders accessed

5. SOFTWARE ANALYSIS (installed_software.txt):
   - Find recently installed suspicious software
   - Identify programs with no/fake publisher
   - Note software installed on the attack day

KEY REGISTRY FORENSIC LOCATIONS:
- Run keys: HKCU/HKLM\...\CurrentVersion\Run
- SAM accounts: SAM\Domains\Account\Users
- Recent docs: NTUSER.DAT\...\RecentDocs
- USB devices: SYSTEM\CurrentControlSet\Enum\USBSTOR
- Installed software: SOFTWARE\...\Uninstall
