
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up Registry Forensics lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null
$logPath = "C:\LabData"

# Create registry artifacts for investigation
Write-Host "[*] Planting registry artifacts..."

# Add suspicious Run key entries
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "SystemHealthCheck" /t REG_SZ /d "C:\Users\Public\updater.exe -hidden" /f 2>$null
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "WindowsDefenderUpdate" /t REG_SZ /d "powershell.exe -enc aQBwAGMAbwBuAGYAaQBnAA==" /f 2>$null

# Export registry data for analysis
reg export "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" "$logPath\HKLM_Run.reg" /y 2>$null
reg export "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" "$logPath\HKCU_Run.reg" /y 2>$null
reg export "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall" "$logPath\Installed_Software.reg" /y 2>$null

# Create USB history export
$usbInfo = @"
USB Storage Device History (from USBSTOR registry key):

Device 1:
  FriendlyName: Kingston DataTraveler 3.0
  SerialNumber: E0D55EA573F3F180
  FirstInstall: 2026-03-15 08:00:12
  LastArrival:  2026-03-18 10:45:33
  LastRemoval:  2026-03-18 11:02:15

Device 2:
  FriendlyName: SanDisk Ultra USB 3.0
  SerialNumber: 4C530001220803
  FirstInstall: 2026-03-01 14:30:45
  LastArrival:  2026-03-10 09:00:22
  LastRemoval:  2026-03-10 17:45:10
"@
Set-Content -Path "$logPath\usb_history.txt" -Value $usbInfo

# Recent documents MRU
$recentDocs = @"
Recent Documents (from NTUSER.DAT RecentDocs):

  2026-03-18 10:15  passwords.txt
  2026-03-18 09:30  data_export.zip
  2026-03-18 09:05  Q1-Revenue.xlsx
  2026-03-17 16:00  Meeting_Notes.docx
  2026-03-17 11:30  Quarterly_Report.pptx
  2026-03-16 14:00  Employee_List.csv

OpenSaveMRU (files opened/saved via dialog):
  2026-03-18 10:00  E:\backup\data_export.zip  (USB Drive)
  2026-03-18 09:30  C:\Users\jsmith\Desktop\data_export.zip
"@
Set-Content -Path "$logPath\recent_documents.txt" -Value $recentDocs

# Software installation timeline
$swTimeline = @"
Software Installation Timeline (from registry Uninstall keys):

  2026-01-15  Microsoft Office 365 ProPlus
  2026-01-15  Google Chrome 120.0
  2026-02-01  7-Zip 23.01
  2026-02-15  Notepad++ 8.6
  2026-03-10  PuTTY 0.80          ** Unusual - SSH client on workstation
  2026-03-15  WinSCP 6.1          ** Unusual - SFTP client, data transfer?
  2026-03-18  CCleaner 6.10       ** Suspicious - anti-forensics tool
"@
Set-Content -Path "$logPath\software_timeline.txt" -Value $swTimeline

@"
=== Windows Registry Forensics Lab ===

Files:
  HKLM_Run.reg             - HKLM Run key export (auto-start programs)
  HKCU_Run.reg             - HKCU Run key export (per-user auto-start)
  Installed_Software.reg   - Installed software registry export
  usb_history.txt          - USB device connection history
  recent_documents.txt     - Recently opened documents
  software_timeline.txt    - Software installation timeline

Analysis with PowerShell:
  # Check Run keys for persistence
  Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
  Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"

  # Check installed software
  Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" | Select DisplayName, InstallDate | Sort InstallDate

  # Check USB history
  Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR\*\*" 2>$null | Select FriendlyName

Your goal: Find persistence mechanisms, suspicious installs, and trace USB activity.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] Registry Forensics lab setup complete."
