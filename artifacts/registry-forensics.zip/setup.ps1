
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === Registry Forensics Lab Setup ==="
New-Item -Path "C:\LabData\registry" -ItemType Directory -Force | Out-Null

Write-Host "[*] Planting registry artifacts..."

# Plant suspicious Run key persistence
reg add "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "SystemHealthMonitor" /t REG_SZ /d "C:\Users\Public\health_check.exe -silent" /f 2>$null
reg add "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" /v "WindowsDefenderUpdate" /t REG_SZ /d "powershell.exe -WindowStyle Hidden -enc aQBwAGMAbwBuAGYAaQBnAA==" /f 2>$null

# Plant suspicious service
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHealthSvc" /v "ImagePath" /t REG_EXPAND_SZ /d "C:\Windows\Temp\svc_update.exe" /f 2>$null
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHealthSvc" /v "DisplayName" /t REG_SZ /d "System Health Service" /f 2>$null
reg add "HKLM\SYSTEM\CurrentControlSet\Services\SysHealthSvc" /v "Start" /t REG_DWORD /d 2 /f 2>$null

# Export registry hives for offline analysis
Write-Host "[*] Exporting registry hives..."
reg save HKLM\SAM "C:\LabData\registry\SAM" /y 2>$null
reg save HKLM\SYSTEM "C:\LabData\registry\SYSTEM" /y 2>$null
reg save HKLM\SOFTWARE "C:\LabData\registry\SOFTWARE" /y 2>$null
reg save HKLM\SECURITY "C:\LabData\registry\SECURITY" /y 2>$null
reg save HKCU "C:\LabData\registry\NTUSER.DAT" /y 2>$null

# Export Run keys for easy analysis
reg export "HKLM\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" "C:\LabData\registry\HKLM_Run.reg" /y 2>$null
reg export "HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\Run" "C:\LabData\registry\HKCU_Run.reg" /y 2>$null
reg export "HKLM\SYSTEM\CurrentControlSet\Services" "C:\LabData\registry\Services.reg" /y 2>$null

@"
=== Windows Registry Forensics Lab ===

Registry hive exports: C:\LabData\registry\
  SAM, SYSTEM, SOFTWARE, SECURITY, NTUSER.DAT

Also exported as .reg text files:
  HKLM_Run.reg, HKCU_Run.reg, Services.reg

Live analysis with PowerShell:
  # Check Run keys (persistence)
  Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"
  Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Run"

  # Check services
  Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Services\*" | Where-Object {`$_.ImagePath -like "*temp*" -or `$_.ImagePath -like "*public*"} | Select PSChildName, ImagePath

  # Recent documents
  Get-ItemProperty "HKCU:\SOFTWARE\Microsoft\Windows\CurrentVersion\Explorer\RecentDocs" 2>$null

  # USB history
  Get-ItemProperty "HKLM:\SYSTEM\CurrentControlSet\Enum\USBSTOR\*\*" 2>$null | Select FriendlyName

  # Installed software
  Get-ItemProperty "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Uninstall\*" | Select DisplayName, InstallDate | Sort InstallDate -Desc | Select -First 20

Investigate: Find persistence mechanisms, suspicious services, and trace user activity.
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] Registry Forensics lab ready."
