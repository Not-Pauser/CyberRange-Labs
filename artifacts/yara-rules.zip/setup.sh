#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive

echo "[*] Installing YARA and dependencies..."
apt-get update -qq
apt-get install -y -qq yara python3 python3-pip > /dev/null 2>&1
pip3 install yara-python > /dev/null 2>&1

mkdir -p /opt/lab_data/samples /opt/lab_data/rules
cd /opt/lab_data

echo "[*] Creating malware samples for scanning..."
python3 << 'PYEOF'
import os, struct, random

# Sample 1: Suspicious executable with C2 strings
with open("samples/suspicious_update.bin", "wb") as f:
    f.write(b"MZ")  # DOS header
    f.write(b"\x90" * 58)
    f.write(struct.pack("<I", 0x80))
    f.write(b"\x00" * 56)
    f.write(b"PE\x00\x00")  # PE signature
    f.write(b"\x00" * 200)
    # Suspicious strings
    f.write(b"cmd.exe /c whoami\x00")
    f.write(b"powershell.exe -enc\x00")
    f.write(b"http://c2.evil-domain.com/beacon\x00")
    f.write(b"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\x00")
    f.write(b"CreateRemoteThread\x00")
    f.write(b"VirtualAllocEx\x00")
    f.write(os.urandom(4096))

# Sample 2: Benign-looking document with macro indicators
with open("samples/quarterly_report.doc", "wb") as f:
    f.write(b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1")  # OLE header
    f.write(b"\x00" * 500)
    f.write(b"Sub AutoOpen()\x00")
    f.write(b"Shell(\"cmd.exe /c net user hacker P@ss123 /add\")\x00")
    f.write(b"Shell(\"cmd.exe /c net localgroup administrators hacker /add\")\x00")
    f.write(os.urandom(2048))

# Sample 3: Clean PDF (false positive test)
with open("samples/invoice_2026.pdf", "wb") as f:
    f.write(b"%PDF-1.4\n")
    f.write(b"1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n")
    f.write(b"This is a normal invoice document\n")
    f.write(os.urandom(1024))

# Sample 4: Ransomware-like binary
with open("samples/system_health.exe", "wb") as f:
    f.write(b"MZ")
    f.write(b"\x90" * 58)
    f.write(struct.pack("<I", 0x80))
    f.write(b"\x00" * 56)
    f.write(b"PE\x00\x00")
    f.write(b"\x00" * 200)
    f.write(b"CryptEncrypt\x00")
    f.write(b"CryptGenKey\x00")
    f.write(b"FindFirstFileW\x00")
    f.write(b"FindNextFileW\x00")
    f.write(b".encrypted\x00")
    f.write(b"YOUR FILES HAVE BEEN ENCRYPTED\x00")
    f.write(b"Send 0.5 BTC to bc1q42lje80dk7q084p90lm9dn02a8x5d0kf3tg23e\x00")
    f.write(os.urandom(4096))

# Sample 5: Trojanized DLL
with open("samples/helper.dll", "wb") as f:
    f.write(b"MZ")
    f.write(b"\x90" * 58)
    f.write(struct.pack("<I", 0x80))
    f.write(b"\x00" * 56)
    f.write(b"PE\x00\x00")
    f.write(b"\x00" * 200)
    f.write(b"http://185.220.101.42:8443/stage2\x00")
    f.write(b"URLDownloadToFileA\x00")
    f.write(b"WinExec\x00")
    f.write(b"%TEMP%\\payload.exe\x00")
    f.write(os.urandom(3072))

print("Created 5 sample files in samples/")
PYEOF

# Starter YARA rule
cat > /opt/lab_data/rules/example.yar << 'EOF'
rule ExampleRule_PEFile {
    meta:
        description = "Detects PE executables"
        author = "Lab Student"
    strings:
        $mz = { 4D 5A }
        $pe = "PE\x00\x00"
    condition:
        $mz at 0 and $pe
}
EOF

cat > /opt/lab_data/README.txt << 'EOF'
=== YARA Rule Writing Lab ===

Files:
  samples/                    - Directory containing files to scan
    suspicious_update.bin     - Suspicious executable
    quarterly_report.doc      - Document with macro indicators
    invoice_2026.pdf          - Clean PDF (test for false positives)
    system_health.exe         - Ransomware-like binary
    helper.dll                - Trojanized DLL
  rules/example.yar           - Example YARA rule to get started

Quick start:
  # Scan all samples with a rule
  yara /opt/lab_data/rules/example.yar /opt/lab_data/samples/

  # Scan with multiple rules
  yara -r /opt/lab_data/rules/ /opt/lab_data/samples/

  # Test a new rule
  echo 'rule Test { strings: $s = "cmd.exe" condition: $s }' > /opt/lab_data/rules/test.yar
  yara /opt/lab_data/rules/test.yar /opt/lab_data/samples/

  # View strings in a file
  strings /opt/lab_data/samples/suspicious_update.bin

Your goal: Write YARA rules to detect each malicious sample without false positives on the PDF.
EOF

echo "[+] YARA rules lab setup complete."
