#!/bin/bash
set -e
export DEBIAN_FRONTEND=noninteractive
echo "[*] === YARA Rule Writing Lab Setup ==="

apt-get update -qq
apt-get install -y -qq yara python3 python3-pip > /dev/null 2>&1
pip3 install yara-python > /dev/null 2>&1

mkdir -p /opt/lab_data/yara/samples /opt/lab_data/yara/rules
ln -sf /opt/lab_data /lab-data 2>/dev/null || true
cd /opt/lab_data/yara

echo "[*] Creating realistic malware samples..."
python3 << 'PYEOF'
import struct, os, random, hashlib

random.seed(42)
samples_dir = "samples"

def make_pe(extra_data, sections=3):
    """Build a minimal but valid-looking PE binary."""
    dos = b"MZ" + b"\x90" * 58 + struct.pack("<I", 0x80) + b"\x00" * 24
    pe_sig = b"PE\x00\x00"
    # COFF header: i386, N sections, timestamp
    coff = struct.pack("<HHIIIHH", 0x14C, sections, 1711000000, 0, 0, 0xE0, 0x0102)
    # Optional header (minimal)
    opt = struct.pack("<HBBIIIIIII", 0x10B, 14, 0, 0x1000, 0x1000, 0x1000, 0x1000, 0x400000, 0x1000, 0x200)
    opt += b"\x00" * (0xE0 - len(opt))
    # Section headers
    sects = b""
    for i, name in enumerate([b".text\x00\x00\x00", b".rdata\x00\x00", b".data\x00\x00\x00"][:sections]):
        sects += name + struct.pack("<IIIIHHI", 0x1000, (i+1)*0x1000, 0x200, (i+1)*0x200, 0, 0, 0) + struct.pack("<I", 0xE0000060 if i==0 else 0xC0000040)
    return dos + pe_sig + coff + opt + sects + extra_data

# Sample 1: Trojan with C2 + persistence strings
data1 = b"\x00" * 200
data1 += b"cmd.exe /c whoami\x00"
data1 += b"powershell.exe -enc\x00"
data1 += b"http://c2.evil-domain.com/beacon\x00"
data1 += b"http://185.220.101.42:8443/stage2\x00"
data1 += b"HKLM\\SOFTWARE\\Microsoft\\Windows\\CurrentVersion\\Run\\SystemHealth\x00"
data1 += b"CreateRemoteThread\x00VirtualAllocEx\x00WriteProcessMemory\x00"
data1 += b"WS2_32.dll\x00kernel32.dll\x00ntdll.dll\x00advapi32.dll\x00"
data1 += b"Mozilla/5.0 CobaltStrike\x00"
data1 += os.urandom(4096)
with open(f"{samples_dir}/suspicious_update.exe", "wb") as f:
    f.write(make_pe(data1))

# Sample 2: OLE document with macro
ole_magic = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
macro_code = b"Sub AutoOpen()\x00"
macro_code += b"Shell(\"cmd.exe /c net user hacker P@ss123 /add\")\x00"
macro_code += b"Shell(\"cmd.exe /c net localgroup administrators hacker /add\")\x00"
macro_code += b"Dim objShell\x00Set objShell = CreateObject(\"WScript.Shell\")\x00"
with open(f"{samples_dir}/quarterly_report.doc", "wb") as f:
    f.write(ole_magic + b"\x00" * 500 + macro_code + os.urandom(2048))

# Sample 3: Clean PDF
with open(f"{samples_dir}/invoice_2026.pdf", "wb") as f:
    f.write(b"%PDF-1.4\n1 0 obj<</Type/Catalog/Pages 2 0 R>>endobj\n")
    f.write(b"2 0 obj<</Type/Pages/Kids[3 0 R]/Count 1>>endobj\n")
    f.write(b"This is a legitimate invoice document for Q1 2026.\n")
    f.write(b"No malicious content here.\n" * 20)
    f.write(os.urandom(512))

# Sample 4: Ransomware
data4 = b"\x00" * 200
data4 += b"CryptEncrypt\x00CryptGenKey\x00CryptAcquireContext\x00"
data4 += b"FindFirstFileW\x00FindNextFileW\x00"
data4 += b".encrypted\x00.locked\x00"
data4 += b"YOUR FILES HAVE BEEN ENCRYPTED\x00"
data4 += b"Send 0.5 BTC to bc1q42lje80dk7q084p90lm9dn02a8x5d0kf3tg23e\x00"
data4 += b"DO NOT attempt to decrypt files manually\x00"
data4 += b"Contact: ransom@protonmail.com\x00"
data4 += os.urandom(4096)
with open(f"{samples_dir}/system_health.exe", "wb") as f:
    f.write(make_pe(data4))

# Sample 5: Downloader DLL
data5 = b"\x00" * 200
data5 += b"http://185.220.101.42:8443/stage2.dll\x00"
data5 += b"URLDownloadToFileA\x00WinExec\x00ShellExecuteA\x00"
data5 += b"%TEMP%\\payload.exe\x00"
data5 += b"wininet.dll\x00urlmon.dll\x00shell32.dll\x00"
data5 += os.urandom(3072)
with open(f"{samples_dir}/helper.dll", "wb") as f:
    f.write(make_pe(data5, sections=2))

# Print hashes
for fn in sorted(os.listdir(samples_dir)):
    path = f"{samples_dir}/{fn}"
    data = open(path, "rb").read()
    print(f"  {fn}: MD5={hashlib.md5(data).hexdigest()}, SHA256={hashlib.sha256(data).hexdigest()[:32]}..., {len(data)} bytes")
PYEOF

# Starter rules
cat > /opt/lab_data/yara/rules/examples.yar << 'YARAEOF'
rule PE_File {
    meta:
        description = "Detects PE executables"
        author = "Example"
    strings:
        $mz = { 4D 5A }
        $pe = "PE\x00\x00"
    condition:
        $mz at 0 and $pe
}

rule OLE_Document {
    meta:
        description = "Detects OLE2 documents (Office)"
    strings:
        $ole = { D0 CF 11 E0 A1 B1 1A E1 }
    condition:
        $ole at 0
}

// TODO: Write your own rules below
YARAEOF

cat > /opt/lab_data/yara/README.txt << 'EOF'
=== YARA Rule Writing Lab ===

Samples to scan:
  samples/suspicious_update.exe  - Trojan with C2 + persistence
  samples/quarterly_report.doc   - Macro-enabled document
  samples/invoice_2026.pdf       - Clean PDF (false positive test)
  samples/system_health.exe      - Ransomware
  samples/helper.dll             - Downloader DLL

Starter rules: rules/examples.yar

Usage:
  yara rules/examples.yar samples/
  yara -s rules/examples.yar samples/suspicious_update.exe
  echo 'rule MyRule { strings: $s = "cmd.exe" condition: $s }' > rules/my_rules.yar
  yara rules/my_rules.yar samples/

  # Extract strings for analysis
  strings samples/suspicious_update.exe | grep -i "http\|dll\|exe\|cmd"
EOF

echo "[+] YARA rules lab ready."
