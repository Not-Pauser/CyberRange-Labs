YARA RULES LAB - Artifact Kit
===============================

FILES INCLUDED:
- samples/clean1.txt      : Clean business document (should NOT match)
- samples/clean2.txt      : Clean system log (should NOT match)
- samples/malware1.bin    : RAT with C2 indicators
- samples/malware2.bin    : Dropper/loader
- samples/malware3.bin    : Credential stealer
- samples/suspicious.bin  : Gray area file (admin tool or malware?)
- starter_rules.yar       : Template YARA rules to complete

SCENARIO:
You have 6 files from an incident response case. Some are clean,
some are malicious. Write YARA rules to detect the malicious samples
without false-positiving on the clean files.

LAB TASKS:
1. SAMPLE ANALYSIS:
   - Examine each sample with `strings` command
   - Identify unique indicators in each malware sample
   - Note what makes clean files different from malware

2. RULE WRITING (starter_rules.yar):
   - Complete the 5 TODO rules in the starter file
   - Write 3 additional bonus rules
   - Each rule should detect at least 1 malware sample
   - NO rule should match the clean files (false positives!)

3. TESTING:
   - Run: yara starter_rules.yar samples/
   - Verify malware files are detected
   - Verify clean files are NOT detected
   - Verify the suspicious.bin classification

4. RULE QUALITY:
   - Use specific string combinations (not single strings)
   - Add proper metadata (author, description, severity, MITRE)
   - Use conditions that minimize false positives
   - Consider using PE module: import "pe"

YARA CHEAT SHEET:
  strings:
    $text = "plain text"           // text string
    $hex = { 4D 5A 90 00 }        // hex pattern
    $regex = /[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}/  // regex
    $wide = "text" wide            // UTF-16LE string
  condition:
    uint16(0) == 0x5A4D            // MZ header check
    all of ($api*)                 // all strings matching prefix
    3 of ($indicator*)             // at least 3 matches
    filesize < 1MB                 // size constraint
