// YARA Rules Lab - Starter Rules
// Modify and extend these rules to detect the malware samples
// Test with: yara starter_rules.yar samples/

rule Suspicious_PE_File {
    // Rule 1: Basic PE file detection
    // This matches ANY PE file - too broad! Improve it.
    meta:
        author = "Student"
        description = "Detects PE files"
        severity = "info"
    condition:
        uint16(0) == 0x5A4D  // MZ header
}

rule YOURNAME_C2_Infrastructure {
    // Rule 2: TODO - Write a rule to detect C2 infrastructure indicators
    // Look at the malware samples for IP addresses and domain names
    meta:
        author = "Student"
        description = "TODO: Detect C2 indicators"
        severity = "high"
        mitre_attack = "T1071.001"
    strings:
        // TODO: Add strings for C2 IPs and domains
        // $ip1 = "???.???.???.??"
        // $domain1 = "???-???-???.xyz"
        $placeholder = "REPLACE_ME"
    condition:
        $placeholder  // TODO: Fix this condition
}

rule YOURNAME_Process_Injection {
    // Rule 3: TODO - Write a rule to detect process injection capabilities
    // Look for combinations of suspicious API imports
    meta:
        author = "Student"
        description = "TODO: Detect process injection APIs"
        severity = "critical"
        mitre_attack = "T1055"
    strings:
        // TODO: Add API strings that indicate process injection
        // Hint: VirtualAlloc + WriteProcessMemory + CreateRemoteThread
        $placeholder = "REPLACE_ME"
    condition:
        $placeholder  // TODO: requires PE file AND multiple injection APIs
}

rule YOURNAME_Credential_Theft {
    // Rule 4: TODO - Write a rule to detect credential theft tools
    // Look for strings related to credential dumping
    meta:
        author = "Student"
        description = "TODO: Detect credential theft indicators"
        severity = "critical"
        mitre_attack = "T1003"
    strings:
        // TODO: Add strings found in credential stealers
        // Hint: lsass, sekurlsa, MiniDump, SAM, SECURITY
        $placeholder = "REPLACE_ME"
    condition:
        $placeholder  // TODO: Fix condition - should require multiple indicators
}

rule YOURNAME_Anti_Analysis {
    // Rule 5: TODO - Write a rule to detect anti-analysis techniques
    meta:
        author = "Student"
        description = "TODO: Detect anti-analysis/evasion"
        severity = "medium"
        mitre_attack = "T1497"
    strings:
        // TODO: Add strings for VM/debugger detection
        // Hint: vmware, virtualbox, IsDebuggerPresent, sandbox
        $placeholder = "REPLACE_ME"
    condition:
        $placeholder
}

// BONUS RULES - Write from scratch:
// Rule 6: Detect malware persistence via registry Run keys
// Rule 7: Detect encoded PowerShell execution
// Rule 8: Detect data exfiltration indicators
