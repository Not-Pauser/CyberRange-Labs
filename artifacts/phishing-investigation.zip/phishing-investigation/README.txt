=== Phishing Email Investigation Lab ===

Location: C:\LabData\ (Windows) or /opt/lab_data/ (Linux)

Files:
  emails/suspicious_email_1.eml  - Email claiming to be from Amazon
  emails/suspicious_email_2.eml  - Email claiming to be from a business partner
  emails/legitimate_email_3.eml  - Legitimate internal IT email (baseline)
  analysis_guide.txt             - Header analysis reference

Your Tasks:
  1. Analyze headers of each email (Return-Path, Received, SPF/DKIM/DMARC)
  2. Identify which emails are phishing and which are legitimate
  3. Extract all IOCs (IPs, domains, URLs, file hashes)
  4. Examine attachments (type, hash, suspicious characteristics)
  5. Write an incident report for the phishing emails

Tools:
  - Notepad/text editor for .eml header examination
  - PowerShell for hash calculation: Get-FileHash <file>
  - Browser dev tools for safe URL inspection (DO NOT click links)
