
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up Phishing Investigation lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null
$logPath = "C:\LabData"

# Create phishing email (.eml format)
@"
Return-Path: <no-reply@hr-beneflts-update.com>
Received: from smtp.hr-beneflts-update.com (198.51.100.55)
        by mail.corp.local (10.0.2.5) with SMTP id abc123;
        Mon, 18 Mar 2026 08:42:15 +0000
Received: from [192.168.1.100] (unknown [198.51.100.55])
        by smtp.hr-beneflts-update.com with ESMTP;
        Mon, 18 Mar 2026 08:42:00 +0000
From: "IT Security Team" <security@hr-beneflts-update.com>
Reply-To: helpdesk@secure-login-portal.com
To: all-employees@corp.local
Subject: [ACTION REQUIRED] Password Expiry - Reset Within 24 Hours
Date: Mon, 18 Mar 2026 08:42:00 +0000
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_NextPart_001"
X-Mailer: PHPMailer 6.8.0
Message-ID: <fake123@hr-beneflts-update.com>
Authentication-Results: mail.corp.local;
    spf=fail (sender IP not authorized for hr-beneflts-update.com);
    dkim=fail (no DKIM signature found);
    dmarc=fail

------=_NextPart_001
Content-Type: text/html; charset="UTF-8"

<html>
<body style="font-family: Arial, sans-serif;">
<div style="max-width: 600px; margin: 0 auto; border: 1px solid #ddd; padding: 20px;">
<img src="http://hr-beneflts-update.com/logo.png" alt="Corp IT" style="height: 50px;">
<h2>Urgent: Password Expiration Notice</h2>
<p>Dear Employee,</p>
<p>Your corporate password will expire in <strong>24 hours</strong>. To avoid account lockout, please reset your password immediately using the secure portal below:</p>
<p style="text-align: center;">
<a href="http://hr-beneflts-update.com/reset?user=employee&token=a8f3e2" style="background: #0078d4; color: white; padding: 12px 30px; text-decoration: none; border-radius: 5px; display: inline-block;">Reset Password Now</a>
</p>
<p><small>If the button doesn't work, copy this link: http://hr-beneflts-update.com/reset?user=employee&token=a8f3e2</small></p>
<p>This is an automated message from IT Security.<br>Do not reply to this email.</p>
<hr>
<p style="color: #888; font-size: 11px;">Corp IT Security | help@corp.local | ext. 4500</p>
</div>
</body>
</html>

------=_NextPart_001
Content-Type: application/octet-stream; name="Password_Reset_Form.pdf.exe"
Content-Disposition: attachment; filename="Password_Reset_Form.pdf.exe"
Content-Transfer-Encoding: base64

TVqQAAMAAAAEAAAA//8AALgAAAA[TRUNCATED - disguised executable]
------=_NextPart_001--
"@ | Set-Content -Path "$logPath\suspicious_email.eml" -Encoding UTF8

# Create second email (legitimate for comparison)
@"
Return-Path: <noreply@corp.local>
Received: from mail.corp.local (10.0.2.5)
        by mail.corp.local (10.0.2.5) with ESMTP;
        Mon, 18 Mar 2026 09:00:00 +0000
From: "IT Help Desk" <helpdesk@corp.local>
To: jsmith@corp.local
Subject: Your support ticket #4521 has been resolved
Date: Mon, 18 Mar 2026 09:00:00 +0000
MIME-Version: 1.0
Content-Type: text/plain; charset="UTF-8"
Authentication-Results: mail.corp.local;
    spf=pass;
    dkim=pass;
    dmarc=pass

Hi John,

Your support ticket #4521 (Outlook calendar sync issue) has been resolved.

If you're still experiencing issues, please reply to this email or call ext. 4500.

Thanks,
IT Help Desk
"@ | Set-Content -Path "$logPath\legitimate_email.eml" -Encoding UTF8

@"
=== Phishing Email Investigation & Triage Lab ===

Files:
  suspicious_email.eml   - Suspicious email to investigate
  legitimate_email.eml   - Known-good email for comparison

Investigation steps:
  1. Open both .eml files in Notepad to examine raw headers
  2. Compare header fields: Return-Path, From, Reply-To, Received, Authentication-Results
  3. Check for SPF/DKIM/DMARC pass/fail
  4. Examine URLs in the email body (DO NOT CLICK - analyze text only)
  5. Check the attachment name for double extensions
  6. Note the domain: "hr-beneflts-update.com" (typosquatting of "benefits")

PowerShell analysis:
  Get-Content C:\LabData\suspicious_email.eml | Select-String "Return-Path|From:|Reply-To|spf=|dkim=|dmarc="
  Get-Content C:\LabData\suspicious_email.eml | Select-String "http"

Your goal: Classify as phishing, extract all IOCs, and write an incident report.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] Phishing Investigation lab setup complete."
