<#
.SYNOPSIS
    Phishing Email Investigation & Triage - lab provisioning script.
.DESCRIPTION
    Deploys the reported phishing email and its attachment to a clear,
    well-known location on the analyst workstation so the trainee can
    examine the raw message and hash the attachment using built-in
    Windows tools (Notepad, PowerShell Get-FileHash). Also drops a
    desktop shortcut to the lab folder and a short README.

    The email body and the attachment are carried inside this script as
    base64 blobs and written out byte-for-byte, so the deployed files are
    identical on every run (the attachment hash is therefore stable).

    Runs on the Windows 11 lab VM after boot. Idempotent and self-contained.
.NOTES
    No analysis findings are recorded in this script. The trainee derives
    every answer by inspecting the deployed email and attachment.
#>
param(
    [string]$LabDataPath = "C:\LabData"
)

$ErrorActionPreference = "Stop"
Set-StrictMode -Version Latest

function Write-Status {
    param([string]$Message)
    Write-Host "[Provision] $Message" -ForegroundColor Cyan
}

# ---------------------------------------------------------------------------
# Embedded artifact payloads (base64). Decoded and written verbatim below.
# ---------------------------------------------------------------------------
$EmlBase64 = @'
UmV0dXJuLVBhdGg6IDxiaWxsaW5nQGRobC1wYXJjZWwtZGVsaXZlcnkudG9wPgpEZWxpdmVyZWQtVG86IGEuaGFkZGFkQG5vcnRod2luZC1sb2dpc3RpY3Mu
Y29tClJlY2VpdmVkOiBmcm9tIG14MDEubm9ydGh3aW5kLWxvZ2lzdGljcy5jb20gKG14MDEubm9ydGh3aW5kLWxvZ2lzdGljcy5jb20gWzEwLjEwLjAuMjVd
KQogICAgYnkgaW1hcC5ub3J0aHdpbmQtbG9naXN0aWNzLmNvbSAoRG92ZWNvdCkgd2l0aCBMTVRQIGlkIDdGMUMwQTkzRTIKICAgIGZvciA8YS5oYWRkYWRA
bm9ydGh3aW5kLWxvZ2lzdGljcy5jb20+OwogICAgVGh1LCAwNCBKdW4gMjAyNiAwODo0MToxMiArMDAwMCAoVVRDKQpSZWNlaXZlZDogZnJvbSB2cHMtZGUt
OTEuYnVsbGV0cHJvb2YtaG9zdC50b3AgKHZwcy1kZS05MS5idWxsZXRwcm9vZi1ob3N0LnRvcCBbMTg1LjIyMC4xMDEuNDddKQogICAgYnkgbXgwMS5ub3J0
aHdpbmQtbG9naXN0aWNzLmNvbSAoUG9zdGZpeCkgd2l0aCBFU01UUCBpZCA0QjJEOUY3QTFDCiAgICBmb3IgPGEuaGFkZGFkQG5vcnRod2luZC1sb2dpc3Rp
Y3MuY29tPjsKICAgIFRodSwgMDQgSnVuIDIwMjYgMDg6NDE6MDkgKzAwMDAgKFVUQykKUmVjZWl2ZWQ6IGZyb20gbG9jYWxob3N0IChsb2NhbGhvc3QgWzEy
Ny4wLjAuMV0pCiAgICBieSB2cHMtZGUtOTEuYnVsbGV0cHJvb2YtaG9zdC50b3AgKFBIUE1haWxlcikgd2l0aCBFU01UUAogICAgZm9yIDxhLmhhZGRhZEBu
b3J0aHdpbmQtbG9naXN0aWNzLmNvbT47CiAgICBUaHUsIDA0IEp1biAyMDI2IDA4OjQxOjA1ICswMDAwIChVVEMpCkF1dGhlbnRpY2F0aW9uLVJlc3VsdHM6
IG14MDEubm9ydGh3aW5kLWxvZ2lzdGljcy5jb207CiAgICBzcGY9ZmFpbCAoc2VuZGVyIElQIDE4NS4yMjAuMTAxLjQ3IGlzIG5vdCBwZXJtaXR0ZWQgdG8g
c2VuZCBtYWlsIGZvciBkaGwuY29tKQogICAgICAgIHNtdHAubWFpbGZyb209YmlsbGluZ0BkaGwtcGFyY2VsLWRlbGl2ZXJ5LnRvcDsKICAgIGRraW09ZmFp
bCAoYm9keSBoYXNoIGRpZCBub3QgdmVyaWZ5KSBoZWFkZXIuZD1kaGwuY29tOwogICAgZG1hcmM9ZmFpbCAocD1yZWplY3QpIGhlYWRlci5mcm9tPWRobC5j
b20KRnJvbTogIkRITCBFeHByZXNzIEN1c3RvbWVyIFN1cHBvcnQiIDxzdXBwb3J0QGRobC5jb20+ClJlcGx5LVRvOiA8Y2xlYXJhbmNlLXN1cHBvcnRAZGhs
LXBhcmNlbC1kZWxpdmVyeS50b3A+ClRvOiAiQW1pciBIYWRkYWQiIDxhLmhhZGRhZEBub3J0aHdpbmQtbG9naXN0aWNzLmNvbT4KU3ViamVjdDogWW91ciBE
SEwgcGFyY2VsIEFUWjg4NDEwMjlERSBpcyBvbiBob2xkIC0gY3VzdG9tcyBmZWUgcmVxdWlyZWQKRGF0ZTogVGh1LCAwNCBKdW4gMjAyNiAwODo0MTowMCAr
MDAwMApNZXNzYWdlLUlEOiA8MjAyNjA2MDQwODQxMDAuNEIyRDlGN0ExQ0BkaGwtcGFyY2VsLWRlbGl2ZXJ5LnRvcD4KTUlNRS1WZXJzaW9uOiAxLjAKWC1N
YWlsZXI6IFBIUE1haWxlciA2LjguMCAoaHR0cHM6Ly9naXRodWIuY29tL1BIUE1haWxlci9QSFBNYWlsZXIpClgtT3JpZ2luYXRpbmctSVA6IDE4NS4yMjAu
MTAxLjQ3CkNvbnRlbnQtVHlwZTogbXVsdGlwYXJ0L21peGVkOwogICAgYm91bmRhcnk9Ii0tLS09X0JvdW5kYXJ5X0RITF8yMDI2X1BISVNIIgoKVGhpcyBp
cyBhIG11bHRpLXBhcnQgbWVzc2FnZSBpbiBNSU1FIGZvcm1hdC4KCi0tLS0tLT1fQm91bmRhcnlfREhMXzIwMjZfUEhJU0gKQ29udGVudC1UeXBlOiB0ZXh0
L2h0bWw7IGNoYXJzZXQ9IlVURi04IgpDb250ZW50LVRyYW5zZmVyLUVuY29kaW5nOiA3Yml0Cgo8aHRtbD4KPGJvZHkgc3R5bGU9ImZvbnQtZmFtaWx5OiBB
cmlhbCwgSGVsdmV0aWNhLCBzYW5zLXNlcmlmOyBjb2xvcjojMzMzOyI+CjxkaXYgc3R5bGU9ImJhY2tncm91bmQ6I2ZmY2MwMDsgcGFkZGluZzoxNHB4OyB0
ZXh0LWFsaWduOmNlbnRlcjsiPgogIDxzcGFuIHN0eWxlPSJmb250LXNpemU6MjJweDsgZm9udC13ZWlnaHQ6Ym9sZDsgY29sb3I6I2Q0MDUxMTsiPkRITCBF
WFBSRVNTPC9zcGFuPgo8L2Rpdj4KPGRpdiBzdHlsZT0icGFkZGluZzoyMnB4OyBib3JkZXI6MXB4IHNvbGlkICNkZGQ7Ij4KPGgyIHN0eWxlPSJjb2xvcjoj
ZDQwNTExOyI+WW91ciBwYXJjZWwgaXMgb24gaG9sZDwvaDI+CjxwPkRlYXIgQ3VzdG9tZXIsPC9wPgo8cD5XZSBhdHRlbXB0ZWQgdG8gZGVsaXZlciB5b3Vy
IHBhcmNlbCAod2F5YmlsbCA8Yj5BVFo4ODQxMDI5REU8L2I+KSBidXQgYSBzbWFsbApvdXRzdGFuZGluZyBjdXN0b21zIGNsZWFyYW5jZSBmZWUgb2YgPGI+
RVVSIDIuOTk8L2I+IG11c3QgYmUgcGFpZCBiZWZvcmUgd2UgY2FuCmNvbXBsZXRlIGRlbGl2ZXJ5LjwvcD4KPHA+UGxlYXNlIGNvbmZpcm0geW91ciBzaGlw
bWVudCBhbmQgc2V0dGxlIHRoZSBmZWUgdXNpbmcgdGhlIG9mZmljaWFsIERITAp0cmFja2luZyBwb3J0YWwgYmVsb3c6PC9wPgo8cCBzdHlsZT0idGV4dC1h
bGlnbjpjZW50ZXI7Ij4KICA8YSBocmVmPSJodHRwczovL3NlY3VyZS1kaGwtcmVkZWxpdmVyeS5pbmZvL2NsZWFyYW5jZS9wYXk/cmVmPUFUWjg4NDEwMjlE
RSIKICAgICBzdHlsZT0iYmFja2dyb3VuZDojZDQwNTExOyBjb2xvcjojZmZmOyBwYWRkaW5nOjEycHggMjhweDsgdGV4dC1kZWNvcmF0aW9uOm5vbmU7CiAg
ICAgYm9yZGVyLXJhZGl1czozcHg7IGZvbnQtd2VpZ2h0OmJvbGQ7Ij4KICAgICBodHRwczovL3d3dy5kaGwuY29tL3RyYWNrCiAgPC9hPgo8L3A+CjxwPlRo
ZSBhdHRhY2hlZCBpbnZvaWNlIGNvbnRhaW5zIHlvdXIgc2hpcG1lbnQgZGV0YWlscy4gT3BlbiBpdCB0byByZXZpZXcgdGhlCmNoYXJnZXMuPC9wPgo8cD48
c21hbGw+SWYgdGhlIGZlZSBpcyBub3QgcGFpZCB3aXRoaW4gNDggaG91cnMgeW91ciBwYXJjZWwgd2lsbCBiZSByZXR1cm5lZCB0bwp0aGUgc2VuZGVyLjwv
c21hbGw+PC9wPgo8cD5LaW5kIHJlZ2FyZHMsPGJyPkRITCBFeHByZXNzIEN1c3RvbWVyIFN1cHBvcnQ8L3A+CjwvZGl2Pgo8L2JvZHk+CjwvaHRtbD4KCi0t
LS0tLT1fQm91bmRhcnlfREhMXzIwMjZfUEhJU0gKQ29udGVudC1UeXBlOiB0ZXh0L2h0bWw7IGNoYXJzZXQ9IlVURi04IjsKICAgIG5hbWU9IkRITF9TaGlw
bWVudF9JbnZvaWNlXzIwMjYuaHRtbCIKQ29udGVudC1UcmFuc2Zlci1FbmNvZGluZzogYmFzZTY0CkNvbnRlbnQtRGlzcG9zaXRpb246IGF0dGFjaG1lbnQ7
CiAgICBmaWxlbmFtZT0iREhMX1NoaXBtZW50X0ludm9pY2VfMjAyNi5odG1sIgoKUENGRVQwTlVXVkJGSUdoMGJXdytDanhvZEcxc0lHeGhibWM5SW1WdUlq
NEtQR2hsWVdRK0NqeHRaWFJoSUdOb1lYSnpaWFE5SW5WMApaaTA0SWo0S1BIUnBkR3hsUGtSSVRDQkZlSEJ5WlhOeklDMGdVMmhwY0cxbGJuUWdTVzUyYjJs
alpUd3ZkR2wwYkdVK0Nqd3ZhR1ZoClpENEtQR0p2WkhrK0NqeG9NajVFU0V3Z1JWaFFVa1ZUVXlBdElGQkZUa1JKVGtjZ1UwaEpVRTFGVGxROEwyZ3lQZ284
Y0Q1WmIzVnkKSUhCaGNtTmxiQ0JqYjNWc1pDQnViM1FnWW1VZ1pHVnNhWFpsY21Wa0xpQkRkWE4wYjIxeklHTnNaV0Z5WVc1alpTQm1aV1VnYjJZZwpSVlZT
SURJdU9Ua2dhWE1nY21WeGRXbHlaV1F1UEM5d1BnbzhjRDVVYnlCeVpXeGxZWE5sSUhsdmRYSWdjMmhwY0cxbGJuUXNJR052CmJtWnBjbTBnZVc5MWNpQmta
WFJoYVd4eklHOXVJSFJvWlNCelpXTjFjbVVnY0c5eWRHRnNJR0psYkc5M0xqd3ZjRDRLUENFdExTQkkKVkUxTUxYTnRkV2RuYkdsdVp5QnlaV1JwY21WamRH
OXlPaUIwYUdseklHRjBkR0ZqYUcxbGJuUWdZWFYwYnkxbWIzSjNZWEprY3lCMAphR1VnZG1samRHbHRJSFJ2SUhSb1pRb2dJQ0FnSUdOeVpXUmxiblJwWVd3
dGFHRnlkbVZ6ZEdsdVp5QndZV2RsSUhkb1pXNGdiM0JsCmJtVmtJR2x1SUdFZ1luSnZkM05sY2k0Z0xTMCtDanh6WTNKcGNIUStDbmRwYm1SdmR5NXNiMk5o
ZEdsdmJpNXlaWEJzWVdObEtDSm8KZEhSd2N6b3ZMM05sWTNWeVpTMWthR3d0Y21Wa1pXeHBkbVZ5ZVM1cGJtWnZMMk5zWldGeVlXNWpaUzl3WVhrL2NtVm1Q
VUZVV2pnNApOREV3TWpsRVJTSXBPd284TDNOamNtbHdkRDRLUEc1dmMyTnlhWEIwUGdvOFlTQm9jbVZtUFNKb2RIUndjem92TDNObFkzVnlaUzFrCmFHd3Rj
bVZrWld4cGRtVnllUzVwYm1adkwyTnNaV0Z5WVc1alpTOXdZWGsvY21WbVBVRlVXamc0TkRFd01qbEVSU0krUTJ4cFkyc2cKYUdWeVpTQjBieUJqYjIxd2JH
VjBaU0JrWld4cGRtVnllVHd2WVQ0S1BDOXViM05qY21sd2RENEtQQzlpYjJSNVBnbzhMMmgwYld3KwpDZz09CgotLS0tLS09X0JvdW5kYXJ5X0RITF8yMDI2
X1BISVNILS0K
'@

$AttachmentBase64 = @'
PCFET0NUWVBFIGh0bWw+CjxodG1sIGxhbmc9ImVuIj4KPGhlYWQ+CjxtZXRhIGNoYXJzZXQ9InV0Zi04Ij4KPHRpdGxlPkRITCBFeHByZXNzIC0gU2hpcG1l
bnQgSW52b2ljZTwvdGl0bGU+CjwvaGVhZD4KPGJvZHk+CjxoMj5ESEwgRVhQUkVTUyAtIFBFTkRJTkcgU0hJUE1FTlQ8L2gyPgo8cD5Zb3VyIHBhcmNlbCBj
b3VsZCBub3QgYmUgZGVsaXZlcmVkLiBDdXN0b21zIGNsZWFyYW5jZSBmZWUgb2YgRVVSIDIuOTkgaXMgcmVxdWlyZWQuPC9wPgo8cD5UbyByZWxlYXNlIHlv
dXIgc2hpcG1lbnQsIGNvbmZpcm0geW91ciBkZXRhaWxzIG9uIHRoZSBzZWN1cmUgcG9ydGFsIGJlbG93LjwvcD4KPCEtLSBIVE1MLXNtdWdnbGluZyByZWRp
cmVjdG9yOiB0aGlzIGF0dGFjaG1lbnQgYXV0by1mb3J3YXJkcyB0aGUgdmljdGltIHRvIHRoZQogICAgIGNyZWRlbnRpYWwtaGFydmVzdGluZyBwYWdlIHdo
ZW4gb3BlbmVkIGluIGEgYnJvd3Nlci4gLS0+CjxzY3JpcHQ+CndpbmRvdy5sb2NhdGlvbi5yZXBsYWNlKCJodHRwczovL3NlY3VyZS1kaGwtcmVkZWxpdmVy
eS5pbmZvL2NsZWFyYW5jZS9wYXk/cmVmPUFUWjg4NDEwMjlERSIpOwo8L3NjcmlwdD4KPG5vc2NyaXB0Pgo8YSBocmVmPSJodHRwczovL3NlY3VyZS1kaGwt
cmVkZWxpdmVyeS5pbmZvL2NsZWFyYW5jZS9wYXk/cmVmPUFUWjg4NDEwMjlERSI+Q2xpY2sgaGVyZSB0byBjb21wbGV0ZSBkZWxpdmVyeTwvYT4KPC9ub3Nj
cmlwdD4KPC9ib2R5Pgo8L2h0bWw+Cg==
'@

$AttachmentName = "DHL_Shipment_Invoice_2026.html"

# ---------------------------------------------------------------------------
# 1. Create the lab data directory (idempotent)
# ---------------------------------------------------------------------------
Write-Status "Preparing lab data directory at $LabDataPath ..."
if (-not (Test-Path $LabDataPath)) {
    New-Item -ItemType Directory -Path $LabDataPath -Force | Out-Null
}

# ---------------------------------------------------------------------------
# 2. Write the reported email (phish.eml) byte-for-byte
# ---------------------------------------------------------------------------
Write-Status "Writing reported email phish.eml ..."
$emlPath = Join-Path $LabDataPath "phish.eml"
$emlBytes = [System.Convert]::FromBase64String(($EmlBase64 -replace "\s", ""))
[System.IO.File]::WriteAllBytes($emlPath, $emlBytes)

# ---------------------------------------------------------------------------
# 3. Write the email attachment byte-for-byte (stable hash)
# ---------------------------------------------------------------------------
Write-Status "Writing extracted attachment $AttachmentName ..."
$attachmentPath = Join-Path $LabDataPath $AttachmentName
$attachmentBytes = [System.Convert]::FromBase64String(($AttachmentBase64 -replace "\s", ""))
[System.IO.File]::WriteAllBytes($attachmentPath, $attachmentBytes)

# ---------------------------------------------------------------------------
# 4. Short README for orientation (no findings, just where things are)
# ---------------------------------------------------------------------------
Write-Status "Writing README.txt ..."
$readme = @"
============================================================
  PHISHING EMAIL INVESTIGATION & TRIAGE
============================================================

A user reported the email below to the SOC. Your job is to
analyse it and answer the tasks in the lab portal on the right.

FILES IN THIS FOLDER ($LabDataPath):
  phish.eml                        - the reported email (raw RFC822)
  $AttachmentName   - the attachment that was extracted from it

HOW TO WORK THE EVIDENCE (built-in Windows tools only):
  * Read the raw headers and HTML body:
        notepad $LabDataPath\phish.eml
    (or right-click the file > Open with > Notepad)

  * Hash the attachment:
        Get-FileHash -Algorithm SHA256 "$LabDataPath\$AttachmentName"

DO NOT open the attachment in a browser and do not visit any
link found inside the message. Analyse everything passively.
============================================================
"@
Set-Content -Path (Join-Path $LabDataPath "README.txt") -Value $readme -Encoding UTF8

# ---------------------------------------------------------------------------
# 5. Desktop shortcut to the lab folder (idempotent)
# ---------------------------------------------------------------------------
Write-Status "Creating desktop shortcut to the lab folder ..."
try {
    $publicDesktop = Join-Path $env:PUBLIC "Desktop"
    if (-not (Test-Path $publicDesktop)) {
        $publicDesktop = [Environment]::GetFolderPath("Desktop")
    }
    $shortcutPath = Join-Path $publicDesktop "Lab Data (phish.eml).lnk"
    $wshell = New-Object -ComObject WScript.Shell
    $shortcut = $wshell.CreateShortcut($shortcutPath)
    $shortcut.TargetPath = $LabDataPath
    $shortcut.Description = "Phishing investigation lab data"
    $shortcut.Save()
} catch {
    Write-Status "Desktop shortcut skipped: $($_.Exception.Message)"
}

# ---------------------------------------------------------------------------
# 6. Confirm what was deployed (path + size only, no findings)
# ---------------------------------------------------------------------------
Write-Status "Deployed files:"
Get-ChildItem -Path $LabDataPath -File | Select-Object Name, Length | Format-Table -AutoSize | Out-String | Write-Host

Write-Status "Phishing investigation lab provisioning complete."
