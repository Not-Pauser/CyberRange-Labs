
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === Phishing Investigation Lab Setup ==="
New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null

# Create realistic phishing email with full MIME structure
@"
Return-Path: <no-reply@hr-beneflts-update.com>
Received: from smtp.hr-beneflts-update.com (198.51.100.55)
        by mail.corp.local (10.0.2.5) with SMTP id abc123def;
        Mon, 18 Mar 2026 08:42:15 +0000
Received: from [192.168.1.100] (unknown [198.51.100.55])
        by smtp.hr-beneflts-update.com (Postfix) with ESMTP id 4F3E2A1B;
        Mon, 18 Mar 2026 08:42:00 +0000
From: "IT Security Team" <security@hr-beneflts-update.com>
Reply-To: helpdesk@secure-login-portal.com
To: all-employees@corp.local
Subject: [ACTION REQUIRED] Password Expiry - Reset Within 24 Hours
Date: Mon, 18 Mar 2026 08:42:00 +0000
MIME-Version: 1.0
Content-Type: multipart/mixed; boundary="----=_NextPart_001_0042_01D9B5F0.A1234567"
X-Mailer: PHPMailer 6.8.0
Message-ID: <fake-20260318-084200@hr-beneflts-update.com>
X-Originating-IP: 198.51.100.55
Authentication-Results: mail.corp.local;
    spf=fail (sender IP 198.51.100.55 not in SPF record for hr-beneflts-update.com);
    dkim=fail (no DKIM signature present);
    dmarc=fail (SPF and DKIM both failed)

------=_NextPart_001_0042_01D9B5F0.A1234567
Content-Type: text/html; charset="UTF-8"
Content-Transfer-Encoding: 7bit

<html>
<head><style>body{font-family:Segoe UI,Arial;}</style></head>
<body>
<div style="max-width:600px;margin:0 auto;border:1px solid #ddd;border-radius:8px;overflow:hidden;">
<div style="background:#0078d4;padding:20px;text-align:center;">
<img src="http://hr-beneflts-update.com/images/corp-logo.png" alt="Corp IT" height="40">
</div>
<div style="padding:25px;">
<h2 style="color:#333;">Urgent: Password Expiration Notice</h2>
<p>Dear Employee,</p>
<p>Our security system has detected that your corporate password will expire in <strong>24 hours</strong>. To maintain access to all company systems, you must reset your password immediately.</p>
<p style="text-align:center;margin:30px 0;">
<a href="http://hr-beneflts-update.com/reset?user=employee&token=a8f3e2&redirect=portal" style="background:#0078d4;color:white;padding:14px 40px;text-decoration:none;border-radius:5px;font-size:16px;display:inline-block;">Reset Password Now</a>
</p>
<p style="color:#666;font-size:12px;">If the button above doesn't work, copy and paste this URL:<br>
<code>http://hr-beneflts-update.com/reset?user=employee&token=a8f3e2</code></p>
<p><strong>Warning:</strong> Failure to reset within 24 hours will result in account lockout.</p>
<hr style="border:none;border-top:1px solid #eee;margin:20px 0;">
<p style="color:#999;font-size:11px;">This is an automated message from IT Security.<br>
Corp IT Security Department | helpdesk@corp.local | Ext. 4500<br>
<em>Do not reply to this email.</em></p>
</div>
</div>
</body>
</html>

------=_NextPart_001_0042_01D9B5F0.A1234567
Content-Type: application/octet-stream; name="Password_Reset_Form.pdf.exe"
Content-Disposition: attachment; filename="Password_Reset_Form.pdf.exe"
Content-Transfer-Encoding: base64
Content-Description: Password reset form

TVqQAAMAAAAEAAAA//8AALgAAAAAAAAAQAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAAA
AAAAAAAAAAAAAAAAAACAAAAO+b8MLAAAABAAAABAAAAAAAEAAAAAAAQAAAAAABAAAAEAAAA
(Truncated - this is actually a PE executable disguised with .pdf.exe double extension)
------=_NextPart_001_0042_01D9B5F0.A1234567--
"@ | Set-Content -Path "C:\LabData\suspicious_email.eml" -Encoding UTF8

# Legitimate email for comparison
@"
Return-Path: <noreply@corp.local>
Received: from mail.corp.local (10.0.2.5)
        by mail.corp.local (10.0.2.5) with ESMTP id xyz789;
        Mon, 18 Mar 2026 09:00:00 +0000
From: "IT Help Desk" <helpdesk@corp.local>
To: jsmith@corp.local
Subject: Re: Ticket #4521 - Outlook Calendar Issue Resolved
Date: Mon, 18 Mar 2026 09:00:00 +0000
MIME-Version: 1.0
Content-Type: text/plain; charset="UTF-8"
Message-ID: <ticket-4521-resolved@corp.local>
Authentication-Results: mail.corp.local;
    spf=pass (sender is authorized for corp.local);
    dkim=pass;
    dmarc=pass

Hi John,

Your support ticket #4521 regarding Outlook calendar sync has been resolved.

The issue was caused by a cached profile that needed to be rebuilt. Your calendar should now sync correctly.

If you continue to experience issues, please reply to this email or call ext. 4500.

Best regards,
Mike Wilson
IT Help Desk
"@ | Set-Content -Path "C:\LabData\legitimate_email.eml" -Encoding UTF8

@"
=== Phishing Email Investigation Lab ===

Emails:
  suspicious_email.eml   - Investigate this email
  legitimate_email.eml   - Known-good email for comparison

Investigation checklist:
  1. Compare From/Return-Path/Reply-To headers
  2. Check Authentication-Results (SPF/DKIM/DMARC)
  3. Trace the Received header chain (read bottom to top)
  4. Examine URLs without clicking (look for typosquatting)
  5. Check attachment: double extension (.pdf.exe)
  6. Note the domain: "hr-beneflts-update.com" (misspelling of "benefits")

PowerShell analysis:
  Get-Content C:\LabData\suspicious_email.eml | Select-String "Return-Path|^From:|Reply-To|Received:|spf=|dkim=|dmarc=|X-Originating"
  Get-Content C:\LabData\suspicious_email.eml | Select-String "http"
  Get-Content C:\LabData\suspicious_email.eml | Select-String "\.exe|\.pdf"
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] Phishing Investigation lab ready."
