POWERSHELL DEOBFUSCATION LAB - Artifact Kit
=============================================

FILES INCLUDED:
- sample1_base64.txt          : Simple Base64 encoded command
- sample2_concat.txt          : String concatenation obfuscation
- sample3_triple_encoded.txt  : Nested/multi-layer Base64
- sample4_amsi_bypass.txt     : AMSI bypass + download cradle
- sample5_complex.txt         : Multi-technique expert challenge

DIFFICULTY PROGRESSION:
  Sample 1: Easy        (single Base64 layer)
  Sample 2: Easy-Medium (string concat + alias resolution)
  Sample 3: Medium-Hard (nested encoding, 2+ layers)
  Sample 4: Hard        (AMSI bypass, persistence, evasion)
  Sample 5: Expert      (env vars, char codes, multi-stage, C2)

FOR EACH SAMPLE:
1. Decode/deobfuscate the PowerShell command
2. Identify what the decoded command does
3. Extract all IOCs (IPs, domains, URLs, file paths)
4. Map to MITRE ATT&CK techniques
5. Write a detection rule (Sigma, YARA, or Splunk SPL)

USEFUL TOOLS:
- CyberChef (https://gchq.github.io/CyberChef/)
- PowerShell ISE (for safe testing with -WhatIf)
- Python: base64.b64decode() + .decode('utf-16-le')
- base64 -d | iconv -f utf-16le -t utf-8

SAFETY NOTE:
Never execute these samples on production systems!
Use isolated VMs or decode manually only.
